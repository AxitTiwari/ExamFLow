# University Exam & Resource Scheduling System

A minimal full-stack academic project demonstrating how a relational database and OS-inspired scheduling/resource-allocation logic can work together.

## Stack

- **Frontend:** React + Vite
- **Backend:** Node.js + Express
- **Database:** MySQL 8.x (InnoDB)
- **Database driver:** `mysql2`
- **Scheduling engine:** JavaScript modules implementing FCFS and priority-based greedy ordering

## Project structure

```text
university-exam-scheduler/
├── frontend/
│   ├── src/
│   │   ├── App.jsx          # Dashboard and project views
│   │   ├── api.js           # Frontend API client
│   │   ├── main.jsx         # React entry point
│   │   └── styles.css       # Responsive UI styling
│   ├── index.html
│   ├── vite.config.js       # /api development proxy to Express
│   └── package.json
├── backend/
│   ├── src/
│   │   ├── config/db.js     # MySQL connection pool
│   │   ├── controllers/     # Request validation and handling
│   │   ├── middleware/      # 404 and error handling
│   │   ├── routes/          # REST API routes
│   │   ├── scheduler/       # FCFS and priority scheduling engine
│   │   ├── services/        # Database queries
│   │   ├── app.js
│   │   └── server.js
│   ├── .env.example
│   └── package.json
├── database/
│   ├── schema.sql           # Tables, foreign keys, indexes
│   ├── seed.sql             # Demo data
│   └── create-user.sql      # Optional restricted MySQL user
├── .gitignore
└── README.md
```

## Requirements

Install the Node.js LTS release and MySQL Server. MySQL Workbench is recommended for running the SQL scripts. VS Code is a convenient editor.

Check the installations in a terminal:

```bash
node -v
npm -v
mysql --version
```

## 1. Create the database

1. Start **MySQL Server**.
2. Open MySQL Workbench and connect to your local server.
3. Open and execute `database/schema.sql` first. It creates the `university_exam_scheduler` database and tables.
4. Execute `database/seed.sql` second. It inserts demo students, subjects, enrollments, faculty, rooms, time slots and exams.
5. Optionally execute `database/create-user.sql` to create the restricted `exam_app` database user. Change its example password first if needed.

If you use the optional account, edit `backend/.env` to match its password. Otherwise you may use your existing local MySQL account in `.env` (avoid using an administrator account outside local development).

## 2. Configure and run the backend

From the project root:

**Windows PowerShell:**

```powershell
Copy-Item backend/.env.example backend/.env
cd backend
npm install
npm run dev
```

Open `backend/.env` and set `DB_USER` and `DB_PASSWORD` to match your local MySQL setup. The example uses the restricted `exam_app` account and password `change_me`.

The API listens on `http://localhost:5000`. Test `http://localhost:5000/api/health`; it should return a small JSON object with `status: "ok"`.

If startup says it cannot connect to MySQL, first check that MySQL Server is running and that the hostname, port, username, password and database name match your local configuration.

## 3. Run the React frontend

Open a **second** terminal at the project root:

```powershell
cd frontend
npm install
npm run dev
```

Vite prints a local URL, normally `http://localhost:5173`. Open that URL in the browser. The frontend proxies `/api` requests to the Express server.

## 4. How to try the project

1. Open the Overview page and confirm that the sample student, exam and room counts appear.
2. Select **FCFS** and click **Generate timetable**.
3. Review the assignments under **Exam timetable**. Check the latest-run metrics on Overview.
4. Select **Priority scheduling**, generate again and compare the allocations and execution-time metric.
5. Open **Exams & subjects** to review subject enrollment, exam status and priority. Use **Add exam** to create an exam for a subject that does not already have an exam.
6. Open **Students** and **Resources** to review the student enrollments, rooms, faculty and time slots.

Generating a schedule replaces the previous generated assignments, then recalculates exam statuses in a database transaction. The timetable currently schedules one room and one invigilating faculty member per exam.

## API reference

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API health check |
| GET | `/api/dashboard` | Dashboard counts |
| GET | `/api/students` | Students and number of subjects |
| GET | `/api/subjects` | Subjects and enrollment counts |
| GET | `/api/exams` | Exams and generated allocation details |
| GET | `/api/rooms` | Room inventory |
| GET | `/api/faculty` | Faculty inventory |
| GET | `/api/time-slots` | Available and blocked time slots |
| GET | `/api/timetable` | Scheduled and unscheduled exams |
| GET | `/api/students/:studentId/timetable` | Read-only timetable for the student's enrolled subjects |
| POST | `/api/exams` | Create an exam `{ "subjectId": 1, "durationMinutes": 180, "priority": 3 }` |
| POST | `/api/schedule/generate` | Generate timetable `{ "algorithm": "FCFS" }` or `{ "algorithm": "PRIORITY" }` |
| POST | `/api/schedule/compare` | Run both algorithms, compare metrics, and leave Priority's timetable saved |
| POST | `/api/students` | Create a student record |
| POST | `/api/subjects` | Create a subject record |
| POST | `/api/enrollments` | Enroll a student in a subject |
| POST | `/api/rooms` | Create a room |
| POST | `/api/faculty` | Create a faculty record |
| POST | `/api/time-slots` | Create an available time slot |

## Scheduling logic

The engine orders exams by insertion ID for FCFS, or by priority descending and then insertion ID for priority scheduling. For each exam, it tries available slots in chronological order and assigns the first compatible room and faculty member. It enforces:

- a student cannot have two exams in the same slot;
- a room can only be used once per slot;
- a faculty member must be marked available and can only supervise one exam per slot;
- room capacity must cover the enrolled students for that exam;
- the exam duration must fit inside the slot.

When a valid allocation cannot be found, the exam is marked `UNSCHEDULED` and a reason is returned by the generation API. The compare endpoint runs FCFS and Priority against the same input records and leaves the Priority result saved. Schedule regeneration uses a MySQL transaction so a failed run does not leave a partial timetable. Resource assignment is performed as one combined decision, avoiding partial room/faculty holds in this single-process simulation; it does not simulate concurrent-process deadlock detection. This is a **greedy scheduling simulation inspired by OS scheduling/resource-allocation concepts**, not a replacement for the operating system's real CPU scheduler. The basic priority/FCFS ordering is deterministic, but this is not a mathematically optimal timetable solver.

## Current scope and limitations

- Sample data is fictitious; replace it with authorized university data before real use.
- The React app includes coordinator data-entry views and a read-only student portal preview. The student portal selects a sample student for demonstration; role-based login, permissions, password reset and production security are not implemented yet.
- A single exam is created per subject because `exams.subject_id` is unique in this minimal schema. This can be expanded to support multiple academic years/sections.
- One room is assigned per exam. Large exams that exceed the largest room are reported as unscheduled instead of being split across rooms.
- `scheduling_constraints` documents the intended rules. The current scheduler enforces the hard checks directly; toggling those rows in MySQL does not disable the checks.
- The room utilization metric is calculated as students assigned divided by the total capacities of rooms used in the generated timetable. It is a simple demonstration metric, not a complete institutional utilization report.
- New faculty are initially marked available for existing available slots, and new slots initially mark all active faculty as available. This is a demo assumption; edit `faculty_availability` in MySQL for realistic faculty availability. The project does not use external APIs or hardware.

## Suggested next improvements

Authentication and role permissions, coordinator forms for all master data, editing/removing records, room-wise/faculty-wise reports, an algorithm comparison page that benchmarks both algorithms on the same dataset, and export to CSV/PDF.
