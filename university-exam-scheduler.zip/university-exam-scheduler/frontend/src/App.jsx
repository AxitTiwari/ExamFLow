import { useCallback, useEffect, useMemo, useState } from 'react';
import { api, formatDate, formatTime } from './api.js';

const navItems = [
  { id: 'overview', label: 'Overview', icon: '▦' },
  { id: 'timetable', label: 'Exam timetable', icon: '▤' },
  { id: 'exams', label: 'Exams & subjects', icon: '▣' },
  { id: 'students', label: 'Students', icon: '♙' },
  { id: 'student-portal', label: 'Student portal', icon: '▧' },
  { id: 'resources', label: 'Resources', icon: '◈' }
];

const emptyData = {
  dashboard: { students: 0, subjects: 0, exams: 0, rooms: 0, scheduled: 0, unscheduled: 0 },
  students: [], subjects: [], exams: [], rooms: [], faculty: [], timeSlots: [],
  timetable: { scheduled: [], unscheduled: [] }
};

const dataForms = {
  student: { title: 'Add student', description: 'Create a student record in the university database.', fields: [
    { name: 'studentNo', label: 'Student ID', type: 'text', placeholder: 'e.g. CSE2416' },
    { name: 'name', label: 'Full name', type: 'text', placeholder: 'Student full name' },
    { name: 'department', label: 'Department', type: 'text', placeholder: 'e.g. CSE' },
    { name: 'semester', label: 'Semester', type: 'number', min: 1, max: 12, placeholder: '5' }
  ] },
  subject: { title: 'Add subject', description: 'Create a subject before adding its examination.', fields: [
    { name: 'code', label: 'Subject code', type: 'text', placeholder: 'e.g. CS506' },
    { name: 'name', label: 'Subject name', type: 'text', placeholder: 'Subject name' },
    { name: 'department', label: 'Department', type: 'text', placeholder: 'e.g. CSE' },
    { name: 'semester', label: 'Semester', type: 'number', min: 1, max: 12, placeholder: '5' }
  ] },
  room: { title: 'Add room', description: 'Add a room and the number of students it can seat.', fields: [
    { name: 'roomCode', label: 'Room code', type: 'text', placeholder: 'e.g. A-103' },
    { name: 'building', label: 'Building', type: 'text', placeholder: 'Academic Block A' },
    { name: 'capacity', label: 'Seating capacity', type: 'number', min: 1, max: 10000, placeholder: '30' }
  ] },
  faculty: { title: 'Add faculty', description: 'New faculty will default to available in existing available slots for this demo.', fields: [
    { name: 'employeeNo', label: 'Employee ID', type: 'text', placeholder: 'e.g. FAC105' },
    { name: 'name', label: 'Full name', type: 'text', placeholder: 'Faculty full name' },
    { name: 'department', label: 'Department', type: 'text', placeholder: 'e.g. CSE' }
  ] },
  slot: { title: 'Add time slot', description: 'All active faculty will initially be marked available for this new slot.', fields: [
    { name: 'slotDate', label: 'Date', type: 'date' },
    { name: 'startsAt', label: 'Start time', type: 'time' },
    { name: 'endsAt', label: 'End time', type: 'time' }
  ] },
  enrollment: { title: 'Enroll student in subject', description: 'Enrollments let the engine detect student timetable clashes.', fields: [
    { name: 'studentId', label: 'Student', type: 'student-select' },
    { name: 'subjectId', label: 'Subject', type: 'subject-select' }
  ] }
};

function StatusPill({ status }) {
  const normalized = String(status || 'DRAFT').toLowerCase();
  return <span className={`status-pill status-${normalized}`}>{normalized.replace('-', ' ')}</span>;
}

function MetricCard({ label, value, hint, icon, tone }) {
  return (
    <article className="metric-card">
      <div className={`metric-icon ${tone}`}>{icon}</div>
      <div className="metric-label">{label}</div>
      <div className="metric-value">{value ?? '—'}</div>
      <div className="metric-hint">{hint}</div>
    </article>
  );
}

function SectionHeading({ eyebrow, title, description, action }) {
  return (
    <div className="section-heading">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h2>{title}</h2>
        {description && <p>{description}</p>}
      </div>
      {action}
    </div>
  );
}

function EmptyState({ title, message }) {
  return <div className="empty-state"><span className="empty-icon">▤</span><strong>{title}</strong><p>{message}</p></div>;
}

function TimetableTable({ rows, showStudents = true }) {
  if (!rows?.length) return <EmptyState title="No timetable yet" message="Choose a scheduling algorithm and generate a timetable to see assignments here." />;
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Subject</th><th>Date</th><th>Time slot</th><th>Room</th><th>Faculty</th><th>Students</th></tr></thead>
        <tbody>{rows.map((row) => (
          <tr key={row.scheduleId || row.id || row.examId}>
            <td><div className="table-primary">{row.subjectName}</div><div className="table-secondary">{row.subjectCode}</div></td>
            <td>{formatDate(row.examDate ?? row.slotDate)}</td>
            <td>{formatTime(row.startsAt)} – {formatTime(row.endsAt)}</td>
            <td><span className="room-tag">{row.roomCode || '—'}</span></td>
            <td>{row.facultyName || '—'}</td>
            <td>{row.studentCount ?? 0}</td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  );
}

function App() {
  const [activeView, setActiveView] = useState('overview');
  const [data, setData] = useState(emptyData);
  const [algorithm, setAlgorithm] = useState('FCFS');
  const [latestRun, setLatestRun] = useState(null);
  const [comparison, setComparison] = useState(null);
  const [comparing, setComparing] = useState(false);
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [studentSchedule, setStudentSchedule] = useState({ student: null, scheduled: [], unscheduled: [], pending: [] });
  const [dataRevision, setDataRevision] = useState(0);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [showExamForm, setShowExamForm] = useState(false);
  const [showDataForm, setShowDataForm] = useState(false);
  const [dataFormType, setDataFormType] = useState('student');
  const [dataForm, setDataForm] = useState({});
  const [examForm, setExamForm] = useState({ subjectId: '', durationMinutes: '180', priority: '3' });

  const refreshData = useCallback(async (quiet = false) => {
    if (!quiet) setLoading(true);
    else setRefreshing(true);
    try {
      const [dashboard, students, subjects, exams, rooms, faculty, timeSlots, timetable] = await Promise.all([
        api.dashboard(), api.students(), api.subjects(), api.exams(), api.rooms(), api.faculty(), api.timeSlots(), api.timetable()
      ]);
      setData({ dashboard, students, subjects, exams, rooms, faculty, timeSlots, timetable });
      setSelectedStudentId((current) => current || String(students[0]?.id || ''));
      setDataRevision((current) => current + 1);
      setError('');
    } catch (err) {
      setError(err.message || 'Could not load application data.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { refreshData(); }, [refreshData]);

  useEffect(() => {
    if (!selectedStudentId) return;
    let cancelled = false;
    api.studentTimetable(selectedStudentId)
      .then((result) => { if (!cancelled) setStudentSchedule(result); })
      .catch((err) => { if (!cancelled) setError(err.message || 'Could not load student timetable.'); });
    return () => { cancelled = true; };
  }, [selectedStudentId, dataRevision]);

  const currentTitle = navItems.find((item) => item.id === activeView)?.label || 'Overview';
  const recentExams = useMemo(() => [...data.exams]
    .filter((exam) => exam.scheduleId)
    .sort((a, b) => String(a.examDate).localeCompare(String(b.examDate)) || String(a.startsAt).localeCompare(String(b.startsAt)))
    .slice(0, 5), [data.exams]);

  function openDataForm(type) {
    setDataFormType(type);
    setDataForm({});
    setShowDataForm(true);
    setError('');
    setNotice('');
  }

  async function handleDataFormSubmit(event) {
    event.preventDefault();
    setError('');
    setNotice('');
    try {
      setComparison(null);
      if (dataFormType === 'student') await api.addStudent({ ...dataForm, semester: Number(dataForm.semester) });
      if (dataFormType === 'subject') await api.addSubject({ ...dataForm, semester: Number(dataForm.semester) });
      if (dataFormType === 'room') await api.addRoom({ ...dataForm, capacity: Number(dataForm.capacity) });
      if (dataFormType === 'faculty') await api.addFaculty(dataForm);
      if (dataFormType === 'slot') await api.addTimeSlot(dataForm);
      if (dataFormType === 'enrollment') await api.enrollStudent({ studentId: Number(dataForm.studentId), subjectId: Number(dataForm.subjectId) });
      const successMessages = { student: 'Student added.', subject: 'Subject added.', room: 'Room added.', faculty: 'Faculty member added.', slot: 'Time slot added.', enrollment: 'Student enrolled in subject.' };
      setShowDataForm(false);
      setNotice(successMessages[dataFormType] || 'Record added.');
      await refreshData(true);
    } catch (err) {
      setError(err.message || 'Could not save this record.');
    }
  }

  async function handleGenerate() {
    setGenerating(true);
    setComparison(null);
    setNotice('');
    setError('');
    try {
      const result = await api.generateSchedule(algorithm);
      setLatestRun(result);
      setNotice(`${result.scheduledCount} of ${result.totalExams} exams scheduled using ${result.algorithm}.`);
      await refreshData(true);
      setActiveView('timetable');
    } catch (err) {
      setError(err.message || 'Schedule generation failed.');
    } finally {
      setGenerating(false);
    }
  }

  async function handleCompare() {
    setComparing(true);
    setError('');
    setNotice('');
    try {
      const result = await api.compareAlgorithms();
      setComparison(result.comparison);
      setLatestRun(result.activeSchedule);
      setAlgorithm('PRIORITY');
      setNotice('Algorithm comparison complete. The priority-based timetable is now the active saved schedule.');
      await refreshData(true);
    } catch (err) {
      setError(err.message || 'Could not compare scheduling algorithms.');
    } finally {
      setComparing(false);
    }
  }

  async function handleAddExam(event) {
    event.preventDefault();
    setComparison(null);
    setError('');
    setNotice('');
    try {
      await api.addExam({
        subjectId: Number(examForm.subjectId),
        durationMinutes: Number(examForm.durationMinutes),
        priority: Number(examForm.priority)
      });
      setShowExamForm(false);
      setExamForm({ subjectId: '', durationMinutes: '180', priority: '3' });
      setNotice('Exam created. Generate the timetable to allocate its resources.');
      await refreshData(true);
    } catch (err) {
      setError(err.message || 'Could not create exam.');
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-lockup">
          <div className="brand-mark">EF</div>
          <div><div className="brand-name">ExamFlow</div><div className="brand-subtitle">UNIVERSITY SCHEDULING</div></div>
        </div>
        <div className="sidebar-label">WORKSPACE</div>
        <nav className="side-nav" aria-label="Main navigation">
          {navItems.map((item) => (
            <button key={item.id} className={`nav-item ${activeView === item.id ? 'active' : ''}`} onClick={() => setActiveView(item.id)}>
              <span className="nav-icon">{item.icon}</span><span>{item.label}</span>
              {item.id === 'timetable' && data.dashboard.scheduled > 0 && <span className="nav-count">{data.dashboard.scheduled}</span>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="os-card"><div className="os-card-icon">⌘</div><div><strong>OS + DBMS</strong><p>Integrated scheduling engine</p></div></div>
          <div className="profile-row"><div className="avatar">EC</div><div className="profile-copy"><strong>Exam Coordinator</strong><span>Local demo workspace</span></div><span className="profile-dots">•••</span></div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb">Workspace <span>/</span> <strong>{currentTitle}</strong></div>
          <div className="topbar-right"><span className="system-status"><i /> Local system</span><button className="icon-button" title="Refresh data" onClick={() => refreshData(true)} disabled={refreshing}>↻</button><div className="top-avatar">EC</div></div>
        </header>

        <div className="page-content">
          {(error || notice) && <div className={`alert ${error ? 'alert-error' : 'alert-success'}`} role="status"><span>{error ? '!' : '✓'}</span><div>{error || notice}{error && error.toLowerCase().includes('fetch') && <div className="alert-help">Start MySQL Server and the backend API, then refresh this page.</div>}</div><button onClick={() => { setError(''); setNotice(''); }} aria-label="Dismiss message">×</button></div>}

          {activeView === 'overview' && <>
            <div className="welcome-row"><div><div className="eyebrow">EXAM OPERATIONS / 2026</div><h1>Good evening, Coordinator <span className="wave">✳</span></h1><p>Plan exams, allocate resources, and keep every schedule conflict-free.</p></div><button className="primary-button" onClick={handleGenerate} disabled={generating || loading}><span>{generating ? '◌' : '⚙'}</span>{generating ? 'Generating…' : 'Generate timetable'}</button></div>
            <section className="metrics-grid">
              <MetricCard label="Total students" value={data.dashboard.students} hint="Registered in database" icon="♙" tone="blue" />
              <MetricCard label="Examinations" value={data.dashboard.exams} hint={`${data.dashboard.subjects} subjects available`} icon="▤" tone="violet" />
              <MetricCard label="Scheduled exams" value={data.dashboard.scheduled} hint="Allocated to a time and room" icon="✓" tone="green" />
              <MetricCard label="Active rooms" value={data.dashboard.rooms} hint={`${data.dashboard.unscheduled} exams need attention`} icon="⌂" tone="orange" />
            </section>

            <section className="overview-grid">
              <article className="panel scheduler-panel">
                <div className="panel-heading"><div><div className="eyebrow">AUTOMATION</div><h3>Scheduling engine</h3><p>Choose an algorithm to allocate available resources.</p></div><span className="panel-heading-icon">⌘</span></div>
                <label className="field-label" htmlFor="algorithm">Scheduling algorithm</label>
                <select id="algorithm" className="select-control" value={algorithm} onChange={(event) => setAlgorithm(event.target.value)}>
                  <option value="FCFS">FCFS — First Come, First Served</option>
                  <option value="PRIORITY">Priority scheduling — highest priority first</option>
                </select>
                <div className="algorithm-note"><span>i</span><p>{algorithm === 'FCFS' ? 'Exams are considered in their creation order. The engine assigns the earliest compatible slot and resources.' : 'Higher-priority exams are considered first; ties are resolved by creation order.'}</p></div>
                <div className="constraint-list"><div><span className="check-mark">✓</span> Student exam overlap checks</div><div><span className="check-mark">✓</span> Room capacity and availability</div><div><span className="check-mark">✓</span> Faculty availability and conflicts</div><div><span className="check-mark">✓</span> Exam duration must fit the slot</div></div>
                <button className="primary-button full-button" onClick={handleGenerate} disabled={generating || comparing || loading}>{generating ? 'Generating schedule…' : 'Run scheduling algorithm'} <span>→</span></button>
                <button className="secondary-button compare-button" onClick={handleCompare} disabled={generating || comparing || loading}>{comparing ? 'Comparing both algorithms…' : '⇄ Compare FCFS vs Priority'}</button>
              </article>

              <article className="panel performance-panel">
                <div className="panel-heading"><div><div className="eyebrow">LAST RUN</div><h3>Scheduling results</h3><p>Summary of the most recent generation.</p></div><span className="result-icon">↗</span></div>
                {latestRun ? <>
                  <div className="run-algorithm"><span className="tiny-dot" />{latestRun.algorithm} algorithm</div>
                  <div className="result-stats"><div><span>Scheduled</span><strong>{latestRun.scheduledCount}<small> / {latestRun.totalExams}</small></strong></div><div><span>Execution time</span><strong>{latestRun.executionTimeMs}<small> ms</small></strong></div></div>
                  <div className="utilization-head"><span>Room capacity utilization</span><strong>{latestRun.roomCapacityUtilization}%</strong></div><div className="progress-track"><div className="progress-value" style={{ width: `${Math.min(100, latestRun.roomCapacityUtilization)}%` }} /></div>
                  {latestRun.unscheduled.length > 0 && <div className="warning-line">! {latestRun.unscheduled.length} exam(s) could not be scheduled.</div>}
                </> : <div className="first-run"><div className="first-run-graphic">◷</div><strong>Ready when you are</strong><p>Run an algorithm to see execution time, allocation success and room utilization.</p></div>}
              </article>
            </section>

            {comparison && <section className="panel comparison-panel"><div className="panel-heading"><div><div className="eyebrow">PERFORMANCE ANALYSIS</div><h3>Algorithm comparison</h3><p>Both algorithms were run on the current database records. Priority scheduling is the active saved timetable.</p></div><span className="compare-icon">⇄</span></div><div className="table-wrap"><table><thead><tr><th>Algorithm</th><th>Scheduled</th><th>Unscheduled</th><th>Execution time</th><th>Room capacity utilization</th></tr></thead><tbody>{[comparison.fcfs, comparison.priority].map((item) => <tr key={item.algorithm}><td><strong className="table-primary">{item.algorithm}</strong>{item.algorithm === 'PRIORITY' && <span className="active-note">Active timetable</span>}</td><td>{item.scheduledCount} / {item.totalExams}</td><td>{item.unscheduledCount}</td><td>{item.executionTimeMs} ms</td><td>{item.roomCapacityUtilization}%</td></tr>)}</tbody></table></div><p className="comparison-footnote">Execution times are run-time measurements and can vary between runs. These are simple project metrics, not an optimality guarantee.</p></section>}

            <section className="panel table-panel">
              <div className="panel-heading panel-heading-inline"><div><div className="eyebrow">ALLOCATED EXAMS</div><h3>Upcoming timetable</h3></div><button className="text-button" onClick={() => setActiveView('timetable')}>View all <span>→</span></button></div>
              <TimetableTable rows={recentExams} />
            </section>
            <div className="lower-grid"><article className="info-card"><div className="info-icon blue">DB</div><div><strong>Data managed by MySQL</strong><p>Students, enrollments, rooms, faculty, availability and schedules stay in a relational database.</p></div></article><article className="info-card"><div className="info-icon purple">OS</div><div><strong>OS concepts in action</strong><p>FCFS, priority ordering and resource-allocation checks are demonstrated in the scheduling engine.</p></div></article></div>
          </>}

          {activeView === 'timetable' && <>
            <SectionHeading eyebrow="SCHEDULE MANAGEMENT" title="Exam timetable" description="Browse generated examination assignments and review any exams the engine could not place." action={<button className="primary-button" onClick={handleGenerate} disabled={generating || loading}>{generating ? 'Generating…' : '↻ Regenerate'}</button>} />
            <div className="metrics-grid compact-metrics"><MetricCard label="Scheduled" value={data.timetable.scheduled.length} hint="Assigned exams" icon="✓" tone="green" /><MetricCard label="Unscheduled" value={data.timetable.unscheduled.length} hint="Need review" icon="!" tone="orange" /><MetricCard label="Time slots" value={data.timeSlots.length} hint="Configured slots" icon="◷" tone="blue" /></div>
            <section className="panel table-panel"><div className="panel-heading panel-heading-inline"><div><h3>Generated assignments</h3><p>Ordered by date and start time</p></div><span className="soft-label">{data.timetable.scheduled.length} assignments</span></div><TimetableTable rows={[...data.timetable.scheduled].sort((a,b) => String(a.examDate).localeCompare(String(b.examDate)) || String(a.startsAt).localeCompare(String(b.startsAt)))} /></section>
            {data.timetable.unscheduled.length > 0 && <section className="panel table-panel"><div className="panel-heading"><div><h3>Needs attention</h3><p>These exams could not be allocated with the current resources.</p></div></div><div className="table-wrap"><table><thead><tr><th>Exam</th><th>Students</th><th>Status</th><th>Reason</th></tr></thead><tbody>{data.timetable.unscheduled.map((exam) => <tr key={exam.id}><td><div className="table-primary">{exam.subjectName}</div><div className="table-secondary">{exam.subjectCode}</div></td><td>{exam.studentCount}</td><td><StatusPill status="UNSCHEDULED" /></td><td className="reason-cell">{exam.status === 'UNSCHEDULED' ? 'No valid allocation. Regenerate or review available room capacity, slots and faculty.' : 'Not generated yet.'}</td></tr>)}</tbody></table></div></section>}
            {latestRun?.unscheduled?.length > 0 && <section className="panel unscheduled-detail"><h3>Latest run: unscheduled reasons</h3>{latestRun.unscheduled.map((item) => <div className="reason-row" key={item.examId}><strong>{item.subjectCode} · {item.subjectName}</strong><span>{item.reason}</span></div>)}</section>}
          </>}

          {activeView === 'exams' && <>
            <SectionHeading eyebrow="ACADEMIC DATA" title="Exams & subjects" description="Exams are linked to subjects. Set duration and priority before running the scheduling engine." action={<div className="header-actions"><button className="secondary-button" onClick={() => openDataForm('subject')}>＋ Add subject</button><button className="primary-button" onClick={() => setShowExamForm(true)}>＋ Add exam</button></div>} />
            <section className="panel table-panel"><div className="panel-heading panel-heading-inline"><div><h3>Examination list</h3><p>{data.exams.length} exam record(s)</p></div><button className="secondary-button" onClick={() => refreshData(true)} disabled={refreshing}>{refreshing ? 'Refreshing…' : '↻ Refresh'}</button></div>
              {data.exams.length ? <div className="table-wrap"><table><thead><tr><th>Subject</th><th>Enrolled students</th><th>Duration</th><th>Priority</th><th>Status</th><th>Assignment</th></tr></thead><tbody>{data.exams.map((exam) => <tr key={exam.id}><td><div className="table-primary">{exam.subjectName}</div><div className="table-secondary">{exam.subjectCode}</div></td><td>{exam.studentCount}</td><td>{exam.durationMinutes} min</td><td><span className="priority-value">{exam.priority} <span>/ 5</span></span></td><td><StatusPill status={exam.status} /></td><td>{exam.roomCode ? `${exam.roomCode} · ${formatDate(exam.examDate)}` : 'Not assigned'}</td></tr>)}</tbody></table></div> : <EmptyState title="No exam records" message="Import the sample SQL data or add a subject and exam in MySQL." />}
            </section>
            <section className="panel subject-panel"><div className="panel-heading"><div><h3>Subjects</h3><p>Subject records used by the exam schedule.</p></div></div><div className="subject-grid">{data.subjects.map((subject) => <div className="subject-card" key={subject.id}><div className="subject-code">{subject.code}</div><strong>{subject.name}</strong><div className="subject-meta">{subject.department} <span>·</span> Semester {subject.semester}</div><div className="subject-enrollment"><span>Enrolled</span><strong>{subject.studentCount}</strong></div></div>)}</div></section>
          </>}

          {activeView === 'student-portal' && <>
            <SectionHeading eyebrow="STUDENT VIEW" title="Student portal" description="Demo view of the timetable for a selected student. Authentication is not enabled in this prototype." action={<span className="soft-label">Read-only schedule</span>} />
            <section className="panel student-portal-panel"><div className="student-portal-banner"><div className="portal-avatar">♙</div><div><div className="eyebrow">MY EXAM SCHEDULE</div><h3>{studentSchedule.student?.name || 'Select a student'}</h3><p>{studentSchedule.student?.studentNo ? `Student ID: ${studentSchedule.student.studentNo}` : 'Choose a sample student to preview their schedule.'}</p></div></div><label className="field-label" htmlFor="student-picker">Preview student</label><select id="student-picker" className="select-control student-picker" value={selectedStudentId} onChange={(event) => setSelectedStudentId(event.target.value)}><option value="">Choose a student</option>{data.students.map((student) => <option value={student.id} key={student.id}>{student.studentNo} — {student.name}</option>)}</select></section>
            <div className="metrics-grid compact-metrics"><MetricCard label="Upcoming exams" value={studentSchedule.scheduled.length} hint="Assigned to this student" icon="✓" tone="green" /><MetricCard label="Unscheduled" value={studentSchedule.unscheduled.length} hint="Exam needs coordinator review" icon="!" tone="orange" /><MetricCard label="Pending" value={studentSchedule.pending.length} hint="Not generated yet" icon="◷" tone="blue" /></div>
            <section className="panel table-panel"><div className="panel-heading"><div><h3>My timetable</h3><p>Only exams for the selected student's enrolled subjects are shown.</p></div></div><TimetableTable rows={studentSchedule.scheduled} showStudents={false} /></section>
            {studentSchedule.unscheduled.length > 0 && <section className="panel unscheduled-detail"><h3>Exams awaiting allocation</h3>{studentSchedule.unscheduled.map((exam) => <div className="reason-row" key={exam.id}><strong>{exam.subjectCode} · {exam.subjectName}</strong><span>The coordinator could not find a valid allocation. Please check the official timetable later.</span></div>)}</section>}
          </>}

          {activeView === 'students' && <>
            <SectionHeading eyebrow="STUDENT DIRECTORY" title="Students" description="Student-to-subject enrollment is used to prevent two exams for the same student in one time slot." action={<div className="header-actions"><button className="secondary-button" onClick={() => openDataForm('enrollment')} disabled={!data.students.length || !data.subjects.length}>＋ Enroll in subject</button><button className="primary-button" onClick={() => openDataForm('student')}>＋ Add student</button><span className="soft-label">{data.students.length} students</span></div>} />
            <section className="panel table-panel"><div className="panel-heading"><div><h3>Registered students</h3><p>Sample records are provided in database/seed.sql.</p></div></div>{data.students.length ? <div className="table-wrap"><table><thead><tr><th>Student</th><th>Student ID</th><th>Department</th><th>Semester</th><th>Subjects</th></tr></thead><tbody>{data.students.map((student) => <tr key={student.id}><td><div className="student-cell"><span className="student-avatar">{student.name.split(' ').map((n) => n[0]).slice(0,2).join('')}</span><span className="table-primary">{student.name}</span></div></td><td>{student.studentNo}</td><td>{student.department}</td><td>{student.semester}</td><td>{student.subjectCount}</td></tr>)}</tbody></table></div> : <EmptyState title="No student records" message="Run database/seed.sql to load sample students and enrollments." />}</section>
          </>}

          {activeView === 'resources' && <>
            <SectionHeading eyebrow="RESOURCE MANAGEMENT" title="Resources & availability" description="The scheduling engine uses room capacity, faculty availability and time-slot windows to make valid allocations." action={<div className="header-actions"><button className="secondary-button" onClick={() => openDataForm('slot')}>＋ Time slot</button><button className="secondary-button" onClick={() => openDataForm('faculty')}>＋ Faculty</button><button className="primary-button" onClick={() => openDataForm('room')}>＋ Room</button></div>} />
            <section className="panel table-panel"><div className="panel-heading"><div><h3>Rooms</h3><p>Rooms are ordered by seating capacity.</p></div></div><div className="resource-grid">{data.rooms.map((room) => <div className="resource-card" key={room.id}><div className="resource-card-icon">⌂</div><div className="resource-card-body"><strong>{room.roomCode}</strong><span>{room.building}</span></div><div className="capacity"><strong>{room.capacity}</strong><span>seats</span></div></div>)}</div></section>
            <section className="panel table-panel"><div className="panel-heading"><div><h3>Faculty</h3><p>Active faculty are assigned only to slots where their availability is configured.</p></div></div>{data.faculty.length ? <div className="table-wrap"><table><thead><tr><th>Faculty member</th><th>Employee ID</th><th>Department</th><th>Status</th></tr></thead><tbody>{data.faculty.map((person) => <tr key={person.id}><td><div className="table-primary">{person.name}</div></td><td>{person.employeeNo}</td><td>{person.department}</td><td><StatusPill status={person.isActive ? 'ACTIVE' : 'INACTIVE'} /></td></tr>)}</tbody></table></div> : <EmptyState title="No faculty records" message="Run database/seed.sql to create sample faculty." />}</section>
            <section className="panel table-panel"><div className="panel-heading"><div><h3>Time slots</h3><p>Only slots marked AVAILABLE are considered by the scheduler.</p></div></div>{data.timeSlots.length ? <div className="table-wrap"><table><thead><tr><th>Date</th><th>Start time</th><th>End time</th><th>Duration</th><th>Status</th></tr></thead><tbody>{data.timeSlots.map((slot) => <tr key={slot.id}><td>{formatDate(slot.slotDate)}</td><td>{formatTime(slot.startsAt)}</td><td>{formatTime(slot.endsAt)}</td><td>{Math.round((Number(String(slot.endsAt).slice(0,2))*60 + Number(String(slot.endsAt).slice(3,5))) - (Number(String(slot.startsAt).slice(0,2))*60 + Number(String(slot.startsAt).slice(3,5))))} min</td><td><StatusPill status={slot.status} /></td></tr>)}</tbody></table></div> : <EmptyState title="No time slots" message="Run database/seed.sql to create example time slots." />}</section>
          </>}

          <footer className="app-footer"><span>ExamFlow <span className="footer-dot">·</span> University Exam & Resource Scheduling System</span><span>React <span className="footer-dot">·</span> Express <span className="footer-dot">·</span> MySQL</span></footer>
        </div>
      </main>

      {showExamForm && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowExamForm(false); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="add-exam-title"><div className="modal-heading"><div><div className="eyebrow">EXAM SETUP</div><h2 id="add-exam-title">Add examination</h2><p>Choose a subject and configure its scheduling priority.</p></div><button className="close-button" onClick={() => setShowExamForm(false)} aria-label="Close">×</button></div>
        <form onSubmit={handleAddExam} className="form-stack"><label className="form-field"><span>Subject</span><select required value={examForm.subjectId} onChange={(event) => setExamForm({ ...examForm, subjectId: event.target.value })}><option value="">Select a subject</option>{data.subjects.filter((subject) => !data.exams.some((exam) => exam.subjectId === subject.id)).map((subject) => <option value={subject.id} key={subject.id}>{subject.code} — {subject.name}</option>)}</select></label><div className="form-two"><label className="form-field"><span>Duration (minutes)</span><input type="number" required min="1" max="1440" value={examForm.durationMinutes} onChange={(event) => setExamForm({ ...examForm, durationMinutes: event.target.value })} /></label><label className="form-field"><span>Priority (1–5)</span><select value={examForm.priority} onChange={(event) => setExamForm({ ...examForm, priority: event.target.value })}>{[1,2,3,4,5].map((level) => <option value={level} key={level}>{level}{level === 5 ? ' — Highest' : level === 1 ? ' — Lowest' : ''}</option>)}</select></label></div><div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setShowExamForm(false)}>Cancel</button><button type="submit" className="primary-button" disabled={!data.subjects.some((subject) => !data.exams.some((exam) => exam.subjectId === subject.id))}>Create exam</button></div></form>
      </section></div>}

      {showDataForm && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowDataForm(false); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="data-form-title"><div className="modal-heading"><div><div className="eyebrow">DATABASE MANAGEMENT</div><h2 id="data-form-title">{dataForms[dataFormType].title}</h2><p>{dataForms[dataFormType].description}</p></div><button className="close-button" onClick={() => setShowDataForm(false)} aria-label="Close">×</button></div>
        <form onSubmit={handleDataFormSubmit} className="form-stack">{dataForms[dataFormType].fields.map((field) => {
          const selectOptions = field.type === 'student-select' ? data.students.map((item) => ({ value: item.id, label: `${item.studentNo} — ${item.name}` })) : field.type === 'subject-select' ? data.subjects.map((item) => ({ value: item.id, label: `${item.code} — ${item.name}` })) : [];
          const inputType = field.type === 'student-select' || field.type === 'subject-select' ? 'select' : field.type;
          return <label className="form-field" key={field.name}><span>{field.label}</span>{inputType === 'select' ? <select required value={dataForm[field.name] || ''} onChange={(event) => setDataForm({ ...dataForm, [field.name]: event.target.value })}><option value="">Choose {field.name === 'studentId' ? 'a student' : 'a subject'}</option>{selectOptions.map((option) => <option value={option.value} key={option.value}>{option.label}</option>)}</select> : <input required type={inputType} min={field.min} max={field.max} placeholder={field.placeholder || ''} value={dataForm[field.name] || ''} onChange={(event) => setDataForm({ ...dataForm, [field.name]: event.target.value })} />}</label>;
        })}<div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setShowDataForm(false)}>Cancel</button><button type="submit" className="primary-button" disabled={dataForms[dataFormType].fields.some((field) => (field.type === 'student-select' && !data.students.length) || (field.type === 'subject-select' && !data.subjects.length))}>Save record</button></div></form>
      </section></div>}
    </div>
  );
}

export default App;
