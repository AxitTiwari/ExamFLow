async function request(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `Request failed (${response.status})`);
  return payload;
}

export const api = {
  health: () => request('/health'),
  dashboard: () => request('/dashboard'),
  students: () => request('/students'),
  studentTimetable: (studentId) => request(`/students/${studentId}/timetable`),
  subjects: () => request('/subjects'),
  exams: () => request('/exams'),
  rooms: () => request('/rooms'),
  faculty: () => request('/faculty'),
  timeSlots: () => request('/time-slots'),
  timetable: () => request('/timetable'),
  addExam: (body) => request('/exams', { method: 'POST', body: JSON.stringify(body) }),
  addStudent: (body) => request('/students', { method: 'POST', body: JSON.stringify(body) }),
  addSubject: (body) => request('/subjects', { method: 'POST', body: JSON.stringify(body) }),
  addRoom: (body) => request('/rooms', { method: 'POST', body: JSON.stringify(body) }),
  addFaculty: (body) => request('/faculty', { method: 'POST', body: JSON.stringify(body) }),
  addTimeSlot: (body) => request('/time-slots', { method: 'POST', body: JSON.stringify(body) }),
  enrollStudent: (body) => request('/enrollments', { method: 'POST', body: JSON.stringify(body) }),
  generateSchedule: (algorithm) => request('/schedule/generate', {
    method: 'POST', body: JSON.stringify({ algorithm })
  }),
  compareAlgorithms: () => request('/schedule/compare', { method: 'POST', body: '{}' })
};

export function formatDate(value) {
  if (!value) return '—';
  // MySQL returns DATE values as YYYY-MM-DD; parsing with an explicit local
  // format prevents off-by-one-day display shifts in some time zones.
  const [year, month, day] = String(value).slice(0, 10).split('-').map(Number);
  return new Date(year, month - 1, day).toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric'
  });
}

export function formatTime(value) {
  if (!value) return '—';
  const [hours, minutes] = String(value).split(':').map(Number);
  const date = new Date();
  date.setHours(hours, minutes, 0, 0);
  return date.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
}
