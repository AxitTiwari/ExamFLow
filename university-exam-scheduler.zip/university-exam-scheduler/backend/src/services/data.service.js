import { pool } from '../config/db.js';

export async function getDashboardData() {
  const [students] = await pool.query('SELECT COUNT(*) AS count FROM students');
  const [subjects] = await pool.query('SELECT COUNT(*) AS count FROM subjects');
  const [exams] = await pool.query('SELECT COUNT(*) AS count FROM exams');
  const [rooms] = await pool.query('SELECT COUNT(*) AS count FROM rooms WHERE is_active = 1');
  const [scheduled] = await pool.query("SELECT COUNT(*) AS count FROM exams WHERE status = 'SCHEDULED'");
  const [unscheduled] = await pool.query("SELECT COUNT(*) AS count FROM exams WHERE status = 'UNSCHEDULED'");

  return {
    students: students[0].count,
    subjects: subjects[0].count,
    exams: exams[0].count,
    rooms: rooms[0].count,
    scheduled: scheduled[0].count,
    unscheduled: unscheduled[0].count
  };
}

export async function listStudents() {
  const [rows] = await pool.query(`
    SELECT st.id, st.student_no AS studentNo, st.full_name AS name,
           st.department, st.semester,
           COUNT(ss.subject_id) AS subjectCount
    FROM students st
    LEFT JOIN student_subjects ss ON ss.student_id = st.id
    GROUP BY st.id
    ORDER BY st.student_no
  `);
  return rows;
}

export async function listSubjects() {
  const [rows] = await pool.query(`
    SELECT s.id, s.subject_code AS code, s.subject_name AS name,
           s.department, s.semester, COUNT(ss.student_id) AS studentCount
    FROM subjects s
    LEFT JOIN student_subjects ss ON ss.subject_id = s.id
    GROUP BY s.id
    ORDER BY s.subject_code
  `);
  return rows;
}

export async function listExams() {
  const [rows] = await pool.query(`
    SELECT e.id, e.subject_id AS subjectId, s.subject_code AS subjectCode,
           s.subject_name AS subjectName, e.duration_minutes AS durationMinutes,
           e.priority, e.status,
           COUNT(DISTINCT ss.student_id) AS studentCount,
           es.id AS scheduleId, ts.slot_date AS examDate,
           ts.starts_at AS startsAt, ts.ends_at AS endsAt,
           r.room_code AS roomCode, f.full_name AS facultyName
    FROM exams e
    JOIN subjects s ON s.id = e.subject_id
    LEFT JOIN student_subjects ss ON ss.subject_id = s.id
    LEFT JOIN exam_schedules es ON es.exam_id = e.id
    LEFT JOIN time_slots ts ON ts.id = es.time_slot_id
    LEFT JOIN rooms r ON r.id = es.room_id
    LEFT JOIN faculty f ON f.id = es.faculty_id
    GROUP BY e.id, s.id, es.id, ts.id, r.id, f.id
    ORDER BY e.priority DESC, s.subject_code
  `);
  return rows;
}

export async function listRooms() {
  const [rows] = await pool.query(`
    SELECT id, room_code AS roomCode, building, capacity, is_active AS isActive
    FROM rooms ORDER BY capacity, room_code
  `);
  return rows;
}

export async function listFaculty() {
  const [rows] = await pool.query(`
    SELECT id, employee_no AS employeeNo, full_name AS name, department,
           is_active AS isActive
    FROM faculty ORDER BY full_name
  `);
  return rows;
}

export async function listTimeSlots() {
  const [rows] = await pool.query(`
    SELECT id, slot_date AS slotDate, starts_at AS startsAt, ends_at AS endsAt, status
    FROM time_slots ORDER BY slot_date, starts_at
  `);
  return rows;
}

export async function listTimetable() {
  const exams = await listExams();
  return {
    scheduled: exams.filter((exam) => exam.scheduleId),
    unscheduled: exams.filter((exam) => !exam.scheduleId && exam.status === 'UNSCHEDULED')
  };
}

export async function createExam({ subjectId, durationMinutes, priority }) {
  const [subject] = await pool.execute('SELECT id FROM subjects WHERE id = ?', [subjectId]);
  if (!subject.length) {
    const error = new Error('The selected subject does not exist.');
    error.status = 400;
    throw error;
  }

  const [result] = await pool.execute(
    `INSERT INTO exams (subject_id, duration_minutes, priority, status)
     VALUES (?, ?, ?, 'DRAFT')`,
    [subjectId, durationMinutes, priority]
  );
  return { id: result.insertId, subjectId, durationMinutes, priority, status: 'DRAFT' };
}
