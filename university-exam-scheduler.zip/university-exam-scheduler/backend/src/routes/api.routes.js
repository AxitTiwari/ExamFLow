import { Router } from 'express';
import { compareAlgorithms, generateSchedule } from '../scheduler/scheduler.service.js';
import {
  addExam, addFaculty, addRoom, addStudent, addSubject, addTimeSlot,
  dashboard, enrollStudent, exams, faculty, rooms, studentTimetable, students, subjects,
  timeSlots, timetable
} from '../controllers/data.controller.js';

const router = Router();
const asyncRoute = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

router.get('/health', (req, res) => res.json({ status: 'ok', service: 'university-exam-scheduler-api' }));
router.get('/dashboard', asyncRoute(dashboard));
router.get('/students', asyncRoute(students));
router.get('/students/:studentId/timetable', asyncRoute(studentTimetable));
router.get('/subjects', asyncRoute(subjects));
router.get('/exams', asyncRoute(exams));
router.get('/rooms', asyncRoute(rooms));
router.get('/faculty', asyncRoute(faculty));
router.get('/time-slots', asyncRoute(timeSlots));
router.get('/timetable', asyncRoute(timetable));

router.post('/students', asyncRoute(addStudent));
router.post('/subjects', asyncRoute(addSubject));
router.post('/rooms', asyncRoute(addRoom));
router.post('/faculty', asyncRoute(addFaculty));
router.post('/time-slots', asyncRoute(addTimeSlot));
router.post('/enrollments', asyncRoute(enrollStudent));
router.post('/exams', asyncRoute(addExam));
router.post('/schedule/generate', asyncRoute(async (req, res) => {
  res.json(await generateSchedule(req.body.algorithm));
}));
router.post('/schedule/compare', asyncRoute(async (req, res) => {
  res.json(await compareAlgorithms());
}));

export default router;
