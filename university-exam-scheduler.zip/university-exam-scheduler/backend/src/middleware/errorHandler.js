export function notFound(req, res) {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
}

export function errorHandler(err, req, res, next) {
  console.error(err);
  if (res.headersSent) return next(err);

  const status = err.status || (err.code === 'ER_DUP_ENTRY' ? 409 : 500);
  const message = err.code === 'ER_DUP_ENTRY'
    ? 'A record with the same unique value already exists.'
    : (status === 500 ? 'An unexpected server error occurred.' : err.message);

  res.status(status).json({ error: message });
}
