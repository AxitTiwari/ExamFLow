import { performance } from 'node:perf_hooks';
import { pool } from '../config/db.js';

const toMinutes = (value) => {
  const [hours, minutes, seconds = '0'] = String(value).split(':');
  return Number(hours) * 60 + Number(minutes) + Number(seconds) / 60;
};

function normalizeAlgorithm(value) {
  const algorithm = String(value || 'FCFS').toUpperCase();
  if (!['FCFS', 'PRIORITY'].includes(algorithm)) {
    const error = new Error('Algorithm must be FCFS or PRIORITY.');
    error.status = 400;
    throw error;
  }
  return algorithm;
}

/**
 * Greedy resource-allocation simulation. It applies OS-inspired FCFS/priority
 * ordering while enforcing the project's hard constraints at application level.
 * It is not the operating system's actual CPU scheduler.
 */
export async function generateSchedule(requestedAlgorithm = 'FCFS') {
  const algorithm = normalizeAlgorithm(requestedAlgorithm);
  const startedAt = performance.now();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    // Regeneration replaces the previous timetable atomically.
    await connection.query('DELETE FROM exam_schedules');
    await connection.query("UPDATE exams SET status = 'DRAFT'");

    const [examsRaw] = await connection.query(`
      SELECT e.id, e.subject_id AS subjectId, e.duration_minutes AS durationMinutes,
             e.priority, s.subject_code AS subjectCode, s.subject_name AS subjectName,
             COUNT(DISTINCT ss.student_id) AS studentCount
      FROM exams e
      JOIN subjects s ON s.id = e.subject_id
      LEFT JOIN student_subjects ss ON ss.subject_id = s.id
      GROUP BY e.id, s.id
    `);
    const [studentsBySubject] = await connection.query(
      'SELECT subject_id AS subjectId, student_id AS studentId FROM student_subjects'
    );
    const [slots] = await connection.query(`
      SELECT id, slot_date AS slotDate, starts_at AS startsAt, ends_at AS endsAt
      FROM time_slots WHERE status = 'AVAILABLE'
      ORDER BY slot_date, starts_at
    `);
    const [rooms] = await connection.query(`
      SELECT id, room_code AS roomCode, capacity FROM rooms
      WHERE is_active = 1 ORDER BY capacity, room_code
    `);
    const [faculty] = await connection.query(`
      SELECT id, full_name AS name FROM faculty
      WHERE is_active = 1 ORDER BY full_name
    `);
    const [availabilityRows] = await connection.query(
      'SELECT faculty_id AS facultyId, time_slot_id AS timeSlotId FROM faculty_availability'
    );

    const studentIdsBySubject = new Map();
    for (const row of studentsBySubject) {
      if (!studentIdsBySubject.has(row.subjectId)) studentIdsBySubject.set(row.subjectId, []);
      studentIdsBySubject.get(row.subjectId).push(row.studentId);
    }

    const facultyAvailable = new Set(availabilityRows.map((row) => `${row.facultyId}:${row.timeSlotId}`));
    const occupiedRooms = new Set();
    const occupiedFaculty = new Set();
    const studentsBySlot = new Map();
    const scheduled = [];
    const unscheduled = [];

    const exams = [...examsRaw].sort((a, b) => {
      if (algorithm === 'PRIORITY' && b.priority !== a.priority) return b.priority - a.priority;
      return a.id - b.id;
    });

    for (const exam of exams) {
      const enrolledStudents = studentIdsBySubject.get(exam.subjectId) || [];
      const studentCount = enrolledStudents.length;
      let selected = null;
      let sawLargeEnoughRoom = false;
      let sawAvailableFaculty = false;
      let sawDurationFit = false;

      for (const slot of slots) {
        const slotKey = String(slot.id);
        const slotDuration = toMinutes(slot.endsAt) - toMinutes(slot.startsAt);
        if (slotDuration < Number(exam.durationMinutes)) continue;
        sawDurationFit = true;

        const alreadyScheduledStudents = studentsBySlot.get(slotKey) || new Set();
        if (enrolledStudents.some((studentId) => alreadyScheduledStudents.has(studentId))) continue;

        for (const room of rooms) {
          if (Number(room.capacity) < studentCount) continue;
          sawLargeEnoughRoom = true;
          if (occupiedRooms.has(`${slot.id}:${room.id}`)) continue;

          for (const person of faculty) {
            if (!facultyAvailable.has(`${person.id}:${slot.id}`)) continue;
            sawAvailableFaculty = true;
            if (occupiedFaculty.has(`${slot.id}:${person.id}`)) continue;

            selected = { slot, room, faculty: person };
            break;
          }
          if (selected) break;
        }
        if (selected) break;
      }

      if (!selected) {
        let reason = 'No combination of free time slot, room, and faculty was available.';
        if (studentCount > 0 && rooms.length && !rooms.some((room) => Number(room.capacity) >= studentCount)) {
          reason = `No active room can hold all ${studentCount} enrolled students.`;
        } else if (!sawDurationFit) {
          reason = `No available time slot is at least ${exam.durationMinutes} minutes long.`;
        } else if (!sawLargeEnoughRoom) {
          reason = 'No active room has sufficient capacity.';
        } else if (!sawAvailableFaculty) {
          reason = 'No faculty member is marked available for a suitable time slot.';
        } else if (slots.length === 0) {
          reason = 'There are no available time slots.';
        }
        unscheduled.push({
          examId: exam.id,
          subjectCode: exam.subjectCode,
          subjectName: exam.subjectName,
          studentCount,
          reason
        });
        await connection.execute("UPDATE exams SET status = 'UNSCHEDULED' WHERE id = ?", [exam.id]);
        continue;
      }

      await connection.execute(
        `INSERT INTO exam_schedules
          (exam_id, time_slot_id, room_id, faculty_id, student_count, algorithm)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [exam.id, selected.slot.id, selected.room.id, selected.faculty.id, studentCount, algorithm]
      );
      await connection.execute("UPDATE exams SET status = 'SCHEDULED' WHERE id = ?", [exam.id]);

      occupiedRooms.add(`${selected.slot.id}:${selected.room.id}`);
      occupiedFaculty.add(`${selected.slot.id}:${selected.faculty.id}`);
      if (!studentsBySlot.has(String(selected.slot.id))) studentsBySlot.set(String(selected.slot.id), new Set());
      for (const studentId of enrolledStudents) studentsBySlot.get(String(selected.slot.id)).add(studentId);

      scheduled.push({
        examId: exam.id,
        subjectCode: exam.subjectCode,
        subjectName: exam.subjectName,
        studentCount,
        slotDate: selected.slot.slotDate,
        startsAt: selected.slot.startsAt,
        endsAt: selected.slot.endsAt,
        roomCode: selected.room.roomCode,
        facultyName: selected.faculty.name
      });
    }

    await connection.commit();

    const totalCapacity = scheduled.reduce((sum, item) => {
      const room = rooms.find((candidate) => candidate.roomCode === item.roomCode);
      return sum + (room ? Number(room.capacity) : 0);
    }, 0);
    const totalStudents = scheduled.reduce((sum, item) => sum + item.studentCount, 0);
    const executionTimeMs = Number((performance.now() - startedAt).toFixed(2));

    return {
      algorithm,
      scheduledCount: scheduled.length,
      unscheduledCount: unscheduled.length,
      totalExams: exams.length,
      executionTimeMs,
      roomCapacityUtilization: totalCapacity ? Number(((totalStudents / totalCapacity) * 100).toFixed(1)) : 0,
      scheduled,
      unscheduled,
      note: 'This is a greedy scheduling simulation using OS-inspired ordering and application-level resource constraints.'
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

/** Run both algorithms against the same current input data. Priority is left as the active saved timetable. */
export async function compareAlgorithms() {
  const fcfs = await generateSchedule('FCFS');
  const priority = await generateSchedule('PRIORITY');
  return {
    comparison: {
      fcfs: {
        algorithm: fcfs.algorithm,
        totalExams: fcfs.totalExams,
        scheduledCount: fcfs.scheduledCount,
        unscheduledCount: fcfs.unscheduledCount,
        executionTimeMs: fcfs.executionTimeMs,
        roomCapacityUtilization: fcfs.roomCapacityUtilization
      },
      priority: {
        algorithm: priority.algorithm,
        totalExams: priority.totalExams,
        scheduledCount: priority.scheduledCount,
        unscheduledCount: priority.unscheduledCount,
        executionTimeMs: priority.executionTimeMs,
        roomCapacityUtilization: priority.roomCapacityUtilization
      }
    },
    activeSchedule: priority
  };
}
