import express from 'express';
import cors from 'cors';
import apiRoutes from './routes/api.routes.js';
import { errorHandler, notFound } from './middleware/errorHandler.js';

const app = express();
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
app.get('/', (req, res) => res.json({ name: 'University Exam & Resource Scheduling System', api: '/api/health' }));
app.use('/api', apiRoutes);
app.use(notFound);
app.use(errorHandler);

export default app;
