import { pool } from '../config/db.js';
import {
  createExam, getDashboardData, listExams, listFaculty, listRooms,
  listStudents, listSubjects, listTimeSlots, listTimetable
} from '../services/data.service.js';

const requiredText = (value, field) => {
  const normalized = String(value ?? '').trim();
  if (!normalized) {
    const error = new Error(`${field} is required.`);
    error.status = 400;
    throw error;
  }
  return normalized;
};

const positiveInt = (value, field, max = 2147483647) => {
  const number = Number(value);
  if (!Number.isInteger(number) || number <= 0 || number > max) {
    const error = new Error(`${field} must be a positive whole number.`);
    error.status = 400;
    throw error;
  }
  return number;
};

export const dashboard = async (req, res) => res.json(await getDashboardData());
export const students = async (req, res) => res.json(await listStudents());
export const subjects = async (req, res) => res.json(await listSubjects());
export const exams = async (req, res) => res.json(await listExams());
export const rooms = async (req, res) => res.json(await listRooms());
export const faculty = async (req, res) => res.json(await listFaculty());
export const timeSlots = async (req, res) => res.json(await listTimeSlots());
export const timetable = async (req, res) => res.json(await listTimetable());

export const studentTimetable = async (req, res) => {
  const studentId = positiveInt(req.params.studentId, 'studentId');
  const [studentRows] = await pool.execute(
    'SELECT id, student_no AS studentNo, full_name AS name FROM students WHERE id = ?',
    [studentId]
  );
  if (!studentRows.length) {
    const error = new Error('Student not found.');
    error.status = 404;
    throw error;
  }
  const [rows] = await pool.execute(`
    SELECT e.id, e.status, e.duration_minutes AS durationMinutes,
           s.subject_code AS subjectCode, s.subject_name AS subjectName,
           es.id AS scheduleId, ts.slot_date AS examDate,
           ts.starts_at AS startsAt, ts.ends_at AS endsAt,
           r.room_code AS roomCode, f.full_name AS facultyName
    FROM student_subjects ss
    JOIN exams e ON e.subject_id = ss.subject_id
    JOIN subjects s ON s.id = e.subject_id
    LEFT JOIN exam_schedules es ON es.exam_id = e.id
    LEFT JOIN time_slots ts ON ts.id = es.time_slot_id
    LEFT JOIN rooms r ON r.id = es.room_id
    LEFT JOIN faculty f ON f.id = es.faculty_id
    WHERE ss.student_id = ?
    ORDER BY ts.slot_date, ts.starts_at, s.subject_code
  `, [studentId]);
  res.json({
    student: studentRows[0],
    scheduled: rows.filter((row) => row.scheduleId),
    unscheduled: rows.filter((row) => !row.scheduleId && row.status === 'UNSCHEDULED'),
    pending: rows.filter((row) => !row.scheduleId && row.status === 'DRAFT')
  });
};

export const addExam = async (req, res) => {
  const subjectId = positiveInt(req.body.subjectId, 'subjectId');
  const durationMinutes = positiveInt(req.body.durationMinutes, 'durationMinutes', 1440);
  const priority = Number(req.body.priority ?? 1);
  if (!Number.isInteger(priority) || priority < 1 || priority > 5) {
    const error = new Error('priority must be an integer between 1 and 5.');
    error.status = 400;
    throw error;
  }
  res.status(201).json(await createExam({ subjectId, durationMinutes, priority }));
};

export const addStudent = async (req, res) => {
  const studentNo = requiredText(req.body.studentNo, 'studentNo');
  const name = requiredText(req.body.name, 'name');
  const department = requiredText(req.body.department, 'department');
  const semester = positiveInt(req.body.semester, 'semester', 12);
  const [result] = await pool.execute(
    'INSERT INTO students (student_no, full_name, department, semester) VALUES (?, ?, ?, ?)',
    [studentNo, name, department, semester]
  );
  res.status(201).json({ id: result.insertId, studentNo, name, department, semester });
};

export const addSubject = async (req, res) => {
  const code = requiredText(req.body.code, 'code');
  const name = requiredText(req.body.name, 'name');
  const department = requiredText(req.body.department, 'department');
  const semester = positiveInt(req.body.semester, 'semester', 12);
  const [result] = await pool.execute(
    'INSERT INTO subjects (subject_code, subject_name, department, semester) VALUES (?, ?, ?, ?)',
    [code, name, department, semester]
  );
  res.status(201).json({ id: result.insertId, code, name, department, semester });
};

export const addRoom = async (req, res) => {
  const roomCode = requiredText(req.body.roomCode, 'roomCode');
  const building = requiredText(req.body.building, 'building');
  const capacity = positiveInt(req.body.capacity, 'capacity', 10000);
  const [result] = await pool.execute(
    'INSERT INTO rooms (room_code, building, capacity) VALUES (?, ?, ?)',
    [roomCode, building, capacity]
  );
  res.status(201).json({ id: result.insertId, roomCode, building, capacity });
};

export const addFaculty = async (req, res) => {
  const employeeNo = requiredText(req.body.employeeNo, 'employeeNo');
  const name = requiredText(req.body.name, 'name');
  const department = requiredText(req.body.department, 'department');
  const [result] = await pool.execute(
    'INSERT INTO faculty (employee_no, full_name, department) VALUES (?, ?, ?)',
    [employeeNo, name, department]
  );
  // Demo assumption from the project proposal: active faculty start as available in existing slots.
  await pool.execute(
    "INSERT IGNORE INTO faculty_availability (faculty_id, time_slot_id) SELECT ?, id FROM time_slots WHERE status = 'AVAILABLE'",
    [result.insertId]
  );
  res.status(201).json({ id: result.insertId, employeeNo, name, department });
};

export const addTimeSlot = async (req, res) => {
  const { slotDate, startsAt, endsAt } = req.body;
  requiredText(slotDate, 'slotDate');
  requiredText(startsAt, 'startsAt');
  requiredText(endsAt, 'endsAt');
  if (String(startsAt) >= String(endsAt)) {
    const error = new Error('endsAt must be later than startsAt.');
    error.status = 400;
    throw error;
  }
  const [result] = await pool.execute(
    "INSERT INTO time_slots (slot_date, starts_at, ends_at, status) VALUES (?, ?, ?, 'AVAILABLE')",
    [slotDate, startsAt, endsAt]
  );
  // In this prototype, all active faculty are initially assumed available for a newly created slot.
  await pool.execute(
    "INSERT IGNORE INTO faculty_availability (faculty_id, time_slot_id) SELECT id, ? FROM faculty WHERE is_active = TRUE",
    [result.insertId]
  );
  res.status(201).json({ id: result.insertId, slotDate, startsAt, endsAt, status: 'AVAILABLE' });
};

export const enrollStudent = async (req, res) => {
  const studentId = positiveInt(req.body.studentId, 'studentId');
  const subjectId = positiveInt(req.body.subjectId, 'subjectId');
  await pool.execute(
    'INSERT INTO student_subjects (student_id, subject_id) VALUES (?, ?)',
    [studentId, subjectId]
  );
  res.status(201).json({ studentId, subjectId });
};
