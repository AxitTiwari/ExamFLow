-- Optional, recommended: create a restricted account for the Node.js backend.
-- Change this password before using the app on any shared machine.
CREATE USER IF NOT EXISTS 'exam_app'@'localhost' IDENTIFIED BY 'change_me';
GRANT SELECT, INSERT, UPDATE, DELETE ON university_exam_scheduler.* TO 'exam_app'@'localhost';
FLUSH PRIVILEGES;
