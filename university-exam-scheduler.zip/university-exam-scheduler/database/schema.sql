-- University Exam & Resource Scheduling System
-- Run this script in MySQL Workbench or MySQL Shell.
CREATE DATABASE IF NOT EXISTS university_exam_scheduler
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE university_exam_scheduler;

CREATE TABLE IF NOT EXISTS students (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_no VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(120) NOT NULL,
  department VARCHAR(80) NOT NULL,
  semester TINYINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS subjects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  subject_code VARCHAR(20) NOT NULL UNIQUE,
  subject_name VARCHAR(120) NOT NULL,
  department VARCHAR(80) NOT NULL,
  semester TINYINT UNSIGNED NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS student_subjects (
  student_id INT UNSIGNED NOT NULL,
  subject_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (student_id, subject_id),
  CONSTRAINT fk_student_subject_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_student_subject_subject FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  INDEX idx_student_subject_subject (subject_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS faculty (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  employee_no VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(120) NOT NULL,
  department VARCHAR(80) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS rooms (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  room_code VARCHAR(30) NOT NULL UNIQUE,
  building VARCHAR(80) NOT NULL,
  capacity SMALLINT UNSIGNED NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  CHECK (capacity > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS time_slots (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slot_date DATE NOT NULL,
  starts_at TIME NOT NULL,
  ends_at TIME NOT NULL,
  status ENUM('AVAILABLE', 'BLOCKED') NOT NULL DEFAULT 'AVAILABLE',
  UNIQUE KEY uq_slot_date_time (slot_date, starts_at, ends_at),
  CHECK (ends_at > starts_at),
  INDEX idx_time_slots_order (slot_date, starts_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS faculty_availability (
  faculty_id INT UNSIGNED NOT NULL,
  time_slot_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (faculty_id, time_slot_id),
  CONSTRAINT fk_availability_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
  CONSTRAINT fk_availability_slot FOREIGN KEY (time_slot_id) REFERENCES time_slots(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS exams (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  subject_id INT UNSIGNED NOT NULL UNIQUE,
  duration_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 180,
  priority TINYINT UNSIGNED NOT NULL DEFAULT 1,
  status ENUM('DRAFT', 'SCHEDULED', 'UNSCHEDULED') NOT NULL DEFAULT 'DRAFT',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_exam_subject FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  CHECK (duration_minutes > 0),
  CHECK (priority BETWEEN 1 AND 5)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS exam_schedules (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  exam_id INT UNSIGNED NOT NULL UNIQUE,
  time_slot_id INT UNSIGNED NOT NULL,
  room_id INT UNSIGNED NOT NULL,
  faculty_id INT UNSIGNED NOT NULL,
  student_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  algorithm ENUM('FCFS', 'PRIORITY') NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_schedule_exam FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE,
  CONSTRAINT fk_schedule_slot FOREIGN KEY (time_slot_id) REFERENCES time_slots(id),
  CONSTRAINT fk_schedule_room FOREIGN KEY (room_id) REFERENCES rooms(id),
  CONSTRAINT fk_schedule_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id),
  UNIQUE KEY uq_room_per_slot (time_slot_id, room_id),
  UNIQUE KEY uq_faculty_per_slot (time_slot_id, faculty_id),
  INDEX idx_schedule_slot (time_slot_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scheduling_constraints (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  constraint_key VARCHAR(50) NOT NULL UNIQUE,
  description VARCHAR(255) NOT NULL,
  is_enabled BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

INSERT IGNORE INTO scheduling_constraints (constraint_key, description, is_enabled) VALUES
('NO_STUDENT_OVERLAP', 'A student cannot sit two exams in the same time slot.', TRUE),
('ROOM_CAPACITY', 'Room capacity must be sufficient for every enrolled student.', TRUE),
('NO_ROOM_OVERLAP', 'A room can host at most one exam per time slot.', TRUE),
('FACULTY_AVAILABILITY', 'An assigned faculty member must be available and cannot supervise two simultaneous exams.', TRUE),
('EXAM_DURATION', 'An exam must fit entirely inside an available time slot.', TRUE);
