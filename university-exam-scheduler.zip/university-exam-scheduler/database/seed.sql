USE university_exam_scheduler;

INSERT IGNORE INTO students (id, student_no, full_name, department, semester) VALUES
(1, 'CSE2401', 'Aarav Sharma', 'CSE', 5),
(2, 'CSE2402', 'Ananya Joshi', 'CSE', 5),
(3, 'CSE2403', 'Kabir Verma', 'CSE', 5),
(4, 'CSE2404', 'Meera Singh', 'CSE', 5),
(5, 'CSE2405', 'Rohan Rawat', 'CSE', 5),
(6, 'CSE2406', 'Ishita Kapoor', 'CSE', 5),
(7, 'AIML2401', 'Dev Patel', 'CSE-AI/ML', 5),
(8, 'AIML2402', 'Sara Khan', 'CSE-AI/ML', 5),
(9, 'AIML2403', 'Arjun Mehta', 'CSE-AI/ML', 5),
(10, 'AIML2404', 'Nisha Das', 'CSE-AI/ML', 5),
(11, 'AIML2405', 'Yash Gupta', 'CSE-AI/ML', 5),
(12, 'AIML2406', 'Diya Rana', 'CSE-AI/ML', 5),
(13, 'CSE2301', 'Manav Saini', 'CSE', 5),
(14, 'CSE2302', 'Aditi Negi', 'CSE', 5),
(15, 'CSE2303', 'Vihaan Bhatia', 'CSE', 5);

INSERT IGNORE INTO subjects (id, subject_code, subject_name, department, semester) VALUES
(1, 'CS501', 'Data Structures', 'CSE', 5),
(2, 'CS502', 'Database Management Systems', 'CSE', 5),
(3, 'CS503', 'Operating Systems', 'CSE', 5),
(4, 'CS504', 'Computer Networks', 'CSE', 5),
(5, 'AI501', 'Machine Learning', 'CSE-AI/ML', 5),
(6, 'CS505', 'Design and Analysis of Algorithms', 'CSE', 5);

INSERT IGNORE INTO student_subjects (student_id, subject_id) VALUES
(1,1),(1,2),(1,3),(1,6),
(2,1),(2,2),(2,4),(2,6),
(3,1),(3,3),(3,4),(3,6),
(4,1),(4,2),(4,3),(4,4),
(5,1),(5,2),(5,6),
(6,1),(6,3),(6,5),(6,6),
(7,2),(7,3),(7,5),
(8,2),(8,4),(8,5),
(9,2),(9,3),(9,4),(9,5),
(10,3),(10,4),(10,5),
(11,2),(11,5),(11,6),
(12,1),(12,4),(12,5),
(13,1),(13,3),(13,6),
(14,2),(14,4),(14,6),
(15,1),(15,2),(15,3),(15,4),(15,6);

INSERT IGNORE INTO faculty (id, employee_no, full_name, department, is_active) VALUES
(1, 'FAC101', 'Dr. Neha Sharma', 'CSE', TRUE),
(2, 'FAC102', 'Prof. Rahul Mehta', 'CSE', TRUE),
(3, 'FAC103', 'Dr. Pooja Joshi', 'CSE-AI/ML', TRUE),
(4, 'FAC104', 'Prof. Amit Rawat', 'CSE', TRUE);

INSERT IGNORE INTO rooms (id, room_code, building, capacity, is_active) VALUES
(1, 'A-101', 'Academic Block A', 20, TRUE),
(2, 'A-102', 'Academic Block A', 30, TRUE),
(3, 'B-201', 'Academic Block B', 45, TRUE),
(4, 'AUD-1', 'Main Block', 100, TRUE);

INSERT IGNORE INTO time_slots (id, slot_date, starts_at, ends_at, status) VALUES
(1, '2026-11-10', '09:00:00', '12:00:00', 'AVAILABLE'),
(2, '2026-11-10', '13:00:00', '16:00:00', 'AVAILABLE'),
(3, '2026-11-11', '09:00:00', '12:00:00', 'AVAILABLE'),
(4, '2026-11-11', '13:00:00', '16:00:00', 'AVAILABLE'),
(5, '2026-11-12', '09:00:00', '12:00:00', 'AVAILABLE'),
(6, '2026-11-12', '13:00:00', '16:00:00', 'AVAILABLE');

INSERT IGNORE INTO faculty_availability (faculty_id, time_slot_id)
SELECT f.id, ts.id FROM faculty f CROSS JOIN time_slots ts WHERE f.is_active = TRUE AND ts.status = 'AVAILABLE';

INSERT IGNORE INTO exams (id, subject_id, duration_minutes, priority, status) VALUES
(1, 1, 180, 5, 'DRAFT'),
(2, 2, 180, 4, 'DRAFT'),
(3, 3, 180, 5, 'DRAFT'),
(4, 4, 180, 3, 'DRAFT'),
(5, 5, 180, 2, 'DRAFT'),
(6, 6, 180, 4, 'DRAFT');
