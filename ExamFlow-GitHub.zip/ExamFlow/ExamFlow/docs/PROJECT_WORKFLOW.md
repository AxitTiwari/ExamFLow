# ExamFlow — Project workflow reference

## Typical end-to-end flow

1. Administrator configures courses, branches and subjects.
2. Administrator creates subject offerings for a precise academic batch.
3. Students register and select the corresponding academic batch.
4. Students enroll in the subject offerings available to them.
5. Teachers register; admin approves their accounts.
6. Approved teachers publish their weekly/date-specific availability.
7. Administrator registers rooms and their actual seating capacities.
8. Administrator creates an examination session and adds exam tasks.
9. Admin chooses FCFS or Priority Scheduling and generates a draft timetable.
10. Admin reviews allocations; use **Clear draft** before allowing further student enrollment changes, then regenerate when ready.
11. Admin publishes the final timetable only after every exam is placed.
12. Students see their published exam schedules; teachers see their published invigilation duties.

## Core scheduling inputs

- Session date range and daily operating window.
- Exam duration and priority.
- Enrolled students per subject offering.
- Room seating capacity.
- Approved teacher availability.
- Existing schedule allocations across all sessions.

## Important implementation choices

- All application-owned tables use the `efp_` prefix.
- Public registration is available only for student and teacher roles.
- Admin identity is bootstrapped from backend environment variables.
- Teachers must be approved before login and before they can be assigned as invigilators.
- Published sessions are immutable through the application routes.
- Scheduling is a greedy conflict-aware allocator, not an optimization solver.
