import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, BookOpenCheck, CalendarDays, CheckCircle2, GraduationCap, ShieldCheck, Users } from 'lucide-react';
import api, { messageFromError } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Field, SelectField, Button, Notice } from '../components/shared';

const blankStudent = { name: '', email: '', password: '', course_id: '', branch_id: '', academic_year: String(new Date().getFullYear()), semester: '1', roll_number: '' };
const blankTeacher = { name: '', email: '', password: '', department: '', designation: '', employee_code: '' };

export default function AuthPage() {
  const { login, registerStudent, registerTeacher } = useAuth();
  const [mode, setMode] = useState('login');
  const [role, setRole] = useState('student');
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const [student, setStudent] = useState(blankStudent);
  const [teacher, setTeacher] = useState(blankTeacher);
  const [catalog, setCatalog] = useState({ courses: [], branches: [] });
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState(null);

  useEffect(() => { api.get('/public/catalog').then(({ data }) => setCatalog(data)).catch(() => {}); }, []);
  const branchOptions = useMemo(() => catalog.branches.filter((b) => String(b.course_id) === String(student.course_id)).map((b) => ({ value: b.id, label: `${b.name} (${b.code})` })), [catalog.branches, student.course_id]);
  const courseOptions = catalog.courses.map((c) => ({ value: c.id, label: `${c.name} (${c.code})` }));

  const submit = async (event) => {
    event.preventDefault(); setBusy(true); setNotice(null);
    try {
      if (mode === 'login') {
        await login(credentials);
      } else if (role === 'student') {
        await registerStudent(student);
      } else {
        await registerTeacher(teacher);
        setNotice({ type: 'success', text: 'Registration sent successfully. You can sign in after an administrator approves your account.' });
        setMode('login');
      }
    } catch (error) { setNotice({ type: 'error', text: messageFromError(error) }); }
    finally { setBusy(false); }
  };

  return <div className="min-h-screen bg-white lg:grid lg:grid-cols-[minmax(420px,1fr)_minmax(500px,1fr)]">
    <section className="relative hidden overflow-hidden bg-ink px-12 py-10 text-white lg:flex lg:flex-col lg:justify-between xl:px-16">
      <div className="absolute -right-36 -top-24 h-[460px] w-[460px] rounded-full border border-white/5" />
      <div className="absolute -right-12 -top-2 h-[320px] w-[320px] rounded-full border border-white/5" />
      <div className="relative z-10 flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-xl bg-brand"><BookOpenCheck size={22} /></span><div><p className="font-display text-xl font-extrabold">ExamFlow</p><p className="text-[10px] font-bold uppercase tracking-[.18em] text-slate-400">University examination system</p></div></div>
      <div className="relative z-10 max-w-xl pb-10">
        <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-teal/30 bg-teal/10 px-3 py-1.5 text-[11px] font-bold text-teal-200"><span className="h-1.5 w-1.5 rounded-full bg-teal" /> Smarter examination operations</span>
        <h1 className="font-display text-5xl font-extrabold leading-[1.14] tracking-tight xl:text-[58px]">A clearer way to plan <span className="text-[#8e9cff]">every exam.</span></h1>
        <p className="mt-6 max-w-md text-sm leading-7 text-slate-400">Bring academic records, examination rooms, faculty availability, and timetable scheduling into one dependable workspace.</p>
        <div className="mt-10 grid grid-cols-3 gap-3">
          {[['01','Academic data'],['02','Smart scheduling'],['03','Clear timetables']].map(([n,label]) => <div key={n} className="rounded-2xl border border-white/10 bg-white/5 p-4"><p className="text-[10px] font-extrabold text-teal">{n}</p><p className="mt-2 text-xs font-bold text-slate-200">{label}</p></div>)}
        </div>
      </div>
      <div className="relative z-10 flex items-center justify-between text-[10px] font-semibold text-slate-500"><span>ExamFlow · Campus operations</span><span>OS + DBMS integrated project</span></div>
    </section>

    <section className="flex min-h-screen items-center justify-center bg-[#f7f9fc] px-5 py-9 sm:px-10">
      <div className="w-full max-w-[470px]">
        <div className="mb-8 flex items-center gap-3 lg:hidden"><span className="grid h-10 w-10 place-items-center rounded-xl bg-ink text-white"><BookOpenCheck size={20} /></span><div><p className="font-display text-lg font-extrabold">ExamFlow</p><p className="text-[10px] uppercase tracking-widest text-muted">Campus operations</p></div></div>
        <div className="mb-7"><p className="text-[11px] font-extrabold uppercase tracking-[.17em] text-brand">Welcome to ExamFlow</p><h2 className="mt-2 font-display text-3xl font-extrabold tracking-tight text-ink">{mode === 'login' ? 'Sign in to your portal' : 'Create your account'}</h2><p className="mt-2 text-sm text-muted">{mode === 'login' ? 'Use your university account to continue.' : 'Choose your role and enter your details below.'}</p></div>
        {notice && <Notice type={notice.type} onClose={() => setNotice(null)}>{notice.text}</Notice>}
        <div className="rounded-3xl border border-slate-100 bg-white p-5 shadow-soft sm:p-7">
          {mode === 'register' && <div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-slate-100 p-1">
            <button type="button" onClick={() => setRole('student')} className={`flex items-center justify-center gap-2 rounded-lg py-2.5 text-xs font-extrabold ${role === 'student' ? 'bg-white text-ink shadow-sm' : 'text-slate-500'}`}><GraduationCap size={15} /> Student</button>
            <button type="button" onClick={() => setRole('teacher')} className={`flex items-center justify-center gap-2 rounded-lg py-2.5 text-xs font-extrabold ${role === 'teacher' ? 'bg-white text-ink shadow-sm' : 'text-slate-500'}`}><Users size={15} /> Teacher</button>
          </div>}
          <form onSubmit={submit} className="space-y-4">
            {mode === 'login' ? <>
              <Field label="Email address" type="email" autoComplete="username" placeholder="you@university.edu" value={credentials.email} onChange={(e) => setCredentials({ ...credentials, email: e.target.value })} required />
              <Field label="Password" type="password" autoComplete="current-password" placeholder="Enter your password" value={credentials.password} onChange={(e) => setCredentials({ ...credentials, password: e.target.value })} required />
            </> : <>
              <Field label="Full name" placeholder="Your full name" value={role === 'student' ? student.name : teacher.name} onChange={(e) => role === 'student' ? setStudent({ ...student, name: e.target.value }) : setTeacher({ ...teacher, name: e.target.value })} required />
              <Field label="Email address" type="email" placeholder="you@university.edu" value={role === 'student' ? student.email : teacher.email} onChange={(e) => role === 'student' ? setStudent({ ...student, email: e.target.value }) : setTeacher({ ...teacher, email: e.target.value })} required />
              <Field label="Password" type="password" minLength={8} placeholder="At least 8 characters" value={role === 'student' ? student.password : teacher.password} onChange={(e) => role === 'student' ? setStudent({ ...student, password: e.target.value }) : setTeacher({ ...teacher, password: e.target.value })} required />
              {role === 'student' ? <>
                <div className="grid grid-cols-2 gap-3">
                  <SelectField label="Course" options={courseOptions} value={student.course_id} onChange={(e) => setStudent({ ...student, course_id: e.target.value, branch_id: '' })} required />
                  <SelectField label="Branch" options={branchOptions} value={student.branch_id} onChange={(e) => setStudent({ ...student, branch_id: e.target.value })} required disabled={!student.course_id} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Academic year" type="number" min="2000" max="2200" value={student.academic_year} onChange={(e) => setStudent({ ...student, academic_year: e.target.value })} required />
                  <SelectField label="Semester" options={Array.from({ length: 12 }, (_, i) => ({ value: i + 1, label: `Semester ${i + 1}` }))} value={student.semester} onChange={(e) => setStudent({ ...student, semester: e.target.value })} required />
                </div>
                <Field label="University roll number (optional)" placeholder="e.g. 24CSE102" value={student.roll_number} onChange={(e) => setStudent({ ...student, roll_number: e.target.value })} />
              </> : <>
                <Field label="Department" placeholder="e.g. Computer Science" value={teacher.department} onChange={(e) => setTeacher({ ...teacher, department: e.target.value })} required />
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Designation (optional)" placeholder="Assistant Professor" value={teacher.designation} onChange={(e) => setTeacher({ ...teacher, designation: e.target.value })} />
                  <Field label="Employee code (optional)" placeholder="EMP-102" value={teacher.employee_code} onChange={(e) => setTeacher({ ...teacher, employee_code: e.target.value })} />
                </div>
                <div className="rounded-xl bg-amber-50 p-3 text-xs leading-5 text-amber-800">Teacher accounts require administrator approval before sign-in is enabled.</div>
              </>}
            </>}
            <Button type="submit" loading={busy} className="mt-1 w-full">{mode === 'login' ? 'Sign in' : 'Create account'} <ArrowRight size={16} /></Button>
          </form>
          <div className="my-5 flex items-center gap-3"><span className="h-px flex-1 bg-slate-100" /><span className="text-[10px] font-bold uppercase tracking-widest text-slate-300">or</span><span className="h-px flex-1 bg-slate-100" /></div>
          <button onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setNotice(null); }} className="w-full rounded-xl border border-slate-200 py-3 text-xs font-extrabold text-slate-600 transition hover:border-brand/40 hover:bg-brand-soft/50 hover:text-brand">{mode === 'login' ? 'Create a student or teacher account' : 'Back to sign in'}</button>
        </div>
        <div className="mt-6 flex items-center justify-center gap-4 text-[10px] font-semibold text-slate-400"><span className="inline-flex items-center gap-1"><ShieldCheck size={13} /> Secure login</span><span>·</span><span className="inline-flex items-center gap-1"><CalendarDays size={13} /> Timetable access</span></div>
      </div>
    </section>
  </div>;
}
