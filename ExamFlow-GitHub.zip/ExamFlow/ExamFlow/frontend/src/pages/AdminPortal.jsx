import { useEffect, useMemo, useState } from 'react';
import {
  Activity, BookOpen, Building2, CalendarClock, CalendarDays, Check, ChevronRight, ClipboardList,
  GraduationCap, LayoutDashboard, Plus, RefreshCw, ShieldCheck, Users, WandSparkles, X
} from 'lucide-react';
import AppShell from '../components/AppShell';
import { Button, Field, Notice, PageTitle, Panel, SelectField, StatCard, StatusPill, Table } from '../components/shared';
import api, { messageFromError } from '../lib/api';

const nav = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'academic', label: 'Academic setup', icon: BookOpen },
  { id: 'students', label: 'Students', icon: GraduationCap },
  { id: 'rooms', label: 'Examination rooms', icon: Building2 },
  { id: 'sessions', label: 'Sessions & exams', icon: CalendarDays },
  { id: 'schedule', label: 'Timetable builder', icon: CalendarClock },
  { id: 'teachers', label: 'Teacher approvals', icon: Users }
];
const currentYear = new Date().getFullYear();
const initial = {
  course: { name: '', code: '' }, branch: { course_id: '', name: '', code: '' }, subject: { code: '', name: '', credits: '3' },
  offering: { subject_id: '', course_id: '', branch_id: '', academic_year: String(currentYear), semester: '1' },
  room: { name: '', building: '', capacity: '60', room_type: 'Classroom' },
  session: { name: '', start_date: '', end_date: '', day_start_time: '09:00', day_end_time: '17:00' },
  exam: { session_id: '', offering_id: '', duration_minutes: '180', priority: '1' }
};

export default function AdminPortal() {
  const [active, setActive] = useState('overview');
  const [data, setData] = useState({ overview: null, courses: [], branches: [], subjects: [], offerings: [], rooms: [], sessions: [], teachers: [], students: [] });
  const [forms, setForms] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState(null);
  const [algorithm, setAlgorithm] = useState('FCFS');
  const [selectedSession, setSelectedSession] = useState('');
  const [scheduleData, setScheduleData] = useState(null);
  const [editing, setEditing] = useState(null);

  const loadAll = async () => {
    const endpoints = [
      ['overview', '/admin/overview'], ['courses', '/admin/courses'], ['branches', '/admin/branches'],
      ['subjects', '/admin/subjects'], ['offerings', '/admin/offerings'], ['rooms', '/admin/rooms'],
      ['sessions', '/admin/sessions'], ['teachers', '/admin/teachers'], ['students', '/admin/students']
    ];
    const results = await Promise.allSettled(endpoints.map(([, url]) => api.get(url)));
    const next = {};
    results.forEach((result, index) => {
      const key = endpoints[index][0];
      if (result.status === 'fulfilled') next[key] = result.value.data[key] ?? result.value.data;
    });
    setData((old) => ({ ...old, ...next }));
  };

  useEffect(() => { loadAll(); }, []);
  useEffect(() => {
    if (active === 'schedule' && selectedSession) {
      api.get(`/admin/sessions/${selectedSession}/schedule`).then(({ data: response }) => setScheduleData(response)).catch((error) => setNotice({ type: 'error', text: messageFromError(error) }));
    }
  }, [active, selectedSession]);

  const setForm = (key, value) => setForms((old) => ({ ...old, [key]: { ...old[key], ...value } }));
  const runAction = async (action, successMessage) => {
    setBusy(true); setNotice(null);
    try { await action(); if (successMessage) setNotice({ type: 'success', text: successMessage }); await loadAll(); }
    catch (error) { setNotice({ type: 'error', text: messageFromError(error) }); }
    finally { setBusy(false); }
  };
  const postForm = (event, endpoint, key, success) => {
    event.preventDefault();
    runAction(async () => { await api.post(endpoint, forms[key]); setForms((old) => ({ ...old, [key]: initial[key] })); }, success);
  };

  const courseOptions = data.courses.map((item) => ({ value: item.id, label: `${item.name} (${item.code})` }));
  const branchOptions = data.branches.map((item) => ({ value: item.id, label: `${item.name} · ${item.course_name}` }));
  const subjectOptions = data.subjects.map((item) => ({ value: item.id, label: `${item.code} — ${item.name}` }));
  const offeringOptions = data.offerings.map((item) => ({ value: item.id, label: `${item.subject_code} — ${item.subject_name} · ${item.course_name}/${item.branch_name} · Sem ${item.semester}` }));
  const sessionOptions = data.sessions.map((item) => ({ value: item.id, label: `${item.name}${item.status === 'published' ? ' · Published' : ''}` }));
  const approvedTeachers = data.teachers.filter((teacher) => teacher.status === 'active').map((teacher) => ({ value: teacher.teacher_id, label: teacher.name }));

  const generate = async () => {
    if (!selectedSession) { setNotice({ type: 'error', text: 'Choose an examination session first.' }); return; }
    setBusy(true); setNotice(null);
    try {
      const { data: response } = await api.post(`/admin/sessions/${selectedSession}/generate`, { algorithm });
      setScheduleData(await (await api.get(`/admin/sessions/${selectedSession}/schedule`)).data);
      setNotice({ type: response.unscheduled.length ? 'info' : 'success', text: `${response.scheduled.length} of ${response.total} examinations scheduled using ${response.algorithm}. ${response.unscheduled.length ? `${response.unscheduled.length} could not be placed; check available rooms, enrollments and teacher availability.` : 'Review the timetable and publish when ready.'}` });
      await loadAll();
    } catch (error) { setNotice({ type: 'error', text: messageFromError(error) }); }
    finally { setBusy(false); }
  };

  const publish = () => runAction(async () => {
    const { data: response } = await api.post(`/admin/sessions/${selectedSession}/publish`);
    setNotice({ type: 'success', text: response.message });
    const { data: refreshed } = await api.get(`/admin/sessions/${selectedSession}/schedule`);
    setScheduleData(refreshed);
  });

  const saveEdit = async (event) => {
    event.preventDefault(); if (!editing || !selectedSession) return;
    setBusy(true); setNotice(null);
    try {
      await api.patch(`/admin/sessions/${selectedSession}/schedule/${editing.id}`, editing);
      const { data: refreshed } = await api.get(`/admin/sessions/${selectedSession}/schedule`);
      setScheduleData(refreshed); setEditing(null); setNotice({ type: 'success', text: 'Schedule updated successfully.' });
    } catch (error) { setNotice({ type: 'error', text: messageFromError(error) }); }
    finally { setBusy(false); }
  };

  const approveTeacher = (teacherId, status) => runAction(() => api.patch(`/admin/teachers/${teacherId}/status`, { status }), status === 'active' ? 'Teacher approved.' : 'Teacher registration rejected.');

  const page = useMemo(() => {
    switch (active) {
      case 'academic': return <>
        <PageTitle eyebrow="Academic data" title="Academic setup" subtitle="Create the academic structure first, then offer subjects to the correct student batches." />
        <div className="grid gap-5 xl:grid-cols-2">
          <Panel title="Create a course" subtitle="Examples: B.Tech, BCA, MCA">
            <form onSubmit={(e) => postForm(e, '/admin/courses', 'course', 'Course created.')} className="grid gap-3 sm:grid-cols-[1fr_130px_auto] sm:items-end">
              <Field label="Course name" placeholder="Bachelor of Technology" value={forms.course.name} onChange={(e) => setForm('course', { name: e.target.value })} required />
              <Field label="Course code" placeholder="BTECH" value={forms.course.code} onChange={(e) => setForm('course', { code: e.target.value })} required />
              <Button type="submit" loading={busy}><Plus size={15} /> Add</Button>
            </form>
          </Panel>
          <Panel title="Create a branch" subtitle="Branches are linked to their parent course">
            <form onSubmit={(e) => postForm(e, '/admin/branches', 'branch', 'Branch created.')} className="grid gap-3 sm:grid-cols-2">
              <SelectField label="Parent course" options={courseOptions} value={forms.branch.course_id} onChange={(e) => setForm('branch', { course_id: e.target.value })} required />
              <Field label="Branch name" placeholder="Computer Science & Engineering" value={forms.branch.name} onChange={(e) => setForm('branch', { name: e.target.value })} required />
              <Field label="Branch code" placeholder="CSE" value={forms.branch.code} onChange={(e) => setForm('branch', { code: e.target.value })} required />
              <div className="flex items-end"><Button type="submit" loading={busy}><Plus size={15} /> Add branch</Button></div>
            </form>
          </Panel>
          <Panel title="Create a subject" subtitle="A subject code must be unique across the university">
            <form onSubmit={(e) => postForm(e, '/admin/subjects', 'subject', 'Subject created.')} className="grid gap-3 sm:grid-cols-[120px_1fr_100px_auto] sm:items-end">
              <Field label="Subject code" placeholder="CS501" value={forms.subject.code} onChange={(e) => setForm('subject', { code: e.target.value })} required />
              <Field label="Subject name" placeholder="Operating Systems" value={forms.subject.name} onChange={(e) => setForm('subject', { name: e.target.value })} required />
              <Field label="Credits" type="number" min="0.5" max="10" step="0.5" value={forms.subject.credits} onChange={(e) => setForm('subject', { credits: e.target.value })} />
              <Button type="submit" loading={busy}><Plus size={15} /> Add</Button>
            </form>
          </Panel>
          <Panel title="Offer a subject to a batch" subtitle="Students only see offerings matching their course, branch, year and semester">
            <form onSubmit={(e) => postForm(e, '/admin/offerings', 'offering', 'Subject offering created.')} className="grid gap-3 sm:grid-cols-2">
              <SelectField label="Subject" options={subjectOptions} value={forms.offering.subject_id} onChange={(e) => setForm('offering', { subject_id: e.target.value })} required />
              <SelectField label="Course" options={courseOptions} value={forms.offering.course_id} onChange={(e) => setForm('offering', { course_id: e.target.value })} required />
              <SelectField label="Branch" options={branchOptions} value={forms.offering.branch_id} onChange={(e) => setForm('offering', { branch_id: e.target.value })} required />
              <div className="grid grid-cols-2 gap-3">
                <Field label="Academic year" type="number" value={forms.offering.academic_year} onChange={(e) => setForm('offering', { academic_year: e.target.value })} required />
                <SelectField label="Semester" options={Array.from({ length: 12 }, (_, i) => ({ value: i + 1, label: `Sem ${i + 1}` }))} value={forms.offering.semester} onChange={(e) => setForm('offering', { semester: e.target.value })} required />
              </div>
              <div className="sm:col-span-2"><Button type="submit" loading={busy}><Plus size={15} /> Create offering</Button></div>
            </form>
          </Panel>
        </div>
        <div className="mt-5 grid gap-5 xl:grid-cols-2">
          <Panel title={`Courses & branches (${data.courses.length} / ${data.branches.length})`}><Table columns={[{ key: 'name', label: 'Course' }, { key: 'code', label: 'Code' }]} rows={data.courses} /></Panel>
          <Panel title={`Subjects (${data.subjects.length})`}><Table columns={[{ key: 'code', label: 'Code' }, { key: 'name', label: 'Subject' }, { key: 'credits', label: 'Credits' }]} rows={data.subjects} /></Panel>
        </div>
        <div className="mt-5"><Panel title={`Batch offerings (${data.offerings.length})`}><Table columns={[{ key: 'subject_code', label: 'Subject' }, { key: 'course_name', label: 'Course / branch', render: (r) => `${r.course_name} · ${r.branch_name}` }, { key: 'academic_year', label: 'Year' }, { key: 'semester', label: 'Semester' }, { key: 'enrolled_count', label: 'Enrolled' }]} rows={data.offerings} /></Panel></div>
      </>;
      case 'students': return <>
        <PageTitle eyebrow="Student records" title="Registered students" subtitle="Review student accounts, academic batches and subject enrollment counts." action={<Button variant="secondary" onClick={loadAll}><RefreshCw size={15} /> Refresh</Button>} />
        <Panel title={`Student directory · ${data.students.length}`}>
          <Table columns={[{ key: 'name', label: 'Student' }, { key: 'email', label: 'Email' }, { key: 'roll_number', label: 'Roll number' }, { key: 'course_name', label: 'Academic batch', render: (r) => `${r.course_name} · ${r.branch_name}` }, { key: 'academic_year', label: 'Year' }, { key: 'semester', label: 'Semester' }, { key: 'enrolled_subjects', label: 'Subjects' }]} rows={data.students} />
        </Panel>
      </>;
      case 'rooms': return <>
        <PageTitle eyebrow="Facilities" title="Examination rooms" subtitle="Register rooms and their seating capacity. The scheduler never places more enrolled students than a room can hold." />
        <Panel title="Add an examination room" subtitle="Use a clear room name that students and invigilators can recognize">
          <form onSubmit={(e) => postForm(e, '/admin/rooms', 'room', 'Room added.')} className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4 xl:items-end">
            <Field label="Room name" placeholder="Block A · 201" value={forms.room.name} onChange={(e) => setForm('room', { name: e.target.value })} required />
            <Field label="Building / block" placeholder="Academic Block A" value={forms.room.building} onChange={(e) => setForm('room', { building: e.target.value })} />
            <Field label="Seating capacity" type="number" min="1" value={forms.room.capacity} onChange={(e) => setForm('room', { capacity: e.target.value })} required />
            <div className="flex items-end gap-3"><SelectField label="Room type" className="min-w-0 flex-1" options={['Classroom', 'Lab', 'Auditorium', 'Other'].map((x) => ({ value: x, label: x }))} value={forms.room.room_type} onChange={(e) => setForm('room', { room_type: e.target.value })} /><Button type="submit" loading={busy}><Plus size={15} /> Add</Button></div>
          </form>
        </Panel>
        <div className="mt-5"><Panel title={`Registered rooms · ${data.rooms.length}`}><Table columns={[{ key: 'name', label: 'Room' }, { key: 'building', label: 'Building' }, { key: 'room_type', label: 'Type' }, { key: 'capacity', label: 'Capacity' }]} rows={data.rooms} /></Panel></div>
      </>;
      case 'sessions': return <>
        <PageTitle eyebrow="Examination setup" title="Sessions & examinations" subtitle="Create a timetable window, then add subject offerings as examination tasks in that session." />
        <Panel title="Create an examination session" subtitle="The time window is used by the scheduling engine when searching for examination slots">
          <form onSubmit={(e) => postForm(e, '/admin/sessions', 'session', 'Examination session created.')} className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            <Field label="Session name" placeholder="End Semester Examination · Dec 2026" value={forms.session.name} onChange={(e) => setForm('session', { name: e.target.value })} required />
            <Field label="Start date" type="date" value={forms.session.start_date} onChange={(e) => setForm('session', { start_date: e.target.value })} required />
            <Field label="End date" type="date" value={forms.session.end_date} onChange={(e) => setForm('session', { end_date: e.target.value })} required />
            <Field label="Daily start time" type="time" value={forms.session.day_start_time} onChange={(e) => setForm('session', { day_start_time: e.target.value })} required />
            <Field label="Daily closing time" type="time" value={forms.session.day_end_time} onChange={(e) => setForm('session', { day_end_time: e.target.value })} required />
            <div className="flex items-end"><Button type="submit" loading={busy}><Plus size={15} /> Create session</Button></div>
          </form>
        </Panel>
        <div className="mt-5 grid gap-5 xl:grid-cols-[.85fr_1.15fr]">
          <Panel title="Add an examination" subtitle="Each offering can appear once in a session">
            <form onSubmit={(e) => postForm(e, '/admin/exams', 'exam', 'Examination added to session.')} className="space-y-3">
              <SelectField label="Examination session" options={sessionOptions.filter((item) => !data.sessions.find((s) => String(s.id) === String(item.value))?.status || data.sessions.find((s) => String(s.id) === String(item.value))?.status === 'draft')} value={forms.exam.session_id} onChange={(e) => setForm('exam', { session_id: e.target.value })} required />
              <SelectField label="Subject offering" options={offeringOptions} value={forms.exam.offering_id} onChange={(e) => setForm('exam', { offering_id: e.target.value })} required />
              <div className="grid grid-cols-2 gap-3">
                <Field label="Duration (minutes)" type="number" min="30" max="480" step="30" value={forms.exam.duration_minutes} onChange={(e) => setForm('exam', { duration_minutes: e.target.value })} required />
                <SelectField label="Priority (1–5)" options={[1, 2, 3, 4, 5].map((n) => ({ value: n, label: `Priority ${n}` }))} value={forms.exam.priority} onChange={(e) => setForm('exam', { priority: e.target.value })} required />
              </div>
              <Button type="submit" loading={busy}><Plus size={15} /> Add examination</Button>
            </form>
          </Panel>
          <Panel title={`Examination sessions · ${data.sessions.length}`} subtitle="Published sessions are locked; draft sessions can be regenerated">
            <Table columns={[{ key: 'name', label: 'Session' }, { key: 'start_date', label: 'Date window', render: (r) => `${String(r.start_date).slice(0, 10)} → ${String(r.end_date).slice(0, 10)}` }, { key: 'exam_count', label: 'Exams' }, { key: 'status', label: 'Status', render: (r) => <StatusPill tone={r.status === 'published' ? 'success' : 'warning'}>{r.status}</StatusPill> }]} rows={data.sessions} />
          </Panel>
        </div>
      </>;
      case 'schedule': return <>
        <PageTitle eyebrow="Operating systems · scheduling" title="Timetable builder" subtitle="Generate with FCFS or Priority Scheduling, inspect allocations, make draft changes, and publish the final timetable." />
        <Panel title="Scheduling controls" subtitle="The engine checks enrolled student conflicts, room capacity and clashes, and approved teacher availability.">
          <div className="grid gap-4 md:grid-cols-[1fr_220px_auto] md:items-end">
            <SelectField label="Examination session" options={sessionOptions} value={selectedSession} onChange={(e) => { setSelectedSession(e.target.value); setEditing(null); }} />
            <SelectField label="OS scheduling algorithm" options={[{ value: 'FCFS', label: 'FCFS · First Come First Serve' }, { value: 'PRIORITY', label: 'Priority Scheduling' }]} value={algorithm} onChange={(e) => setAlgorithm(e.target.value)} />
            <Button onClick={generate} loading={busy} disabled={!selectedSession || data.sessions.find((s) => String(s.id) === String(selectedSession))?.status === 'published'}><WandSparkles size={16} /> Generate timetable</Button>
          </div>
          {selectedSession && data.sessions.find((s) => String(s.id) === String(selectedSession))?.status === 'published' && <p className="mt-3 text-xs font-semibold text-teal-700">This timetable is published and locked. It is visible in the student and teacher portals.</p>}
        </Panel>
        {scheduleData && <div className="mt-5 space-y-5">
          <div className="grid gap-4 sm:grid-cols-3">
            <StatCard label="Examinations" value={scheduleData.totalExams} icon={ClipboardList} />
            <StatCard label="Scheduled" value={scheduleData.schedule.length} icon={Check} tint="teal" />
            <StatCard label="Unscheduled" value={scheduleData.unscheduledCount} icon={Activity} tint="amber" />
          </div>
          <Panel title={scheduleData.session.name} subtitle={`Schedule for ${String(scheduleData.session.start_date).slice(0, 10)} through ${String(scheduleData.session.end_date).slice(0, 10)}`} action={scheduleData.session.status === 'published' ? <StatusPill tone="success">Published</StatusPill> : <div className="flex flex-wrap gap-2">{scheduleData.schedule.length > 0 && <Button variant="secondary" onClick={() => runAction(async () => { const { data: response } = await api.post(`/admin/sessions/${selectedSession}/reset`); const { data: refreshed } = await api.get(`/admin/sessions/${selectedSession}/schedule`); setScheduleData(refreshed); setNotice({ type: 'success', text: response.message }); })} loading={busy}>Clear draft</Button>}<Button onClick={publish} loading={busy} disabled={!scheduleData.totalExams || scheduleData.unscheduledCount > 0} ><ShieldCheck size={15} /> Publish timetable</Button></div>}>
            <Table columns={[{ key: 'exam_date', label: 'Date' }, { key: 'start_time', label: 'Time' }, { key: 'subject_code', label: 'Subject' }, { key: 'room_name', label: 'Room' }, { key: 'teacher_name', label: 'Invigilator' }, { key: 'student_count', label: 'Students' }, { key: 'actions', label: 'Action' }]} rows={scheduleData.schedule} renderRow={(row) => <tr key={row.id}>
              <td>{String(row.exam_date).slice(0, 10)}</td><td className="whitespace-nowrap">{String(row.start_time).slice(0, 5)}–{String(row.end_time).slice(0, 5)}</td>
              <td><span className="font-extrabold text-ink">{row.subject_code}</span><span className="mt-0.5 block text-[11px] text-slate-400">{row.subject_name}</span></td><td>{row.room_name}</td><td>{row.teacher_name}</td><td>{row.student_count}</td>
              <td>{scheduleData.session.status === 'draft' ? <button className="text-xs font-extrabold text-brand hover:underline" onClick={() => setEditing({ id: row.id, exam_date: String(row.exam_date).slice(0, 10), start_time: String(row.start_time).slice(0, 5), room_id: String(row.room_id), teacher_id: String(row.teacher_id) })}>Edit</button> : <StatusPill tone="success">Locked</StatusPill>}</td>
            </tr>} />
            {editing && <div className="mt-5 rounded-2xl border border-brand/20 bg-brand-soft/40 p-4">
              <div className="mb-3 flex items-center justify-between"><p className="text-sm font-extrabold text-ink">Edit timetable allocation</p><button onClick={() => setEditing(null)} className="text-slate-500"><X size={17} /></button></div>
              <form onSubmit={saveEdit} className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <Field label="Exam date" type="date" value={editing.exam_date} onChange={(e) => setEditing({ ...editing, exam_date: e.target.value })} required />
                <Field label="Start time" type="time" value={editing.start_time} onChange={(e) => setEditing({ ...editing, start_time: e.target.value })} required />
                <SelectField label="Room" options={data.rooms.map((r) => ({ value: r.id, label: `${r.name} · ${r.capacity} seats` }))} value={editing.room_id} onChange={(e) => setEditing({ ...editing, room_id: e.target.value })} required />
                <SelectField label="Invigilator" options={approvedTeachers} value={editing.teacher_id} onChange={(e) => setEditing({ ...editing, teacher_id: e.target.value })} required />
                <div className="sm:col-span-2 xl:col-span-4"><Button type="submit" loading={busy}>Save allocation</Button></div>
              </form>
            </div>}
          </Panel>
          {scheduleData.unscheduledCount > 0 && <Panel title={`Examinations needing attention · ${scheduleData.unscheduledCount}`} subtitle="Resolve the issue, then run the scheduler again.">
            <Table columns={[{ key: 'subject_code', label: 'Subject' }, { key: 'subject_name', label: 'Examination' }, { key: 'student_count', label: 'Enrolled students' }, { key: 'reason', label: 'Next step' }]} rows={scheduleData.unscheduled.map((item) => ({ ...item, reason: Number(item.student_count) === 0 ? 'Enroll students in this offering first.' : 'Check available rooms, approved teachers, availability and session time window.' }))} />
          </Panel>}
        </div>}
      </>;
      case 'teachers': return <>
        <PageTitle eyebrow="Faculty management" title="Teacher approvals" subtitle="Teacher registrations remain pending until an administrator approves them. Only approved teachers can submit availability and receive invigilation assignments." />
        <Panel title={`Registered teachers · ${data.teachers.length}`}>
          <Table columns={[{ key: 'name', label: 'Teacher' }, { key: 'email', label: 'Email' }, { key: 'department', label: 'Department' }, { key: 'employee_code', label: 'Employee code' }, { key: 'status', label: 'Status' }, { key: 'actions', label: 'Actions' }]} rows={data.teachers} renderRow={(row) => <tr key={row.teacher_id}>
            <td className="font-bold text-ink">{row.name}</td><td>{row.email}</td><td>{row.department}</td><td>{row.employee_code || '—'}</td>
            <td><StatusPill tone={row.status === 'active' ? 'success' : row.status === 'pending' ? 'warning' : 'danger'}>{row.status}</StatusPill></td>
            <td>{row.status === 'pending' ? <div className="flex gap-2"><button onClick={() => approveTeacher(row.teacher_id, 'active')} className="rounded-lg bg-teal-soft p-2 text-teal-700 hover:bg-teal-100" title="Approve"><Check size={15} /></button><button onClick={() => approveTeacher(row.teacher_id, 'rejected')} className="rounded-lg bg-rose-50 p-2 text-rose-600 hover:bg-rose-100" title="Reject"><X size={15} /></button></div> : <span className="text-xs text-slate-400">No action</span>}</td>
          </tr>} />
        </Panel>
      </>;
      default: return <>
        <PageTitle eyebrow="Administrator workspace" title="Good day, administrator." subtitle="Your central view of academic setup, examination planning, and timetable operations." action={<Button variant="secondary" onClick={loadAll}><RefreshCw size={15} /> Refresh</Button>} />
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard label="Active students" value={data.overview?.students ?? '—'} icon={GraduationCap} />
          <StatCard label="Approved teachers" value={data.overview?.teachers ?? '—'} icon={Users} tint="teal" />
          <StatCard label="Pending approvals" value={data.overview?.pendingTeachers ?? '—'} icon={ShieldCheck} tint="amber" />
          <StatCard label="Subjects" value={data.overview?.subjects ?? '—'} icon={BookOpen} tint="violet" />
          <StatCard label="Examination rooms" value={data.overview?.rooms ?? '—'} icon={Building2} />
          <StatCard label="Exam sessions" value={data.overview?.sessions ?? '—'} icon={CalendarDays} tint="teal" />
          <StatCard label="Examinations" value={data.overview?.exams ?? '—'} icon={ClipboardList} tint="violet" />
          <StatCard label="Scheduled exams" value={data.overview?.scheduled ?? '—'} icon={CalendarClock} tint="amber" />
        </div>
        <div className="mt-6 grid gap-5 xl:grid-cols-[1.25fr_.75fr]">
          <Panel title="Recent examination sessions" subtitle="Track the status of your most recent timetable windows">
            <Table columns={[{ key: 'name', label: 'Session' }, { key: 'start_date', label: 'Starts' }, { key: 'exam_count', label: 'Exams' }, { key: 'status', label: 'Status' }]} rows={data.overview?.recentSessions || []} />
          </Panel>
          <Panel title="Quick actions" subtitle="Jump into the key steps of your workflow">
            <div className="space-y-2">
              {[
                ['academic','Set up academic structure','Create courses, branches and subjects',BookOpen],
                ['rooms','Register examination rooms','Enter room capacity and building details',Building2],
                ['sessions','Create exam session','Define the timetable date and time window',CalendarDays],
                ['schedule','Build a timetable','Run FCFS or Priority scheduling',WandSparkles]
              ].map(([id,label,description,Icon]) => <button key={id} onClick={() => setActive(id)} className="flex w-full items-center gap-3 rounded-xl border border-slate-100 p-3 text-left transition hover:border-brand/20 hover:bg-brand-soft/40">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-soft text-brand"><Icon size={17} /></span><span className="min-w-0 flex-1"><span className="block text-xs font-extrabold text-ink">{label}</span><span className="mt-0.5 block text-[10px] text-slate-400">{description}</span></span><ChevronRight size={16} className="text-slate-300" />
              </button>)}
            </div>
          </Panel>
        </div>
      </>;
    }
  }, [active, data, forms, busy, selectedSession, algorithm, scheduleData, editing, approvedTeachers, sessionOptions, courseOptions, branchOptions, subjectOptions, offeringOptions]);

  return <AppShell navigation={nav} active={active} onNavigate={(id) => { setActive(id); setNotice(null); }} title={nav.find((x) => x.id === active)?.label}>
    {notice && <Notice type={notice.type} onClose={() => setNotice(null)}>{notice.text}</Notice>}
    {page}
  </AppShell>;
}
