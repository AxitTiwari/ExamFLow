import { useEffect, useState } from 'react';
import { BookOpen, CalendarDays, GraduationCap, MapPin, RefreshCw, UserRound } from 'lucide-react';
import AppShell from '../components/AppShell';
import { Button, EmptyState, Notice, PageTitle, Panel, StatusPill, Table } from '../components/shared';
import api, { messageFromError } from '../lib/api';
import { useAuth } from '../context/AuthContext';

const nav = [
  { id: 'subjects', label: 'My subjects', icon: BookOpen },
  { id: 'timetable', label: 'Exam timetable', icon: CalendarDays },
  { id: 'profile', label: 'My profile', icon: UserRound }
];

export default function StudentPortal() {
  const { user } = useAuth();
  const [active, setActive] = useState('subjects');
  const [offerings, setOfferings] = useState([]);
  const [schedule, setSchedule] = useState([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState(null);

  const load = async () => {
    const [subjectResult, scheduleResult] = await Promise.allSettled([api.get('/student/offerings'), api.get('/student/timetable')]);
    if (subjectResult.status === 'fulfilled') setOfferings(subjectResult.value.data.offerings);
    if (scheduleResult.status === 'fulfilled') setSchedule(scheduleResult.value.data.schedule);
    const failed = [subjectResult, scheduleResult].find((x) => x.status === 'rejected');
    if (failed) setNotice({ type: 'error', text: messageFromError(failed.reason) });
  };
  useEffect(() => { load(); }, []);

  const toggleEnrollment = async (offering) => {
    setBusy(true); setNotice(null);
    try {
      const response = offering.enrolled
        ? await api.delete(`/student/enrollments/${offering.offering_id}`)
        : await api.post(`/student/enrollments/${offering.offering_id}`);
      setNotice({ type: 'success', text: response.data.message });
      await load();
    } catch (error) { setNotice({ type: 'error', text: messageFromError(error) }); }
    finally { setBusy(false); }
  };

  const page = active === 'timetable' ? <>
    <PageTitle eyebrow="Published examination plan" title="Your exam timetable" subtitle="Only examinations from published sessions appear here. Check the date, timing and room before exam day." action={<Button variant="secondary" onClick={load}><RefreshCw size={15} /> Refresh</Button>} />
    <Panel title={`Upcoming examinations · ${schedule.length}`} subtitle="Your enrolled subjects, arranged chronologically">
      <Table columns={[{ key: 'exam_date', label: 'Date' }, { key: 'start_time', label: 'Timing' }, { key: 'subject_code', label: 'Subject' }, { key: 'session_name', label: 'Session' }, { key: 'room_name', label: 'Room / building' }]} rows={schedule} renderRow={(row) => <tr key={row.id}>
        <td><span className="font-extrabold text-ink">{String(row.exam_date).slice(0, 10)}</span></td><td className="whitespace-nowrap">{String(row.start_time).slice(0, 5)} – {String(row.end_time).slice(0, 5)}</td>
        <td><span className="font-extrabold text-ink">{row.subject_code}</span><span className="mt-0.5 block text-[11px] text-slate-400">{row.subject_name}</span></td><td>{row.session_name}</td><td><span className="font-bold text-ink">{row.room_name}</span><span className="mt-0.5 block text-[11px] text-slate-400">{row.building || 'Building not specified'}</span></td>
      </tr>} emptyTitle="Your published timetable is not available yet" emptyDetail="Enroll in your subjects and check back after the university publishes the examination timetable." />
    </Panel>
  </> : active === 'profile' ? <>
    <PageTitle eyebrow="Account details" title="My student profile" subtitle="Your academic details determine which subject offerings are available to you." />
    <div className="grid gap-5 md:grid-cols-[.7fr_1.3fr]">
      <Panel title="Student account"><div className="flex items-center gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-soft text-brand"><GraduationCap size={23} /></span><div><p className="font-extrabold text-ink">{user?.name}</p><p className="text-xs text-slate-400">{user?.email}</p></div></div><div className="mt-5 border-t border-slate-100 pt-4"><StatusPill tone="success">Active account</StatusPill></div></Panel>
      <Panel title="Academic information"><div className="grid gap-4 sm:grid-cols-2">
        {[['Course',user?.profile?.course_name],['Branch',user?.profile?.branch_name],['Academic year',user?.profile?.academic_year],['Semester',user?.profile?.semester],['Roll number',user?.profile?.roll_number || 'Not provided']].map(([label,value]) => <div key={label}><p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">{label}</p><p className="mt-1 text-sm font-bold text-ink">{value || '—'}</p></div>)}
      </div></Panel>
    </div>
  </> : <>
    <PageTitle eyebrow="Student workspace" title={`Welcome, ${user?.name?.split(' ')[0] || 'student'}.`} subtitle="Review the subjects assigned to your academic batch and enroll before the examination timetable is published." action={<Button variant="secondary" onClick={load}><RefreshCw size={15} /> Refresh</Button>} />
    <div className="mb-5 grid gap-4 sm:grid-cols-3">
      <div className="card p-5"><p className="text-xs font-bold text-slate-500">Eligible subjects</p><p className="mt-2 font-display text-3xl font-extrabold text-ink">{offerings.length}</p></div>
      <div className="card p-5"><p className="text-xs font-bold text-slate-500">Enrolled subjects</p><p className="mt-2 font-display text-3xl font-extrabold text-ink">{offerings.filter((x) => x.enrolled).length}</p></div>
      <div className="card p-5"><p className="text-xs font-bold text-slate-500">Published exams</p><p className="mt-2 font-display text-3xl font-extrabold text-ink">{schedule.length}</p></div>
    </div>
    <Panel title="Subject enrollment" subtitle="Only subjects matching your course, branch, academic year and semester are displayed.">
      {!offerings.length ? <EmptyState title="No subjects assigned to your batch yet" detail="Your administrator needs to create subject offerings for your exact academic batch before you can enroll." /> : <div className="grid gap-3 md:grid-cols-2">
        {offerings.map((offering) => <div key={offering.offering_id} className="rounded-2xl border border-slate-100 p-4 transition hover:border-brand/20 hover:shadow-sm">
          <div className="flex items-start justify-between gap-3"><span className="rounded-lg bg-brand-soft px-2.5 py-1 text-[11px] font-extrabold text-brand">{offering.code}</span><span className="text-[10px] font-bold text-slate-400">{offering.credits} credits</span></div>
          <h3 className="mt-3 font-display text-base font-extrabold text-ink">{offering.name}</h3>
          <p className="mt-1 text-[11px] text-slate-400">{offering.course_name} · {offering.branch_name} · Semester {offering.semester}</p>
          <div className="mt-4 flex items-center justify-between gap-3"><StatusPill tone={offering.published ? 'success' : offering.enrolled ? 'brand' : 'neutral'}>{offering.published ? 'Timetable published' : offering.enrolled ? 'Enrolled' : 'Not enrolled'}</StatusPill>
            {!offering.published && <Button variant={offering.enrolled ? 'secondary' : 'primary'} className="px-3 py-2 text-xs" onClick={() => toggleEnrollment(offering)} loading={busy}>{offering.enrolled ? 'Withdraw' : 'Enroll'}</Button>}
          </div>
        </div>)}
      </div>}
    </Panel>
    {schedule.length > 0 && <div className="mt-5"><Panel title="Next published examinations" action={<button onClick={() => setActive('timetable')} className="text-xs font-extrabold text-brand">View full timetable →</button>}><div className="space-y-3">{schedule.slice(0, 3).map((item) => <div key={item.id} className="flex items-center gap-3 rounded-xl bg-slate-50 p-3"><div className="grid h-11 w-11 place-items-center rounded-xl bg-white text-center"><CalendarDays size={16} className="mx-auto text-brand" /><span className="text-[9px] font-extrabold text-slate-500">{String(item.exam_date).slice(8,10)}</span></div><div className="min-w-0 flex-1"><p className="truncate text-xs font-extrabold text-ink">{item.subject_code} · {item.subject_name}</p><p className="mt-1 text-[10px] text-slate-400">{String(item.exam_date).slice(0,10)} · {String(item.start_time).slice(0,5)} · {item.room_name}</p></div><MapPin size={15} className="text-slate-300" /></div>)}</div></Panel></div>}
  </>;

  return <AppShell navigation={nav} active={active} onNavigate={(id) => { setActive(id); setNotice(null); }} title={nav.find((x) => x.id === active)?.label}>
    {notice && <Notice type={notice.type} onClose={() => setNotice(null)}>{notice.text}</Notice>}{page}
  </AppShell>;
}
