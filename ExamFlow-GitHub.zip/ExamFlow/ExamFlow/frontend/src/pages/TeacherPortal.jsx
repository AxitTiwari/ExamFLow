import { useEffect, useState } from 'react';
import { CalendarClock, CalendarDays, Clock3, Plus, RefreshCw, Trash2, UserRound } from 'lucide-react';
import AppShell from '../components/AppShell';
import { Button, EmptyState, Field, Notice, PageTitle, Panel, SelectField, Table } from '../components/shared';
import api, { messageFromError } from '../lib/api';
import { useAuth } from '../context/AuthContext';

const nav = [
  { id: 'availability', label: 'My availability', icon: Clock3 },
  { id: 'duties', label: 'Invigilation duties', icon: CalendarDays },
  { id: 'profile', label: 'My profile', icon: UserRound }
];
const weekdays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

export default function TeacherPortal() {
  const { user } = useAuth();
  const [active, setActive] = useState('availability');
  const [mode, setMode] = useState('weekly');
  const [form, setForm] = useState({ weekday: '1', available_date: '', start_time: '09:00', end_time: '17:00' });
  const [availability, setAvailability] = useState([]);
  const [duties, setDuties] = useState([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState(null);

  const load = async () => {
    const [a, d] = await Promise.allSettled([api.get('/teacher/availability'), api.get('/teacher/duties')]);
    if (a.status === 'fulfilled') setAvailability(a.value.data.availability);
    if (d.status === 'fulfilled') setDuties(d.value.data.duties);
    const failed = [a,d].find((x) => x.status === 'rejected');
    if (failed) setNotice({ type: 'error', text: messageFromError(failed.reason) });
  };
  useEffect(() => { load(); }, []);

  const addAvailability = async (event) => {
    event.preventDefault(); setBusy(true); setNotice(null);
    try {
      const payload = { start_time: form.start_time, end_time: form.end_time, weekday: mode === 'weekly' ? form.weekday : null, available_date: mode === 'date' ? form.available_date : null };
      const { data } = await api.post('/teacher/availability', payload);
      setNotice({ type: 'success', text: data.message }); setForm({ ...form, available_date: '' }); await load();
    } catch (error) { setNotice({ type: 'error', text: messageFromError(error) }); }
    finally { setBusy(false); }
  };

  const removeAvailability = async (id) => {
    setBusy(true); setNotice(null);
    try { const { data } = await api.delete(`/teacher/availability/${id}`); setNotice({ type: 'success', text: data.message }); await load(); }
    catch (error) { setNotice({ type: 'error', text: messageFromError(error) }); }
    finally { setBusy(false); }
  };

  const page = active === 'duties' ? <>
    <PageTitle eyebrow="Faculty schedule" title="Invigilation duties" subtitle="Your assigned examinations will appear here once the administrator publishes the timetable." action={<Button variant="secondary" onClick={load}><RefreshCw size={15} /> Refresh</Button>} />
    <Panel title={`Published assignments · ${duties.length}`} subtitle="Date, duty timing, examination room and subject details">
      <Table columns={[{ key: 'exam_date', label: 'Date' }, { key: 'start_time', label: 'Timing' }, { key: 'subject_code', label: 'Subject' }, { key: 'session_name', label: 'Session' }, { key: 'room_name', label: 'Assigned room' }]} rows={duties} renderRow={(row) => <tr key={row.id}>
        <td className="font-extrabold text-ink">{String(row.exam_date).slice(0,10)}</td><td className="whitespace-nowrap">{String(row.start_time).slice(0,5)}–{String(row.end_time).slice(0,5)}</td>
        <td><span className="font-extrabold text-ink">{row.subject_code}</span><span className="mt-0.5 block text-[11px] text-slate-400">{row.subject_name}</span></td><td>{row.session_name}</td><td>{row.room_name}<span className="mt-0.5 block text-[11px] text-slate-400">{row.building || 'Building not specified'}</span></td>
      </tr>} emptyTitle="No invigilation duties published yet" emptyDetail="Make sure your availability is up to date. The administrator will assign duties when the exam timetable is generated." />
    </Panel>
  </> : active === 'profile' ? <>
    <PageTitle eyebrow="Account details" title="My teacher profile" subtitle="Your approved faculty account details." />
    <Panel title="Teacher account"><div className="flex items-center gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-soft text-brand"><UserRound size={22} /></span><div><p className="font-extrabold text-ink">{user?.name}</p><p className="text-xs text-slate-400">{user?.email}</p></div></div><div className="mt-5 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-4"><span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Account role</span><span className="rounded-full bg-teal-soft px-2.5 py-1 text-[11px] font-bold text-teal-700">Approved teacher</span></div><div className="mt-4"><p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Department</p><p className="mt-1 text-sm font-bold text-ink">{user?.profile?.department || '—'}</p></div></Panel>
  </> : <>
    <PageTitle eyebrow="Faculty workspace" title={`Welcome, ${user?.name?.split(' ')[0] || 'teacher'}.`} subtitle="Set your available days and times so the examination scheduler can assign invigilation duties without conflicts." action={<Button variant="secondary" onClick={load}><RefreshCw size={15} /> Refresh</Button>} />
    <div className="mb-5 grid gap-4 sm:grid-cols-2"><div className="card p-5"><p className="text-xs font-bold text-slate-500">Availability entries</p><p className="mt-2 font-display text-3xl font-extrabold text-ink">{availability.length}</p></div><div className="card p-5"><p className="text-xs font-bold text-slate-500">Published duties</p><p className="mt-2 font-display text-3xl font-extrabold text-ink">{duties.length}</p></div></div>
    <div className="grid gap-5 xl:grid-cols-[.85fr_1.15fr]">
      <Panel title="Add availability" subtitle="You can add a weekly recurring window or a one-time date. The scheduler respects both.">
        <div className="mb-4 grid grid-cols-2 gap-2 rounded-xl bg-slate-100 p-1"><button onClick={() => setMode('weekly')} className={`rounded-lg py-2.5 text-xs font-extrabold ${mode === 'weekly' ? 'bg-white text-ink shadow-sm' : 'text-slate-500'}`}>Weekly pattern</button><button onClick={() => setMode('date')} className={`rounded-lg py-2.5 text-xs font-extrabold ${mode === 'date' ? 'bg-white text-ink shadow-sm' : 'text-slate-500'}`}>Specific date</button></div>
        <form onSubmit={addAvailability} className="space-y-3">
          {mode === 'weekly' ? <SelectField label="Available weekday" options={weekdays.map((day, index) => ({ value: index, label: day }))} value={form.weekday} onChange={(e) => setForm({ ...form, weekday: e.target.value })} required /> : <Field label="Available date" type="date" value={form.available_date} onChange={(e) => setForm({ ...form, available_date: e.target.value })} required />}
          <div className="grid grid-cols-2 gap-3"><Field label="From" type="time" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} required /><Field label="Until" type="time" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} required /></div>
          <Button type="submit" loading={busy}><Plus size={15} /> Save availability</Button>
        </form>
      </Panel>
      <Panel title={`Saved availability · ${availability.length}`} subtitle="Remove entries that no longer reflect your availability.">
        {!availability.length ? <EmptyState title="No availability submitted" detail="Add at least one weekly availability window so the admin can assign invigilation duties." /> : <div className="space-y-2">{availability.map((item) => <div key={item.id} className="flex items-center gap-3 rounded-xl border border-slate-100 p-3">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-soft text-brand"><CalendarClock size={16} /></span>
          <div className="min-w-0 flex-1"><p className="text-xs font-extrabold text-ink">{item.available_date ? String(item.available_date).slice(0,10) : `Every ${weekdays[Number(item.weekday)]}`}</p><p className="mt-1 text-[11px] text-slate-400">{String(item.start_time).slice(0,5)} – {String(item.end_time).slice(0,5)}</p></div>
          <button onClick={() => removeAvailability(item.id)} disabled={busy} className="rounded-lg p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-600" title="Remove"><Trash2 size={15} /></button>
        </div>)}</div>}
      </Panel>
    </div>
    {duties.length > 0 && <div className="mt-5"><Panel title="Your next invigilation duties" action={<button onClick={() => setActive('duties')} className="text-xs font-extrabold text-brand">View all →</button>}><Table columns={[{ key: 'exam_date', label: 'Date' },{ key: 'start_time', label: 'Time' },{ key: 'subject_code', label: 'Subject' },{ key: 'room_name', label: 'Room' }]} rows={duties.slice(0,4)} /></Panel></div>}
  </>;

  return <AppShell navigation={nav} active={active} onNavigate={(id) => { setActive(id); setNotice(null); }} title={nav.find((x) => x.id === active)?.label}>
    {notice && <Notice type={notice.type} onClose={() => setNotice(null)}>{notice.text}</Notice>}{page}
  </AppShell>;
}
