import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import api from '../lib/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState(() => localStorage.getItem('examflow_token'));

  useEffect(() => {
    let active = true;
    if (!token) { setLoading(false); return () => { active = false; }; }
    api.get('/auth/me')
      .then(({ data }) => { if (active) setUser(data.user); })
      .catch(() => { localStorage.removeItem('examflow_token'); if (active) { setToken(null); setUser(null); } })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [token]);

  const login = async (credentials) => {
    const { data } = await api.post('/auth/login', credentials);
    localStorage.setItem('examflow_token', data.token);
    setToken(data.token);
    setUser(data.user);
    return data.user;
  };

  const registerStudent = async (payload) => {
    const { data } = await api.post('/auth/register/student', payload);
    localStorage.setItem('examflow_token', data.token);
    setToken(data.token);
    setUser(data.user);
    return data;
  };
  const registerTeacher = async (payload) => api.post('/auth/register/teacher', payload);
  const logout = () => {
    localStorage.removeItem('examflow_token');
    setToken(null);
    setUser(null);
  };

  const value = useMemo(() => ({ user, loading, login, logout, registerStudent, registerTeacher }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider');
  return value;
}
