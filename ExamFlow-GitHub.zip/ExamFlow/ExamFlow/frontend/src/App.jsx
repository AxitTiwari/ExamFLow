import { LoaderCircle } from 'lucide-react';
import { useAuth } from './context/AuthContext';
import AuthPage from './pages/AuthPage';
import AdminPortal from './pages/AdminPortal';
import StudentPortal from './pages/StudentPortal';
import TeacherPortal from './pages/TeacherPortal';

export default function App() {
  const { user, loading } = useAuth();
  if (loading) return <div className="grid min-h-screen place-items-center bg-canvas"><div className="flex items-center gap-3 text-sm font-bold text-slate-500"><LoaderCircle className="animate-spin text-brand" size={20} /> Loading ExamFlow...</div></div>;
  if (!user) return <AuthPage />;
  if (user.role === 'admin') return <AdminPortal />;
  if (user.role === 'student') return <StudentPortal />;
  if (user.role === 'teacher') return <TeacherPortal />;
  return <AuthPage />;
}
