import { BookOpenCheck, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function AppShell({ children, navigation, active, onNavigate, title }) {
  const { user, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const initials = (user?.name || 'U').split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase();
  const navigate = (id) => { onNavigate(id); setMobileOpen(false); };

  return <div className="min-h-screen bg-canvas lg:flex">
    <aside className={`fixed inset-y-0 left-0 z-40 flex w-[260px] flex-col bg-ink px-4 py-5 text-white transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex items-center gap-3 px-3 pb-8 pt-1">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand text-white"><BookOpenCheck size={21} /></span>
        <div><p className="font-display text-[17px] font-extrabold tracking-tight">ExamFlow</p><p className="text-[10px] font-bold uppercase tracking-[.17em] text-slate-400">Campus operations</p></div>
        <button className="ml-auto text-slate-400 lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close menu"><X size={19} /></button>
      </div>
      <p className="px-3 pb-3 text-[10px] font-extrabold uppercase tracking-[.16em] text-slate-500">Workspace</p>
      <nav className="space-y-1">
        {navigation.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => navigate(id)} className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-left text-sm font-semibold transition ${active === id ? 'bg-white/10 text-white shadow-inner' : 'text-slate-400 hover:bg-white/5 hover:text-slate-100'}`}>
          <Icon size={17} strokeWidth={active === id ? 2.3 : 1.8} /><span>{label}</span>{active === id && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-teal" />}
        </button>)}
      </nav>
      <div className="mt-auto rounded-2xl border border-white/10 bg-white/5 p-4">
        <p className="text-xs font-bold">Need a hand?</p><p className="mt-1 text-[11px] leading-5 text-slate-400">Keep your academic records up to date before generating a timetable.</p>
        <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full w-2/3 rounded-full bg-teal" /></div>
        <p className="mt-2 text-[10px] font-semibold text-slate-500">ExamFlow workspace</p>
      </div>
    </aside>
    {mobileOpen && <button className="fixed inset-0 z-30 bg-ink/40 lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation overlay" />}
    <div className="min-w-0 flex-1">
      <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-slate-100 bg-white/90 px-4 backdrop-blur sm:px-7">
        <div className="flex items-center gap-3"><button className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu size={19} /></button>
          <div><p className="text-[10px] font-bold uppercase tracking-[.16em] text-slate-400">{user?.role || 'portal'}</p><p className="font-display text-sm font-extrabold text-ink">{title || navigation.find((item) => item.id === active)?.label || 'Workspace'}</p></div>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden text-right sm:block"><p className="text-xs font-extrabold text-ink">{user?.name}</p><p className="text-[10px] capitalize text-slate-400">{user?.role} account</p></div>
          <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-soft text-xs font-extrabold text-brand">{initials}</span>
          <button onClick={logout} className="rounded-xl border border-slate-200 p-2 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600" title="Sign out"><LogOut size={16} /></button>
        </div>
      </header>
      <main className="mx-auto max-w-[1440px] p-4 sm:p-7 lg:p-8">{children}</main>
    </div>
  </div>;
}
