import { LoaderCircle, Inbox } from 'lucide-react';

export function Panel({ title, subtitle, action, children, className = '' }) {
  return <section className={`card ${className}`}>
    {(title || action) && <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 px-5 py-4 sm:px-6">
      <div>{title && <h2 className="font-display text-base font-extrabold text-ink">{title}</h2>}{subtitle && <p className="mt-1 text-xs text-muted">{subtitle}</p>}</div>
      {action}
    </div>}
    <div className="p-5 sm:p-6">{children}</div>
  </section>;
}

export function PageTitle({ eyebrow, title, subtitle, action }) {
  return <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
    <div>{eyebrow && <p className="mb-1 text-[11px] font-extrabold uppercase tracking-[.16em] text-brand">{eyebrow}</p>}
      <h1 className="font-display text-2xl font-extrabold tracking-tight text-ink sm:text-[28px]">{title}</h1>
      {subtitle && <p className="mt-1.5 max-w-2xl text-sm text-muted">{subtitle}</p>}
    </div>{action}
  </div>;
}

export function Button({ children, variant = 'primary', loading = false, disabled = false, className = '', ...props }) {
  const classes = variant === 'secondary' ? 'btn-secondary' : variant === 'danger' ? 'btn-danger' : 'btn-primary';
  return <button className={`${classes} ${className}`} disabled={loading || disabled} {...props}>
    {loading && <LoaderCircle size={15} className="animate-spin" />}{children}
  </button>;
}

export function Field({ label, hint, className = '', ...props }) {
  return <label className={`block ${className}`}>
    {label && <span className="field-label">{label}</span>}
    <input className="field" {...props} />
    {hint && <span className="mt-1 block text-[11px] text-slate-400">{hint}</span>}
  </label>;
}

export function SelectField({ label, options = [], placeholder = 'Select an option', className = '', ...props }) {
  return <label className={`block ${className}`}>
    {label && <span className="field-label">{label}</span>}
    <select className="field" {...props}>
      <option value="">{placeholder}</option>
      {options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
    </select>
  </label>;
}

export function Notice({ children, type = 'success', onClose }) {
  if (!children) return null;
  const palette = type === 'error' ? 'border-rose-100 bg-rose-50 text-rose-700' : type === 'info' ? 'border-blue-100 bg-blue-50 text-blue-700' : 'border-teal-100 bg-teal-soft text-teal-700';
  return <div className={`mb-4 flex items-start justify-between gap-3 rounded-xl border px-4 py-3 text-sm ${palette}`} role="status">
    <span>{children}</span>{onClose && <button onClick={onClose} className="font-bold opacity-70">×</button>}
  </div>;
}

export function StatusPill({ children, tone = 'neutral' }) {
  const palette = { success: 'bg-teal-soft text-teal-700', warning: 'bg-amber-50 text-amber-700', danger: 'bg-rose-50 text-rose-700', brand: 'bg-brand-soft text-brand', neutral: 'bg-slate-100 text-slate-600' };
  return <span className={`inline-flex whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-extrabold ${palette[tone] || palette.neutral}`}>{children}</span>;
}

export function EmptyState({ title = 'Nothing here yet', detail = 'Records will appear here after they are added.' }) {
  return <div className="flex flex-col items-center justify-center px-4 py-10 text-center">
    <span className="mb-3 grid h-11 w-11 place-items-center rounded-2xl bg-slate-100 text-slate-400"><Inbox size={19} /></span>
    <p className="text-sm font-bold text-slate-700">{title}</p><p className="mt-1 max-w-sm text-xs text-slate-400">{detail}</p>
  </div>;
}

export function Table({ columns, rows, emptyTitle, emptyDetail, renderRow }) {
  if (!rows?.length) return <EmptyState title={emptyTitle} detail={emptyDetail} />;
  return <div className="table-wrap"><table className="table">
    <thead><tr>{columns.map((column) => <th key={column.key}>{column.label}</th>)}</tr></thead>
    <tbody>{rows.map((row, index) => renderRow ? renderRow(row, index) : <tr key={row.id || index}>{columns.map((column) => <td key={column.key}>{column.render ? column.render(row) : row[column.key]}</td>)}</tr>)}</tbody>
  </table></div>;
}

export function StatCard({ label, value, icon: Icon, tint = 'brand', note }) {
  const styles = { brand: 'bg-brand-soft text-brand', teal: 'bg-teal-soft text-teal', amber: 'bg-amber-50 text-amber-600', violet: 'bg-violet-50 text-violet-600' };
  return <div className="card p-5">
    <div className="flex items-center justify-between"><span className="text-xs font-bold text-slate-500">{label}</span><span className={`grid h-9 w-9 place-items-center rounded-xl ${styles[tint]}`}><Icon size={17} /></span></div>
    <div className="mt-3 font-display text-3xl font-extrabold tracking-tight text-ink">{value ?? '—'}</div>
    {note && <p className="mt-1 text-[11px] text-slate-400">{note}</p>}
  </div>;
}
