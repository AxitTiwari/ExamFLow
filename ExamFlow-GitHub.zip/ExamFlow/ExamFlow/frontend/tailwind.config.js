/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#101a2e',
        muted: '#718096',
        canvas: '#f4f7fb',
        brand: { DEFAULT: '#4f63e8', dark: '#3d50d3', soft: '#edf0ff' },
        teal: { DEFAULT: '#18a999', soft: '#e5f8f5' }
      },
      boxShadow: { soft: '0 12px 35px rgba(18, 35, 67, 0.07)' }
    }
  },
  plugins: []
};
