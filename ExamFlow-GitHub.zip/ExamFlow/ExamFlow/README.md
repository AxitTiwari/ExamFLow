# ExamFlow — University Examination Timetable Management System

ExamFlow is a full-stack university examination management project built with **React, Tailwind CSS, Node.js, Express.js and MySQL 8**. It has separate administrator, student and teacher portals, secure role-based sign-in, relational academic records, and an examination scheduling engine implementing **FCFS** and **Priority Scheduling**.

The project focuses on working functionality and database integration. It is designed to run against a local MySQL server and does not require external APIs or hardware.

## 1. Technology stack

| Technology | Use in ExamFlow |
|---|---|
| HTML5, CSS3, JavaScript | Web structure, styling and application logic |
| React 18 | Interactive admin, student and teacher portals |
| Vite | Frontend development server and production build |
| Tailwind CSS | Responsive UI styling |
| Node.js | Backend JavaScript runtime |
| Express.js | REST API routes, validation and business logic |
| MySQL 8 + mysql2 | Relational storage, foreign keys, joins and transactions |
| JWT | Authenticated API sessions |
| bcryptjs | Password hashing using the bcrypt algorithm |
| Helmet, CORS, express-rate-limit | Basic HTTP security controls and login/API rate limiting |
| Git / VS Code | Suggested source control and development environment |

## 2. Project structure

```text
ExamFlow/
├── backend/
│   ├── src/
│   │   ├── config/       # environment variables and MySQL initialization
│   │   ├── middleware/   # JWT authentication and role authorization
│   │   ├── routes/       # auth, admin, student, teacher and public APIs
│   │   ├── services/     # FCFS / Priority scheduling engine
│   │   ├── utils/        # reusable validation and HTTP helpers
│   │   └── server.js
│   ├── test/             # scheduling unit tests
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/   # shared UI and application shell
│   │   ├── context/      # authentication state
│   │   ├── lib/          # API client
│   │   └── pages/        # login, admin, student and teacher portals
│   └── vite.config.js
├── docs/
└── README.md
```

## 3. Before you start

Install the following on your Windows computer:

- Node.js 20 or newer (Node.js 22 is suitable).
- MySQL Server 8.0 and a working local MySQL account.
- VS Code or another code editor.

Start your MySQL service before launching the backend. The project expects the local database account to be able to create a database and tables. The configured account is `root` by default, but it can be changed in the environment file.

## 4. Configure the database connection

1. Open the `ExamFlow` folder in VS Code.
2. Copy `backend/.env.example` and rename the copy to `backend/.env`.
3. Open `backend/.env` and set your own local MySQL password:

```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=YOUR_EXISTING_MYSQL_PASSWORD
DB_NAME=university_exam_scheduler
```

4. Change `ADMIN_PASSWORD` and `JWT_SECRET` in that same file before first use. Keep `.env` private and never commit it to GitHub.

### Database safety

On startup, the backend creates the database `university_exam_scheduler` if it does not exist, then creates the ExamFlow tables using the `efp_` prefix. It uses `CREATE TABLE IF NOT EXISTS`; it does **not** drop, rename or overwrite unrelated existing tables. Existing tables in the configured database are left in place.

The database is managed by the MySQL server. It is not a database file inside the React frontend. The Express backend connects to MySQL through a connection pool.

## 5. Install and run

Open a terminal in the top-level `ExamFlow` folder and run:

```bash
npm install
npm run install:all
npm run dev
```

This starts:

- Backend API: `http://localhost:5000`
- React frontend: `http://localhost:5173`
- Health check: `http://localhost:5000/api/health`

Open `http://localhost:5173` in your browser.

If you prefer separate terminals:

```bash
# Terminal 1 — backend
cd backend
npm install
npm run dev

# Terminal 2 — frontend
cd frontend
npm install
npm run dev
```

## 6. First login and recommended setup sequence

### Administrator

The first administrator is seeded automatically when the backend starts. The starter values in `.env.example` are `admin@examflow.local` and `ChangeThisAdminPassword123!`; change `ADMIN_PASSWORD` before first use and keep the value private. Admin registration is intentionally not available on the public registration page.

Sign in as administrator and complete the following sequence:

1. **Academic setup:** create courses, branches and subjects.
2. **Batch offerings:** connect each subject to a course, branch, academic year and semester.
3. **Examination rooms:** add rooms and their actual seating capacities.
4. **Teacher approvals:** ask teachers to register, then approve their accounts.
5. **Teacher availability:** approved teachers sign in and submit weekly or date-specific availability.
6. **Sessions & exams:** create the examination window and add subject offerings as exams, with duration and priority.
7. **Timetable builder:** choose FCFS or Priority Scheduling, generate the draft, review or edit allocations, then publish.

### Students

Students register from the sign-in screen using their course, branch, academic year and semester. They can enroll only in offerings assigned to that exact academic batch. They can view examination dates and room allocations after the administrator publishes the timetable.

### Teachers

Teachers register from the sign-in screen. Their accounts remain pending until approved by an administrator. After approval, teachers can sign in, submit recurring weekly availability or date-specific availability, and view their published invigilation duties.

## 7. Scheduling engine and constraints

The scheduler first orders the exams:

- **FCFS:** earlier-created examination tasks are considered first.
- **Priority Scheduling:** higher priority values are considered first; FCFS order breaks ties.

For each examination, the engine searches the session's dates and daily window in 30-minute increments. A candidate allocation is accepted only when:

1. Students enrolled in the exam do not have another examination overlapping that time.
2. The selected room has enough seats for all enrolled students.
3. The room is not assigned to another overlapping examination.
4. The selected teacher is approved, has matching availability, and has no overlapping invigilation assignment.

The scheduler uses a practical greedy allocation strategy. It does not claim to find a mathematically optimal timetable for every possible input. Examinations that cannot be placed are reported to the admin; the timetable cannot be published while any exam remains unscheduled.

A published session is locked against regeneration and manual editing. Students and teachers only see schedules after publication. Once a draft allocation exists for a subject, enrollment changes for that offering are temporarily locked so room capacity and student-conflict checks stay consistent. The admin can use **Clear draft** in the timetable builder to reopen enrollment, then generate again. Publishing rechecks teacher approval, availability and room capacity.

## 8. Main API groups

| API prefix | Purpose |
|---|---|
| `/api/auth` | Student/teacher registration, login and current user |
| `/api/public` | Course and branch catalog used on registration |
| `/api/admin` | Academic data, rooms, sessions, exams, approvals, scheduling and publication |
| `/api/student` | Eligible offerings, enrollment and published student timetable |
| `/api/teacher` | Teacher availability and published invigilation duties |

All admin, student and teacher APIs require a valid JWT and enforce the corresponding role on the server. Hiding a frontend screen is not the only access control.

## 9. Database tables

| Table | Purpose |
|---|---|
| `efp_users` | Login identity, password hash, role and account status |
| `efp_courses` | Courses such as B.Tech, BCA and MCA |
| `efp_branches` | Branches linked to a course |
| `efp_students` | Student profile and academic batch |
| `efp_teachers` | Teacher profile and department |
| `efp_subjects` | University subject catalog |
| `efp_offerings` | Subject-to-batch mapping |
| `efp_enrollments` | Student-to-offering relationship |
| `efp_rooms` | Room name, type and capacity |
| `efp_exam_sessions` | Examination windows and publication state |
| `efp_exams` | Session-specific exam tasks, duration and priority |
| `efp_teacher_availability` | Weekly or date-specific faculty availability |
| `efp_exam_schedule` | Final room, teacher, date and time allocation |

Foreign keys, unique constraints and transactions are used to maintain consistency. Passwords are stored as hashes, never as plaintext.

## 10. Build and tests

```bash
# Frontend production build
npm run build

# Backend scheduling unit tests
npm test
```

The included tests cover FCFS ordering, priority ordering, time-overlap behavior, slot generation and teacher availability matching.

## 11. Troubleshooting

**Backend says access denied for `root`:** Check `DB_USER` and `DB_PASSWORD` in `backend/.env`. Use the same password that works for your local MySQL account.

**Backend cannot connect:** Check that the MySQL service is running and that port `3306` is listening. Confirm the host and port in `.env`.

**Student registration has no course or branch:** Sign in as admin and create the course and branch first.

**A timetable cannot be generated:** Check that there are exam records, rooms with sufficient capacity, approved teachers, and teacher availability covering the session dates and time window. Check that all students in the intended batch have enrolled.

**A timetable cannot be published:** Every exam in the session must have a valid allocation. The scheduler reports the number of exams it could not place.

**Frontend API requests fail:** Run the backend on port `5000` and the frontend on port `5173`. The Vite development proxy forwards `/api` requests to the backend.

---

**Project note:** This is a functional academic project baseline. Before using it for a real university, add institution-specific policy validation, audit logs, backups, deployment secrets management, database migration tooling, accessibility testing and security review.
