const express = require('express');
const { getPool } = require('../config/db');
const { HttpError, required, positiveInt, asyncRoute } = require('../utils/http');
const router = express.Router();

async function getTeacherId(userId) {
  const [[row]] = await getPool().execute('SELECT id FROM efp_teachers WHERE user_id=?', [userId]);
  if (!row) throw new HttpError(404, 'Teacher profile was not found.');
  return Number(row.id);
}

router.get('/availability', asyncRoute(async (req, res) => {
  const teacherId = await getTeacherId(req.user.id);
  const [availability] = await getPool().execute(
    'SELECT * FROM efp_teacher_availability WHERE teacher_id=? ORDER BY weekday,available_date,start_time', [teacherId]
  );
  res.json({ availability });
}));

router.post('/availability', asyncRoute(async (req, res) => {
  required(req.body || {}, ['start_time', 'end_time']);
  const teacherId = await getTeacherId(req.user.id);
  const weekday = req.body.weekday === '' || req.body.weekday === undefined || req.body.weekday === null ? null : Number(req.body.weekday);
  const date = req.body.available_date ? String(req.body.available_date).slice(0, 10) : null;
  if (weekday === null && !date) throw new HttpError(400, 'Choose a recurring weekday or a specific date.');
  if (weekday !== null && (!Number.isInteger(weekday) || weekday < 0 || weekday > 6)) throw new HttpError(400, 'Weekday must be between 0 and 6.');
  if (String(req.body.end_time) <= String(req.body.start_time)) throw new HttpError(400, 'End time must be after start time.');
  const [result] = await getPool().execute(
    'INSERT INTO efp_teacher_availability (teacher_id,weekday,available_date,start_time,end_time) VALUES (?,?,?,?,?)',
    [teacherId, date ? null : weekday, date, req.body.start_time, req.body.end_time]
  );
  res.status(201).json({ id: result.insertId, message: 'Availability saved.' });
}));

router.delete('/availability/:availabilityId', asyncRoute(async (req, res) => {
  const teacherId = await getTeacherId(req.user.id);
  const availabilityId = positiveInt(req.params.availabilityId, 'Availability');
  const [result] = await getPool().execute('DELETE FROM efp_teacher_availability WHERE id=? AND teacher_id=?', [availabilityId, teacherId]);
  if (!result.affectedRows) throw new HttpError(404, 'Availability entry not found.');
  res.json({ message: 'Availability entry deleted.' });
}));

router.get('/duties', asyncRoute(async (req, res) => {
  const teacherId = await getTeacherId(req.user.id);
  const [duties] = await getPool().execute(
    `SELECT sch.id, sch.exam_date, sch.start_time, sch.end_time, s.code AS subject_code,
      s.name AS subject_name, r.name AS room_name, r.building, se.name AS session_name
     FROM efp_exam_schedule sch JOIN efp_exams ex ON ex.id=sch.exam_id
     JOIN efp_exam_sessions se ON se.id=ex.session_id AND se.status='published'
     JOIN efp_offerings off ON off.id=ex.offering_id JOIN efp_subjects s ON s.id=off.subject_id
     JOIN efp_rooms r ON r.id=sch.room_id
     WHERE sch.teacher_id=? AND sch.status='published' ORDER BY sch.exam_date,sch.start_time`, [teacherId]
  );
  res.json({ duties });
}));

module.exports = router;
