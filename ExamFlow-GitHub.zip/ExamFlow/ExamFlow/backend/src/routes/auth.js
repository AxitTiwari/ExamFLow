const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getPool } = require('../config/db');
const { env } = require('../config/env');
const { authenticate } = require('../middleware/auth');
const { HttpError, required, asyncRoute, positiveInt } = require('../utils/http');

const router = express.Router();

function issueToken(user) {
  const token = jwt.sign({ sub: user.id, role: user.role }, env.JWT_SECRET, { expiresIn: env.JWT_EXPIRES_IN });
  return { token, user: { id: user.id, name: user.name, email: user.email, role: user.role, status: user.status } };
}

router.post('/register/student', asyncRoute(async (req, res) => {
  const body = req.body || {};
  required(body, ['name', 'email', 'password', 'course_id', 'branch_id', 'academic_year', 'semester']);
  if (String(body.password).length < 8) throw new HttpError(400, 'Password must contain at least 8 characters.');
  if (!/^\S+@\S+\.\S+$/.test(String(body.email))) throw new HttpError(400, 'Enter a valid email address.');
  const courseId = positiveInt(body.course_id, 'Course');
  const branchId = positiveInt(body.branch_id, 'Branch');
  const year = Number(body.academic_year);
  const semester = Number(body.semester);
  if (!Number.isInteger(year) || year < 2000 || year > 2200) throw new HttpError(400, 'Academic year must be a valid year.');
  if (!Number.isInteger(semester) || semester < 1 || semester > 12) throw new HttpError(400, 'Semester must be between 1 and 12.');

  const pool = getPool();
  const [branches] = await pool.execute('SELECT id FROM efp_branches WHERE id = ? AND course_id = ?', [branchId, courseId]);
  if (!branches.length) throw new HttpError(400, 'The selected branch does not belong to the selected course.');

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const hash = await bcrypt.hash(String(body.password), 12);
    const [userResult] = await connection.execute(
      `INSERT INTO efp_users (name, email, password_hash, role, status) VALUES (?, ?, ?, 'student', 'active')`,
      [String(body.name).trim(), String(body.email).trim().toLowerCase(), hash]
    );
    await connection.execute(
      `INSERT INTO efp_students (user_id, course_id, branch_id, academic_year, semester, roll_number)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [userResult.insertId, courseId, branchId, year, semester, body.roll_number ? String(body.roll_number).trim() : null]
    );
    const user = { id: userResult.insertId, name: String(body.name).trim(), email: String(body.email).trim().toLowerCase(), role: 'student', status: 'active' };
    await connection.commit();
    res.status(201).json(issueToken(user));
  } catch (error) {
    await connection.rollback();
    if (error.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'This email or roll number is already registered.');
    throw error;
  } finally { connection.release(); }
}));

router.post('/register/teacher', asyncRoute(async (req, res) => {
  const body = req.body || {};
  required(body, ['name', 'email', 'password', 'department']);
  if (String(body.password).length < 8) throw new HttpError(400, 'Password must contain at least 8 characters.');
  if (!/^\S+@\S+\.\S+$/.test(String(body.email))) throw new HttpError(400, 'Enter a valid email address.');
  const connection = await getPool().getConnection();
  try {
    await connection.beginTransaction();
    const hash = await bcrypt.hash(String(body.password), 12);
    const [userResult] = await connection.execute(
      `INSERT INTO efp_users (name, email, password_hash, role, status) VALUES (?, ?, ?, 'teacher', 'pending')`,
      [String(body.name).trim(), String(body.email).trim().toLowerCase(), hash]
    );
    await connection.execute(
      `INSERT INTO efp_teachers (user_id, department, designation, employee_code) VALUES (?, ?, ?, ?)`,
      [userResult.insertId, String(body.department).trim(), body.designation ? String(body.designation).trim() : null, body.employee_code ? String(body.employee_code).trim() : null]
    );
    await connection.commit();
    res.status(201).json({ message: 'Registration submitted. Your account will be available after administrator approval.' });
  } catch (error) {
    await connection.rollback();
    if (error.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'This email or employee code is already registered.');
    throw error;
  } finally { connection.release(); }
}));

router.post('/login', asyncRoute(async (req, res) => {
  required(req.body || {}, ['email', 'password']);
  const [rows] = await getPool().execute('SELECT * FROM efp_users WHERE email = ?', [String(req.body.email).trim().toLowerCase()]);
  if (!rows.length || !(await bcrypt.compare(String(req.body.password), rows[0].password_hash))) {
    throw new HttpError(401, 'Email or password is incorrect.');
  }
  const user = rows[0];
  if (user.status === 'pending') throw new HttpError(403, 'Your teacher account is awaiting administrator approval.');
  if (user.status === 'rejected') throw new HttpError(403, 'Your account registration was not approved. Please contact the administrator.');
  res.json(issueToken(user));
}));

router.get('/me', authenticate, asyncRoute(async (req, res) => {
  const user = { ...req.user };
  if (user.role === 'student') {
    const [[profile]] = await getPool().execute(
      `SELECT st.id AS student_id, st.course_id, st.branch_id, st.academic_year, st.semester, st.roll_number,
              c.name AS course_name, b.name AS branch_name
       FROM efp_students st JOIN efp_courses c ON c.id = st.course_id
       JOIN efp_branches b ON b.id = st.branch_id WHERE st.user_id = ?`, [user.id]
    );
    user.profile = profile || null;
  } else if (user.role === 'teacher') {
    const [[profile]] = await getPool().execute(
      'SELECT id AS teacher_id, department, designation, employee_code FROM efp_teachers WHERE user_id = ?', [user.id]
    );
    user.profile = profile || null;
  }
  res.json({ user });
}));

module.exports = router;
