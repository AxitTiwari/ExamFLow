const express = require('express');
const { getPool } = require('../config/db');
const { HttpError, positiveInt, asyncRoute } = require('../utils/http');
const router = express.Router();

async function getStudentId(userId) {
  const [[row]] = await getPool().execute('SELECT id,course_id,branch_id,academic_year,semester FROM efp_students WHERE user_id=?', [userId]);
  if (!row) throw new HttpError(404, 'Student profile was not found.');
  return row;
}

router.get('/offerings', asyncRoute(async (req, res) => {
  const student = await getStudentId(req.user.id);
  const [offerings] = await getPool().execute(
    `SELECT off.id AS offering_id, sub.id AS subject_id, sub.code, sub.name, sub.credits,
      off.academic_year, off.semester, c.name AS course_name, b.name AS branch_name,
      EXISTS(SELECT 1 FROM efp_enrollments en WHERE en.offering_id=off.id AND en.student_id=?) AS enrolled,
      EXISTS(SELECT 1 FROM efp_exams ex JOIN efp_exam_sessions se ON se.id=ex.session_id
        WHERE ex.offering_id=off.id AND se.status='published') AS published
     FROM efp_offerings off JOIN efp_subjects sub ON sub.id=off.subject_id
     JOIN efp_courses c ON c.id=off.course_id JOIN efp_branches b ON b.id=off.branch_id
     WHERE off.course_id=? AND off.branch_id=? AND off.academic_year=? AND off.semester=?
     ORDER BY sub.code`, [student.id, student.course_id, student.branch_id, student.academic_year, student.semester]
  );
  res.json({ offerings });
}));

router.post('/enrollments/:offeringId', asyncRoute(async (req, res) => {
  const offeringId = positiveInt(req.params.offeringId, 'Offering');
  const student = await getStudentId(req.user.id);
  const [[offering]] = await getPool().execute(
    `SELECT id FROM efp_offerings WHERE id=? AND course_id=? AND branch_id=? AND academic_year=? AND semester=?`,
    [offeringId, student.course_id, student.branch_id, student.academic_year, student.semester]
  );
  if (!offering) throw new HttpError(403, 'This subject is not available for your academic batch.');
  const [[locked]] = await getPool().execute(
    `SELECT COUNT(*) AS n FROM efp_exams ex
     LEFT JOIN efp_exam_schedule sch ON sch.exam_id=ex.id
     WHERE ex.offering_id=? AND sch.id IS NOT NULL`, [offeringId]
  );
  if (Number(locked.n)) throw new HttpError(409, 'Enrollment is locked because this subject already has a draft or published timetable allocation. Ask the administrator to clear the draft timetable before changing enrollment.');
  try {
    await getPool().execute('INSERT INTO efp_enrollments (student_id,offering_id) VALUES (?,?)', [student.id, offeringId]);
    res.status(201).json({ message: 'You are enrolled in this subject.' });
  } catch (error) { if (error.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'You are already enrolled in this subject.'); throw error; }
}));

router.delete('/enrollments/:offeringId', asyncRoute(async (req, res) => {
  const offeringId = positiveInt(req.params.offeringId, 'Offering');
  const student = await getStudentId(req.user.id);
  const [[locked]] = await getPool().execute(
    `SELECT COUNT(*) AS n FROM efp_exams ex
     LEFT JOIN efp_exam_schedule sch ON sch.exam_id=ex.id
     WHERE ex.offering_id=? AND sch.id IS NOT NULL`, [offeringId]
  );
  if (Number(locked.n)) throw new HttpError(409, 'Withdrawal is locked because this subject already has a draft or published timetable allocation. Ask the administrator to clear the draft timetable before changing enrollment.');
  await getPool().execute('DELETE FROM efp_enrollments WHERE student_id=? AND offering_id=?', [student.id, offeringId]);
  res.json({ message: 'You have been withdrawn from this subject.' });
}));

router.get('/timetable', asyncRoute(async (req, res) => {
  const student = await getStudentId(req.user.id);
  const [schedule] = await getPool().execute(
    `SELECT sch.id, sch.exam_date, sch.start_time, sch.end_time,
      sub.code AS subject_code, sub.name AS subject_name, c.name AS course_name, b.name AS branch_name,
      r.name AS room_name, r.building, se.name AS session_name
     FROM efp_enrollments en JOIN efp_offerings off ON off.id=en.offering_id
     JOIN efp_exams ex ON ex.offering_id=off.id JOIN efp_exam_sessions se ON se.id=ex.session_id AND se.status='published'
     JOIN efp_exam_schedule sch ON sch.exam_id=ex.id AND sch.status='published'
     JOIN efp_subjects sub ON sub.id=off.subject_id JOIN efp_courses c ON c.id=off.course_id
     JOIN efp_branches b ON b.id=off.branch_id JOIN efp_rooms r ON r.id=sch.room_id
     WHERE en.student_id=? ORDER BY sch.exam_date,sch.start_time`, [student.id]
  );
  res.json({ schedule });
}));

module.exports = router;
