const express = require('express');
const { getPool } = require('../config/db');
const { asyncRoute } = require('../utils/http');
const router = express.Router();

router.get('/catalog', asyncRoute(async (req, res) => {
  const [courses] = await getPool().execute('SELECT id, name, code FROM efp_courses ORDER BY name');
  const [branches] = await getPool().execute('SELECT id, course_id, name, code FROM efp_branches ORDER BY name');
  res.json({ courses, branches });
}));

module.exports = router;
