const express = require('express');
const { getPool } = require('../config/db');
const { generateSchedule, overlaps, toMinutes } = require('../services/scheduler');
const { HttpError, required, positiveInt, asyncRoute } = require('../utils/http');
const router = express.Router();

router.get('/overview', asyncRoute(async (req, res) => {
  const pool = getPool();
  const counts = {};
  const queries = {
    students: "SELECT COUNT(*) AS n FROM efp_users WHERE role='student' AND status='active'",
    teachers: "SELECT COUNT(*) AS n FROM efp_users WHERE role='teacher' AND status='active'",
    pendingTeachers: "SELECT COUNT(*) AS n FROM efp_users WHERE role='teacher' AND status='pending'",
    subjects: 'SELECT COUNT(*) AS n FROM efp_subjects',
    rooms: 'SELECT COUNT(*) AS n FROM efp_rooms',
    sessions: 'SELECT COUNT(*) AS n FROM efp_exam_sessions',
    scheduled: 'SELECT COUNT(*) AS n FROM efp_exam_schedule',
    exams: 'SELECT COUNT(*) AS n FROM efp_exams'
  };
  for (const [key, sql] of Object.entries(queries)) {
    const [[row]] = await pool.query(sql);
    counts[key] = Number(row.n);
  }
  const [recentSessions] = await pool.execute(
    `SELECT s.id, s.name, s.start_date, s.end_date, s.status,
      (SELECT COUNT(*) FROM efp_exams e WHERE e.session_id = s.id) AS exam_count,
      (SELECT COUNT(*) FROM efp_exam_schedule sch JOIN efp_exams e ON e.id = sch.exam_id WHERE e.session_id = s.id) AS scheduled_count
     FROM efp_exam_sessions s ORDER BY s.created_at DESC LIMIT 5`
  );
  res.json({ counts, recentSessions });
}));

router.get('/courses', asyncRoute(async (req, res) => {
  const [rows] = await getPool().execute('SELECT * FROM efp_courses ORDER BY name');
  res.json({ courses: rows });
}));
router.post('/courses', asyncRoute(async (req, res) => {
  required(req.body || {}, ['name', 'code']);
  try {
    const [result] = await getPool().execute('INSERT INTO efp_courses (name, code) VALUES (?, ?)', [String(req.body.name).trim(), String(req.body.code).trim().toUpperCase()]);
    res.status(201).json({ id: result.insertId, message: 'Course created.' });
  } catch (error) { if (error.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'A course with this code already exists.'); throw error; }
}));

router.get('/branches', asyncRoute(async (req, res) => {
  const [rows] = await getPool().execute('SELECT b.*, c.name AS course_name FROM efp_branches b JOIN efp_courses c ON c.id=b.course_id ORDER BY c.name,b.name');
  res.json({ branches: rows });
}));
router.post('/branches', asyncRoute(async (req, res) => {
  required(req.body || {}, ['course_id', 'name', 'code']);
  const courseId = positiveInt(req.body.course_id, 'Course');
  try {
    const [result] = await getPool().execute('INSERT INTO efp_branches (course_id, name, code) VALUES (?, ?, ?)', [courseId, String(req.body.name).trim(), String(req.body.code).trim().toUpperCase()]);
    res.status(201).json({ id: result.insertId, message: 'Branch created.' });
  } catch (error) { if (error.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'This branch already exists for the selected course.'); throw error; }
}));

router.get('/subjects', asyncRoute(async (req, res) => {
  const [rows] = await getPool().execute('SELECT * FROM efp_subjects ORDER BY name');
  res.json({ subjects: rows });
}));
router.post('/subjects', asyncRoute(async (req, res) => {
  required(req.body || {}, ['code', 'name']);
  const credits = Number(req.body.credits || 3);
  if (!Number.isFinite(credits) || credits < 0.5 || credits > 10) throw new HttpError(400, 'Credits must be between 0.5 and 10.');
  try {
    const [result] = await getPool().execute('INSERT INTO efp_subjects (code, name, credits) VALUES (?, ?, ?)', [String(req.body.code).trim().toUpperCase(), String(req.body.name).trim(), credits]);
    res.status(201).json({ id: result.insertId, message: 'Subject created.' });
  } catch (error) { if (error.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'A subject with this code already exists.'); throw error; }
}));

router.get('/offerings', asyncRoute(async (req, res) => {
  const [rows] = await getPool().execute(
    `SELECT o.*, s.code AS subject_code, s.name AS subject_name, c.name AS course_name, b.name AS branch_name,
      (SELECT COUNT(*) FROM efp_enrollments en WHERE en.offering_id=o.id) AS enrolled_count
     FROM efp_offerings o JOIN efp_subjects s ON s.id=o.subject_id
     JOIN efp_courses c ON c.id=o.course_id JOIN efp_branches b ON b.id=o.branch_id ORDER BY o.created_at DESC`
  );
  res.json({ offerings: rows });
}));
router.post('/offerings', asyncRoute(async (req, res) => {
  required(req.body || {}, ['subject_id', 'course_id', 'branch_id', 'academic_year', 'semester']);
  const subjectId = positiveInt(req.body.subject_id, 'Subject');
  const courseId = positiveInt(req.body.course_id, 'Course');
  const branchId = positiveInt(req.body.branch_id, 'Branch');
  const year = Number(req.body.academic_year);
  const semester = Number(req.body.semester);
  if (!Number.isInteger(year) || year < 2000 || year > 2200) throw new HttpError(400, 'Academic year is invalid.');
  if (!Number.isInteger(semester) || semester < 1 || semester > 12) throw new HttpError(400, 'Semester must be between 1 and 12.');
  const [branch] = await getPool().execute('SELECT id FROM efp_branches WHERE id=? AND course_id=?', [branchId, courseId]);
  if (!branch.length) throw new HttpError(400, 'Selected branch does not belong to the selected course.');
  try {
    const [result] = await getPool().execute(
      'INSERT INTO efp_offerings (subject_id,course_id,branch_id,academic_year,semester) VALUES (?,?,?,?,?)',
      [subjectId, courseId, branchId, year, semester]
    );
    res.status(201).json({ id: result.insertId, message: 'Subject offering created.' });
  } catch (error) { if (error.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'This subject is already offered to that academic batch.'); throw error; }
}));

router.get('/rooms', asyncRoute(async (req, res) => {
  const [rows] = await getPool().execute('SELECT * FROM efp_rooms ORDER BY name');
  res.json({ rooms: rows });
}));
router.post('/rooms', asyncRoute(async (req, res) => {
  required(req.body || {}, ['name', 'capacity']);
  const capacity = Number(req.body.capacity);
  if (!Number.isInteger(capacity) || capacity < 1 || capacity > 10000) throw new HttpError(400, 'Room capacity must be a positive whole number.');
  try {
    const [result] = await getPool().execute(
      'INSERT INTO efp_rooms (name,building,capacity,room_type) VALUES (?,?,?,?)',
      [String(req.body.name).trim(), req.body.building ? String(req.body.building).trim() : null, capacity, String(req.body.room_type || 'Classroom').trim()]
    );
    res.status(201).json({ id: result.insertId, message: 'Examination room created.' });
  } catch (error) { if (error.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'A room with this name already exists.'); throw error; }
}));

router.get('/sessions', asyncRoute(async (req, res) => {
  const [rows] = await getPool().execute(
    `SELECT s.*, (SELECT COUNT(*) FROM efp_exams e WHERE e.session_id=s.id) AS exam_count,
      (SELECT COUNT(*) FROM efp_exam_schedule sch JOIN efp_exams e ON e.id=sch.exam_id WHERE e.session_id=s.id) AS scheduled_count
     FROM efp_exam_sessions s ORDER BY s.start_date DESC, s.id DESC`
  );
  res.json({ sessions: rows });
}));
router.post('/sessions', asyncRoute(async (req, res) => {
  required(req.body || {}, ['name', 'start_date', 'end_date', 'day_start_time', 'day_end_time']);
  if (String(req.body.end_date) < String(req.body.start_date)) throw new HttpError(400, 'End date must be on or after start date.');
  if (String(req.body.day_end_time) <= String(req.body.day_start_time)) throw new HttpError(400, 'Daily closing time must be after opening time.');
  const [result] = await getPool().execute(
    `INSERT INTO efp_exam_sessions (name,start_date,end_date,day_start_time,day_end_time,created_by)
     VALUES (?,?,?,?,?,?)`,
    [String(req.body.name).trim(), req.body.start_date, req.body.end_date, req.body.day_start_time, req.body.day_end_time, req.user.id]
  );
  res.status(201).json({ id: result.insertId, message: 'Examination session created.' });
}));

router.get('/sessions/:sessionId/exams', asyncRoute(async (req, res) => {
  const sessionId = positiveInt(req.params.sessionId, 'Session');
  const [rows] = await getPool().execute(
    `SELECT ex.*, s.code AS subject_code, s.name AS subject_name, off.academic_year, off.semester,
      c.name AS course_name, b.name AS branch_name,
      (SELECT COUNT(*) FROM efp_enrollments en WHERE en.offering_id=off.id) AS student_count
     FROM efp_exams ex JOIN efp_offerings off ON off.id=ex.offering_id JOIN efp_subjects s ON s.id=off.subject_id
     JOIN efp_courses c ON c.id=off.course_id JOIN efp_branches b ON b.id=off.branch_id
     WHERE ex.session_id=? ORDER BY ex.created_at`, [sessionId]
  );
  res.json({ exams: rows });
}));
router.post('/exams', asyncRoute(async (req, res) => {
  required(req.body || {}, ['session_id', 'offering_id']);
  const sessionId = positiveInt(req.body.session_id, 'Session');
  const offeringId = positiveInt(req.body.offering_id, 'Offering');
  const duration = Number(req.body.duration_minutes || 180);
  const priority = Number(req.body.priority || 1);
  if (!Number.isInteger(duration) || duration < 30 || duration > 480) throw new HttpError(400, 'Exam duration must be between 30 and 480 minutes.');
  if (!Number.isInteger(priority) || priority < 1 || priority > 5) throw new HttpError(400, 'Priority must be between 1 and 5.');
  const [[session]] = await getPool().execute('SELECT status FROM efp_exam_sessions WHERE id=?', [sessionId]);
  if (!session) throw new HttpError(404, 'Examination session not found.');
  if (session.status === 'published') throw new HttpError(409, 'This session is already published.');
  try {
    const [result] = await getPool().execute(
      'INSERT INTO efp_exams (session_id,offering_id,duration_minutes,priority) VALUES (?,?,?,?)',
      [sessionId, offeringId, duration, priority]
    );
    res.status(201).json({ id: result.insertId, message: 'Examination added to session.' });
  } catch (error) { if (error.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'This subject offering is already an exam in that session.'); throw error; }
}));


router.get('/students', asyncRoute(async (req, res) => {
  const [rows] = await getPool().execute(
    `SELECT
        st.user_id AS student_id,
        st.academic_year,
        st.semester,
        st.roll_no AS roll_number,
        COALESCE(st.full_name, u.name) AS name,
        u.email,
        u.status,
        c.name AS course_name,
        b.name AS branch_name,
        (SELECT COUNT(*)
         FROM efp_enrollments en
         WHERE en.student_id = st.user_id
        ) AS enrolled_subjects
     FROM efp_students st
     JOIN efp_users u ON u.id = st.user_id
     JOIN efp_courses c ON c.id = st.course_id
     JOIN efp_branches b ON b.id = st.branch_id
     ORDER BY u.name`
  );

  res.json({ students: rows });
}));


router.get('/teachers', asyncRoute(async (req, res) => {
  const [rows] = await getPool().execute(
    `SELECT t.id AS teacher_id, t.department, t.designation, t.employee_code,
      u.id AS user_id, u.name, u.email, u.status, u.created_at
     FROM efp_teachers t JOIN efp_users u ON u.id=t.user_id ORDER BY FIELD(u.status,'pending','active','rejected'),u.name`
  );
  res.json({ teachers: rows });
}));
router.patch('/teachers/:teacherId/status', asyncRoute(async (req, res) => {
  const teacherId = positiveInt(req.params.teacherId, 'Teacher');
  const status = String(req.body.status || '');
  if (!['active', 'rejected'].includes(status)) throw new HttpError(400, 'Status must be active or rejected.');
  const [result] = await getPool().execute(
    `UPDATE efp_users u JOIN efp_teachers t ON t.user_id=u.id SET u.status=? WHERE t.id=?`, [status, teacherId]
  );
  if (!result.affectedRows) throw new HttpError(404, 'Teacher not found.');
  res.json({ message: status === 'active' ? 'Teacher approved.' : 'Teacher registration rejected.' });
}));

router.post('/sessions/:sessionId/generate', asyncRoute(async (req, res) => {
  const sessionId = positiveInt(req.params.sessionId, 'Session');
  const algorithm = String(req.body.algorithm || 'FCFS').toUpperCase();
  if (!['FCFS', 'PRIORITY'].includes(algorithm)) throw new HttpError(400, 'Choose FCFS or PRIORITY scheduling.');
  const result = await generateSchedule(sessionId, algorithm);
  res.json({ message: `Scheduling completed using ${algorithm}.`, ...result });
}));

router.get('/sessions/:sessionId/schedule', asyncRoute(async (req, res) => {
  const sessionId = positiveInt(req.params.sessionId, 'Session');
  const [[session]] = await getPool().execute('SELECT * FROM efp_exam_sessions WHERE id=?', [sessionId]);
  if (!session) throw new HttpError(404, 'Examination session not found.');
  const [schedule] = await getPool().execute(
    `SELECT sch.id, sch.exam_id, sch.exam_date, sch.start_time, sch.end_time, sch.status,
      r.id AS room_id, r.name AS room_name, r.capacity,
      t.id AS teacher_id, u.name AS teacher_name, s.code AS subject_code, s.name AS subject_name,
      ex.duration_minutes, ex.priority, off.id AS offering_id,
      (SELECT COUNT(*) FROM efp_enrollments en WHERE en.offering_id=off.id) AS student_count
     FROM efp_exam_schedule sch JOIN efp_exams ex ON ex.id=sch.exam_id
     JOIN efp_offerings off ON off.id=ex.offering_id JOIN efp_subjects s ON s.id=off.subject_id
     JOIN efp_rooms r ON r.id=sch.room_id JOIN efp_teachers t ON t.id=sch.teacher_id
     JOIN efp_users u ON u.id=t.user_id WHERE ex.session_id=?
     ORDER BY sch.exam_date,sch.start_time,s.code`, [sessionId]
  );
  const [unscheduled] = await getPool().execute(
    `SELECT ex.id AS exam_id, sub.code AS subject_code, sub.name AS subject_name,
      (SELECT COUNT(*) FROM efp_enrollments en WHERE en.offering_id=off.id) AS student_count
     FROM efp_exams ex JOIN efp_offerings off ON off.id=ex.offering_id
     JOIN efp_subjects sub ON sub.id=off.subject_id
     LEFT JOIN efp_exam_schedule sch ON sch.exam_id=ex.id
     WHERE ex.session_id=? AND sch.id IS NULL ORDER BY ex.created_at`, [sessionId]
  );
  const [[totalRow]] = await getPool().execute('SELECT COUNT(*) AS n FROM efp_exams WHERE session_id=?', [sessionId]);
  res.json({ session, schedule, unscheduled, totalExams: Number(totalRow.n), unscheduledCount: unscheduled.length });
}));

router.patch('/sessions/:sessionId/schedule/:scheduleId', asyncRoute(async (req, res) => {
  const sessionId = positiveInt(req.params.sessionId, 'Session');
  const scheduleId = positiveInt(req.params.scheduleId, 'Schedule');
  required(req.body || {}, ['exam_date', 'start_time', 'room_id', 'teacher_id']);
  const roomId = positiveInt(req.body.room_id, 'Room');
  const teacherId = positiveInt(req.body.teacher_id, 'Teacher');
  const [[current]] = await getPool().execute(
    `SELECT sch.*, ex.session_id, ex.duration_minutes, off.id AS offering_id,
      (SELECT COUNT(*) FROM efp_enrollments en WHERE en.offering_id=off.id) AS student_count,
      sess.start_date, sess.end_date, sess.day_start_time, sess.day_end_time
     FROM efp_exam_schedule sch JOIN efp_exams ex ON ex.id=sch.exam_id
     JOIN efp_offerings off ON off.id=ex.offering_id JOIN efp_exam_sessions sess ON sess.id=ex.session_id
     WHERE sch.id=? AND ex.session_id=?`, [scheduleId, sessionId]
  );
  if (!current) throw new HttpError(404, 'Scheduled examination not found.');
  if (current.status === 'published') throw new HttpError(409, 'Published schedules are locked.');
  const date = String(req.body.exam_date).slice(0, 10);
  const endMinutes = toMinutes(req.body.start_time) + Number(current.duration_minutes);
  const endTime = `${String(Math.floor(endMinutes / 60)).padStart(2, '0')}:${String(endMinutes % 60).padStart(2, '0')}:00`;
  if (date < String(current.start_date).slice(0, 10) || date > String(current.end_date).slice(0, 10)) throw new HttpError(400, 'The date must fall within this examination session.');
  if (toMinutes(req.body.start_time) < toMinutes(current.day_start_time) || endMinutes > toMinutes(current.day_end_time)) throw new HttpError(400, 'The examination must fit inside the session daily time window.');

  const pool = getPool();
  const [[room]] = await pool.execute('SELECT * FROM efp_rooms WHERE id=?', [roomId]);
  if (!room || Number(room.capacity) < Number(current.student_count)) throw new HttpError(400, 'Selected room is missing or has insufficient seating capacity.');
  const [[teacher]] = await pool.execute(
    `SELECT t.id FROM efp_teachers t JOIN efp_users u ON u.id=t.user_id WHERE t.id=? AND u.status='active'`, [teacherId]
  );
  if (!teacher) throw new HttpError(400, 'Select an approved teacher.');
  const weekday = new Date(`${date}T12:00:00Z`).getUTCDay();
  const [availability] = await pool.execute(
    `SELECT id FROM efp_teacher_availability WHERE teacher_id=?
      AND (available_date=? OR (available_date IS NULL AND weekday=?))
      AND start_time<=? AND end_time>=? LIMIT 1`, [teacherId, date, weekday, req.body.start_time, endTime]
  );
  if (!availability.length) throw new HttpError(400, 'The selected teacher is not available for this date and time.');

  const [conflicts] = await pool.execute(
    `SELECT sch.id, sch.room_id, sch.teacher_id, sch.start_time, sch.end_time, off.id AS offering_id
     FROM efp_exam_schedule sch JOIN efp_exams ex ON ex.id=sch.exam_id JOIN efp_offerings off ON off.id=ex.offering_id
     WHERE sch.exam_date=? AND sch.id<>? AND (sch.room_id=? OR sch.teacher_id=?)`,
    [date, scheduleId, roomId, teacherId]
  );
  if (conflicts.some((row) => overlaps(row.start_time, row.end_time, req.body.start_time, endTime))) throw new HttpError(409, 'The room or teacher is already assigned during that time.');

  const [studentRows] = await pool.execute('SELECT student_id FROM efp_enrollments WHERE offering_id=?', [current.offering_id]);
  const myStudents = new Set(studentRows.map((row) => Number(row.student_id)));
  const [otherSchedule] = await pool.execute(
    `SELECT sch.id, sch.start_time, sch.end_time, off.id AS offering_id
     FROM efp_exam_schedule sch JOIN efp_exams ex ON ex.id=sch.exam_id JOIN efp_offerings off ON off.id=ex.offering_id
     WHERE sch.exam_date=? AND sch.id<>?`, [date, scheduleId]
  );
  const overlapRows = otherSchedule.filter((row) => overlaps(row.start_time, row.end_time, req.body.start_time, endTime));
  if (overlapRows.length) {
    const otherOfferingIds = overlapRows.map((row) => Number(row.offering_id));
    const [otherEnrollments] = await pool.query(`SELECT student_id, offering_id FROM efp_enrollments WHERE offering_id IN (${otherOfferingIds.map(() => '?').join(',')})`, otherOfferingIds);
    if (otherEnrollments.some((row) => myStudents.has(Number(row.student_id)))) throw new HttpError(409, 'One or more students have another examination at that time.');
  }
  await pool.execute(
    'UPDATE efp_exam_schedule SET room_id=?,teacher_id=?,exam_date=?,start_time=?,end_time=? WHERE id=?',
    [roomId, teacherId, date, req.body.start_time, endTime, scheduleId]
  );
  res.json({ message: 'Schedule updated.', end_time: endTime });
}));

router.post('/sessions/:sessionId/reset', asyncRoute(async (req, res) => {
  const sessionId = positiveInt(req.params.sessionId, 'Session');
  const [[session]] = await getPool().execute('SELECT status FROM efp_exam_sessions WHERE id=?', [sessionId]);
  if (!session) throw new HttpError(404, 'Examination session not found.');
  if (session.status === 'published') throw new HttpError(409, 'A published timetable cannot be cleared.');
  const [exams] = await getPool().execute('SELECT id FROM efp_exams WHERE session_id=?', [sessionId]);
  if (exams.length) {
    const ids = exams.map((row) => Number(row.id));
    await getPool().query(`DELETE FROM efp_exam_schedule WHERE exam_id IN (${ids.map(() => '?').join(',')})`, ids);
  }
  res.json({ message: 'Draft allocations cleared. Students can update enrollment before you generate the timetable again.' });
}));

router.post('/sessions/:sessionId/publish', asyncRoute(async (req, res) => {
  const sessionId = positiveInt(req.params.sessionId, 'Session');
  const connection = await getPool().getConnection();
  try {
    await connection.beginTransaction();
    const [[session]] = await connection.execute('SELECT * FROM efp_exam_sessions WHERE id=? FOR UPDATE', [sessionId]);
    if (!session) throw new HttpError(404, 'Examination session not found.');
    if (session.status === 'published') throw new HttpError(409, 'This timetable is already published.');
    const [[counts]] = await connection.execute(
      `SELECT COUNT(*) AS total, COUNT(sch.id) AS scheduled FROM efp_exams ex
       LEFT JOIN efp_exam_schedule sch ON sch.exam_id=ex.id WHERE ex.session_id=?`, [sessionId]
    );
    if (Number(counts.total) === 0) throw new HttpError(400, 'There are no examinations in this session.');
    if (Number(counts.total) !== Number(counts.scheduled)) throw new HttpError(400, `Cannot publish yet: ${Number(counts.total) - Number(counts.scheduled)} examination(s) are not scheduled.`);

    const [allocations] = await connection.execute(
      `SELECT sch.exam_date, sch.start_time, sch.end_time, sch.teacher_id,
        off.id AS offering_id, r.capacity, u.status AS teacher_status,
        (SELECT COUNT(*) FROM efp_enrollments en WHERE en.offering_id=off.id) AS student_count
       FROM efp_exam_schedule sch JOIN efp_exams ex ON ex.id=sch.exam_id
       JOIN efp_offerings off ON off.id=ex.offering_id
       JOIN efp_rooms r ON r.id=sch.room_id
       JOIN efp_teachers t ON t.id=sch.teacher_id JOIN efp_users u ON u.id=t.user_id
       WHERE ex.session_id=?`, [sessionId]
    );
    for (const item of allocations) {
      if (item.teacher_status !== 'active') throw new HttpError(409, 'A scheduled invigilator is no longer approved. Regenerate the draft timetable.');
      if (Number(item.capacity) < Number(item.student_count)) throw new HttpError(409, 'A room no longer has enough capacity for its enrolled students. Regenerate the draft timetable.');
      const weekday = new Date(`${String(item.exam_date).slice(0,10)}T12:00:00Z`).getUTCDay();
      const [availability] = await connection.execute(
        `SELECT id FROM efp_teacher_availability WHERE teacher_id=?
          AND (available_date=? OR (available_date IS NULL AND weekday=?))
          AND start_time<=? AND end_time>=? LIMIT 1`,
        [item.teacher_id, String(item.exam_date).slice(0,10), weekday, item.start_time, item.end_time]
      );
      if (!availability.length) throw new HttpError(409, 'A teacher availability entry changed after scheduling. Regenerate the draft timetable before publishing.');
    }

    await connection.execute(
      `UPDATE efp_exam_schedule sch JOIN efp_exams ex ON ex.id=sch.exam_id SET sch.status='published' WHERE ex.session_id=?`, [sessionId]
    );
    await connection.execute("UPDATE efp_exam_sessions SET status='published' WHERE id=?", [sessionId]);
    await connection.commit();
    res.json({ message: 'Timetable published. Students and teachers can now view their schedules.' });
  } catch (error) { await connection.rollback(); throw error; }
  finally { connection.release(); }
}));

module.exports = router;
