const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const { env } = require('./config/env');
const { initializeDatabase } = require('./config/db');
const { authenticate, allowRoles } = require('./middleware/auth');
const authRoutes = require('./routes/auth');
const publicRoutes = require('./routes/public');
const adminRoutes = require('./routes/admin');
const studentRoutes = require('./routes/student');
const teacherRoutes = require('./routes/teacher');

const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: env.FRONTEND_ORIGIN.split(',').map((item) => item.trim()), credentials: true }));
app.use(express.json({ limit: '1mb' }));
if (env.NODE_ENV !== 'test') app.use(morgan('dev'));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: 'draft-7', legacyHeaders: false }), authRoutes);
app.use('/api/public', publicRoutes);
app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'ExamFlow API' }));
app.use('/api/admin', authenticate, allowRoles('admin'), adminRoutes);
app.use('/api/student', authenticate, allowRoles('student'), studentRoutes);
app.use('/api/teacher', authenticate, allowRoles('teacher'), teacherRoutes);
app.use((req, res) => res.status(404).json({ message: 'API endpoint not found.' }));
app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  const status = error.status || (error.code === 'ER_DUP_ENTRY' ? 409 : 500);
  const message = status >= 500 && env.NODE_ENV === 'production'
    ? 'An unexpected server error occurred.'
    : (error.code === 'ER_DUP_ENTRY' ? 'A record with the same unique value already exists.' : error.message || 'Server error.');
  if (status >= 500) console.error(error);
  res.status(status).json({ message });
});

async function start() {
  await initializeDatabase();
  app.listen(env.PORT, () => console.log(`ExamFlow API running at http://localhost:${env.PORT}`));
}

if (require.main === module) {
  start().catch((error) => { console.error('Could not start ExamFlow:', error.message); process.exit(1); });
}

module.exports = app;
