class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function required(body, fields) {
  const missing = fields.filter((field) => body[field] === undefined || body[field] === null || String(body[field]).trim() === '');
  if (missing.length) throw new HttpError(400, `Please provide: ${missing.join(', ')}.`);
}

function positiveInt(value, label = 'ID') {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) throw new HttpError(400, `${label} must be a valid positive number.`);
  return parsed;
}

function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

module.exports = { HttpError, required, positiveInt, asyncRoute };
