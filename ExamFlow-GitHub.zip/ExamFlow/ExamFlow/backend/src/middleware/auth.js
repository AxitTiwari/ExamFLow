const jwt = require('jsonwebtoken');
const { env } = require('../config/env');
const { getPool } = require('../config/db');

async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ message: 'Please sign in to continue.' });
    const payload = jwt.verify(token, env.JWT_SECRET);
    const [rows] = await getPool().execute(
      'SELECT id, name, email, role, status FROM efp_users WHERE id = ?', [payload.sub]
    );
    if (!rows.length || rows[0].status !== 'active') {
      return res.status(401).json({ message: 'This account is not active.' });
    }
    req.user = rows[0];
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Your session is invalid or has expired. Please sign in again.' });
    }
    next(error);
  }
}

function allowRoles(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'You do not have permission to perform this action.' });
    }
    next();
  };
}

module.exports = { authenticate, allowRoles };
