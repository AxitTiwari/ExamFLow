function toMinutes(time) {
  const [h, m] = String(time).slice(0, 5).split(':').map(Number);
  return h * 60 + m;
}

function toTime(minutes) {
  const h = Math.floor(minutes / 60).toString().padStart(2, '0');
  const m = (minutes % 60).toString().padStart(2, '0');
  return `${h}:${m}:00`;
}

function overlaps(aStart, aEnd, bStart, bEnd) {
  return toMinutes(aStart) < toMinutes(bEnd) && toMinutes(bStart) < toMinutes(aEnd);
}

function intersects(left, right) {
  if (!left || !right || left.length === 0 || right.length === 0) return false;
  const rightSet = new Set(right.map(Number));
  return left.some((id) => rightSet.has(Number(id)));
}

function sortExams(exams, algorithm) {
  const copy = [...exams];
  if (String(algorithm).toUpperCase() === 'PRIORITY') {
    return copy.sort((a, b) => Number(b.priority) - Number(a.priority) || new Date(a.created_at) - new Date(b.created_at) || a.id - b.id);
  }
  return copy.sort((a, b) => new Date(a.created_at) - new Date(b.created_at) || a.id - b.id);
}

function dateRange(start, end) {
  const dates = [];
  const cursor = new Date(`${String(start).slice(0, 10)}T12:00:00Z`);
  const last = new Date(`${String(end).slice(0, 10)}T12:00:00Z`);
  while (cursor <= last) {
    dates.push(cursor.toISOString().slice(0, 10));
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return dates;
}

function teacherAvailable(teacherId, date, start, end, availability) {
  const weekday = new Date(`${date}T12:00:00Z`).getUTCDay();
  return availability.some((row) => Number(row.teacher_id) === Number(teacherId)
    && (row.available_date === date || (row.available_date == null && Number(row.weekday) === weekday))
    && toMinutes(row.start_time) <= toMinutes(start)
    && toMinutes(row.end_time) >= toMinutes(end));
}

function buildSlots(session, duration) {
  const slots = [];
  const start = toMinutes(session.day_start_time);
  const close = toMinutes(session.day_end_time);
  // 30-minute increments permit staggered examinations while keeping the search predictable.
  for (const date of dateRange(session.start_date, session.end_date)) {
    for (let minute = start; minute + duration <= close; minute += 30) {
      slots.push({ date, start: toTime(minute), end: toTime(minute + duration) });
    }
  }
  return slots;
}

async function generateSchedule(sessionId, algorithm) {
  const { getPool } = require('../config/db');
  const pool = getPool();
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [[session]] = await connection.execute('SELECT * FROM efp_exam_sessions WHERE id = ? FOR UPDATE', [sessionId]);
    if (!session) throw Object.assign(new Error('Examination session was not found.'), { status: 404 });
    if (session.status === 'published') throw Object.assign(new Error('A published timetable is locked and cannot be regenerated.'), { status: 409 });

    const [exams] = await connection.execute(
      `SELECT ex.id, ex.session_id, ex.offering_id, ex.duration_minutes, ex.priority, ex.created_at,
              sub.code AS subject_code, sub.name AS subject_name,
              off.course_id, off.branch_id, off.academic_year, off.semester,
              (SELECT COUNT(*) FROM efp_enrollments en WHERE en.offering_id = off.id) AS student_count
       FROM efp_exams ex
       JOIN efp_offerings off ON off.id = ex.offering_id
       JOIN efp_subjects sub ON sub.id = off.subject_id
       WHERE ex.session_id = ?`, [sessionId]
    );
    if (!exams.length) throw Object.assign(new Error('Add at least one examination to this session before generating a timetable.'), { status: 400 });

    const examIds = exams.map((exam) => Number(exam.id));
    await connection.query(`DELETE FROM efp_exam_schedule WHERE exam_id IN (${examIds.map(() => '?').join(',')})`, examIds);

    const offeringIds = [...new Set(exams.map((exam) => Number(exam.offering_id)))];
    const [enrollments] = await connection.query(
      `SELECT offering_id, student_id FROM efp_enrollments WHERE offering_id IN (${offeringIds.map(() => '?').join(',')})`, offeringIds
    );
    const studentsByOffering = new Map();
    for (const row of enrollments) {
      const key = Number(row.offering_id);
      if (!studentsByOffering.has(key)) studentsByOffering.set(key, []);
      studentsByOffering.get(key).push(Number(row.student_id));
    }

    const [rooms] = await connection.execute('SELECT id, name, capacity FROM efp_rooms ORDER BY capacity ASC, name ASC');
    const [teachers] = await connection.execute(
      `SELECT t.id, u.name FROM efp_teachers t JOIN efp_users u ON u.id = t.user_id
       WHERE u.role = 'teacher' AND u.status = 'active' ORDER BY u.name ASC`
    );
    const [availability] = await connection.execute('SELECT * FROM efp_teacher_availability');
    const [existingRows] = await connection.execute(
      `SELECT sch.id, sch.room_id, sch.teacher_id, sch.exam_date, sch.start_time, sch.end_time, off.id AS offering_id
       FROM efp_exam_schedule sch JOIN efp_exams ex ON ex.id = sch.exam_id
       JOIN efp_offerings off ON off.id = ex.offering_id`
    );
    const allOfferingIds = [...new Set(existingRows.map((row) => Number(row.offering_id)))];
    const missingOfferingIds = allOfferingIds.filter((id) => !studentsByOffering.has(id));
    if (missingOfferingIds.length) {
      const [otherEnrollments] = await connection.query(
        `SELECT offering_id, student_id FROM efp_enrollments WHERE offering_id IN (${missingOfferingIds.map(() => '?').join(',')})`, missingOfferingIds
      );
      for (const row of otherEnrollments) {
        const key = Number(row.offering_id);
        if (!studentsByOffering.has(key)) studentsByOffering.set(key, []);
        studentsByOffering.get(key).push(Number(row.student_id));
      }
    }
    const existing = existingRows.map((row) => ({
      ...row, studentIds: studentsByOffering.get(Number(row.offering_id)) || []
    }));

    const ordered = sortExams(exams, algorithm);
    const results = [];
    const unscheduled = [];

    for (const exam of ordered) {
      const studentIds = studentsByOffering.get(Number(exam.offering_id)) || [];
      if (studentIds.length === 0) {
        unscheduled.push({ examId: Number(exam.id), subject: `${exam.subject_code} · ${exam.subject_name}`, reason: 'No students are enrolled in this subject offering.' });
        continue;
      }
      const slots = buildSlots(session, Number(exam.duration_minutes));
      let placed = null;
      for (const slot of slots) {
        const overlapping = existing.filter((item) => item.exam_date === slot.date
          && overlaps(item.start_time, item.end_time, slot.start, slot.end));
        if (intersects(studentIds, overlapping.flatMap((item) => item.studentIds))) continue;

        for (const room of rooms) {
          if (Number(room.capacity) < Number(exam.student_count)) continue;
          if (overlapping.some((item) => Number(item.room_id) === Number(room.id))) continue;

          for (const teacher of teachers) {
            if (overlapping.some((item) => Number(item.teacher_id) === Number(teacher.id))) continue;
            if (!teacherAvailable(teacher.id, slot.date, slot.start, slot.end, availability)) continue;
            placed = { exam, slot, room, teacher, studentIds };
            break;
          }
          if (placed) break;
        }
        if (placed) break;
      }

      if (!placed) {
        unscheduled.push({ examId: Number(exam.id), subject: `${exam.subject_code} · ${exam.subject_name}`, reason: 'No slot satisfied student, room capacity, room availability, and approved-teacher availability constraints.' });
        continue;
      }

      const [insertResult] = await connection.execute(
        `INSERT INTO efp_exam_schedule (exam_id, room_id, teacher_id, exam_date, start_time, end_time, status)
         VALUES (?, ?, ?, ?, ?, ?, 'draft')`,
        [placed.exam.id, placed.room.id, placed.teacher.id, placed.slot.date, placed.slot.start, placed.slot.end]
      );
      const record = {
        id: insertResult.insertId,
        exam_id: Number(placed.exam.id),
        room_id: Number(placed.room.id),
        room_name: placed.room.name,
        teacher_id: Number(placed.teacher.id),
        teacher_name: placed.teacher.name,
        exam_date: placed.slot.date,
        start_time: placed.slot.start,
        end_time: placed.slot.end,
        subject_code: placed.exam.subject_code,
        subject_name: placed.exam.subject_name,
        student_count: Number(placed.exam.student_count),
        studentIds: placed.studentIds
      };
      existing.push(record);
      results.push(record);
    }

    await connection.commit();
    return { algorithm: String(algorithm).toUpperCase(), scheduled: results, unscheduled, total: exams.length };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

module.exports = { generateSchedule, overlaps, sortExams, buildSlots, toMinutes, teacherAvailable };
