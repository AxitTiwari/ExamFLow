const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const { env } = require('./env');

let pool;

const schema = [
  `CREATE TABLE IF NOT EXISTS efp_users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','student','teacher') NOT NULL,
    status ENUM('active','pending','rejected') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_efp_users_role_status (role, status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_courses (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    code VARCHAR(30) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_branches (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    course_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(120) NOT NULL,
    code VARCHAR(30) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_efp_branch_course_name (course_id, name),
    CONSTRAINT fk_efp_branches_course FOREIGN KEY (course_id) REFERENCES efp_courses(id)
      ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_students (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    course_id BIGINT UNSIGNED NOT NULL,
    branch_id BIGINT UNSIGNED NOT NULL,
    academic_year SMALLINT UNSIGNED NOT NULL,
    semester TINYINT UNSIGNED NOT NULL,
    roll_number VARCHAR(50) NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_efp_students_user FOREIGN KEY (user_id) REFERENCES efp_users(id) ON DELETE CASCADE,
    CONSTRAINT fk_efp_students_course FOREIGN KEY (course_id) REFERENCES efp_courses(id) ON DELETE RESTRICT,
    CONSTRAINT fk_efp_students_branch FOREIGN KEY (branch_id) REFERENCES efp_branches(id) ON DELETE RESTRICT,
    CONSTRAINT chk_efp_student_semester CHECK (semester BETWEEN 1 AND 12),
    INDEX idx_efp_students_batch (course_id, branch_id, academic_year, semester)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_teachers (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    department VARCHAR(120) NOT NULL,
    designation VARCHAR(120) NULL,
    employee_code VARCHAR(50) NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_efp_teachers_user FOREIGN KEY (user_id) REFERENCES efp_users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_subjects (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    name VARCHAR(160) NOT NULL,
    credits DECIMAL(3,1) NOT NULL DEFAULT 3.0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_offerings (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    subject_id BIGINT UNSIGNED NOT NULL,
    course_id BIGINT UNSIGNED NOT NULL,
    branch_id BIGINT UNSIGNED NOT NULL,
    academic_year SMALLINT UNSIGNED NOT NULL,
    semester TINYINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_efp_offering_batch (subject_id, course_id, branch_id, academic_year, semester),
    CONSTRAINT fk_efp_offerings_subject FOREIGN KEY (subject_id) REFERENCES efp_subjects(id) ON DELETE RESTRICT,
    CONSTRAINT fk_efp_offerings_course FOREIGN KEY (course_id) REFERENCES efp_courses(id) ON DELETE RESTRICT,
    CONSTRAINT fk_efp_offerings_branch FOREIGN KEY (branch_id) REFERENCES efp_branches(id) ON DELETE RESTRICT,
    INDEX idx_efp_offerings_batch (course_id, branch_id, academic_year, semester)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_enrollments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    student_id BIGINT UNSIGNED NOT NULL,
    offering_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_efp_enrollment (student_id, offering_id),
    CONSTRAINT fk_efp_enrollments_student FOREIGN KEY (student_id) REFERENCES efp_students(id) ON DELETE CASCADE,
    CONSTRAINT fk_efp_enrollments_offering FOREIGN KEY (offering_id) REFERENCES efp_offerings(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_rooms (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    building VARCHAR(120) NULL,
    capacity INT UNSIGNED NOT NULL,
    room_type VARCHAR(60) NOT NULL DEFAULT 'Classroom',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_efp_room_capacity CHECK (capacity > 0)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_exam_sessions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    day_start_time TIME NOT NULL DEFAULT '09:00:00',
    day_end_time TIME NOT NULL DEFAULT '17:00:00',
    status ENUM('draft','published') NOT NULL DEFAULT 'draft',
    created_by BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_efp_sessions_creator FOREIGN KEY (created_by) REFERENCES efp_users(id) ON DELETE RESTRICT,
    CONSTRAINT chk_efp_session_dates CHECK (end_date >= start_date),
    INDEX idx_efp_sessions_dates (start_date, end_date)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_exams (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    session_id BIGINT UNSIGNED NOT NULL,
    offering_id BIGINT UNSIGNED NOT NULL,
    duration_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 180,
    priority TINYINT UNSIGNED NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_efp_exam_session_offering (session_id, offering_id),
    CONSTRAINT fk_efp_exams_session FOREIGN KEY (session_id) REFERENCES efp_exam_sessions(id) ON DELETE CASCADE,
    CONSTRAINT fk_efp_exams_offering FOREIGN KEY (offering_id) REFERENCES efp_offerings(id) ON DELETE RESTRICT,
    CONSTRAINT chk_efp_exam_duration CHECK (duration_minutes BETWEEN 30 AND 480),
    INDEX idx_efp_exams_session (session_id, priority, created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_teacher_availability (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    teacher_id BIGINT UNSIGNED NOT NULL,
    weekday TINYINT UNSIGNED NULL,
    available_date DATE NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_efp_availability_teacher FOREIGN KEY (teacher_id) REFERENCES efp_teachers(id) ON DELETE CASCADE,
    CONSTRAINT chk_efp_availability_day CHECK ((weekday IS NOT NULL) OR (available_date IS NOT NULL)),
    CONSTRAINT chk_efp_availability_weekday CHECK (weekday IS NULL OR weekday BETWEEN 0 AND 6),
    CONSTRAINT chk_efp_availability_time CHECK (end_time > start_time),
    INDEX idx_efp_availability_teacher_day (teacher_id, weekday, available_date)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS efp_exam_schedule (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    exam_id BIGINT UNSIGNED NOT NULL UNIQUE,
    room_id BIGINT UNSIGNED NOT NULL,
    teacher_id BIGINT UNSIGNED NOT NULL,
    exam_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status ENUM('draft','published') NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_efp_schedule_exam FOREIGN KEY (exam_id) REFERENCES efp_exams(id) ON DELETE CASCADE,
    CONSTRAINT fk_efp_schedule_room FOREIGN KEY (room_id) REFERENCES efp_rooms(id) ON DELETE RESTRICT,
    CONSTRAINT fk_efp_schedule_teacher FOREIGN KEY (teacher_id) REFERENCES efp_teachers(id) ON DELETE RESTRICT,
    CONSTRAINT chk_efp_schedule_time CHECK (end_time > start_time),
    INDEX idx_efp_schedule_date_time (exam_date, start_time, end_time),
    INDEX idx_efp_schedule_room (room_id, exam_date),
    INDEX idx_efp_schedule_teacher (teacher_id, exam_date)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`
];

async function initializeDatabase() {
  const bootstrap = await mysql.createConnection({
    host: env.DB_HOST,
    port: env.DB_PORT,
    user: env.DB_USER,
    password: env.DB_PASSWORD,
    multipleStatements: false
  });
  const safeName = env.DB_NAME.replace(/[^a-zA-Z0-9_]/g, '');
  await bootstrap.query(`CREATE DATABASE IF NOT EXISTS \`${safeName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await bootstrap.end();

  pool = mysql.createPool({
    host: env.DB_HOST,
    port: env.DB_PORT,
    user: env.DB_USER,
    password: env.DB_PASSWORD,
    database: safeName,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    timezone: 'Z',
    dateStrings: ['DATE', 'TIME']
  });

  for (const statement of schema) await pool.query(statement);
  await seedAdmin();
  return pool;
}

async function seedAdmin() {
  const email = env.ADMIN_EMAIL.toLowerCase();
  const [rows] = await pool.execute('SELECT id, role FROM efp_users WHERE email = ?', [email]);
  if (rows.length) {
    if (rows[0].role !== 'admin') throw new Error(`ADMIN_EMAIL ${email} is already used by a non-admin account. Choose a different ADMIN_EMAIL.`);
    return;
  }
  const hash = await bcrypt.hash(env.ADMIN_PASSWORD, 12);
  await pool.execute(
    `INSERT INTO efp_users (name, email, password_hash, role, status)
     VALUES (?, ?, ?, 'admin', 'active')`,
    [env.ADMIN_NAME, email, hash]
  );
  console.log(`Initial admin account created: ${email}`);
}

function getPool() {
  if (!pool) throw new Error('Database has not been initialized.');
  return pool;
}

module.exports = { initializeDatabase, getPool };
