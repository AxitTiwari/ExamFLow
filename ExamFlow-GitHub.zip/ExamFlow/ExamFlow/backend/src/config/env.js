const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });

const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: Number(process.env.PORT || 5000),
  FRONTEND_ORIGIN: process.env.FRONTEND_ORIGIN || 'http://localhost:5173',
  DB_HOST: process.env.DB_HOST || 'localhost',
  DB_PORT: Number(process.env.DB_PORT || 3306),
  DB_USER: process.env.DB_USER || 'root',
  DB_PASSWORD: process.env.DB_PASSWORD || '',
  DB_NAME: process.env.DB_NAME || 'university_exam_scheduler',
  ADMIN_NAME: process.env.ADMIN_NAME || 'ExamFlow Administrator',
  ADMIN_EMAIL: process.env.ADMIN_EMAIL || 'admin@examflow.local',
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD || '',
  JWT_SECRET: process.env.JWT_SECRET || '',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '8h'
};

if (!env.ADMIN_PASSWORD && env.NODE_ENV === 'production') {
  throw new Error('ADMIN_PASSWORD must be configured in production.');
}
if (!env.JWT_SECRET || env.JWT_SECRET.length < 32) {
  if (env.NODE_ENV === 'production') throw new Error('JWT_SECRET must be at least 32 characters in production.');
  env.JWT_SECRET = 'development-only-secret-change-this-before-deploying-123456';
}
if (!env.ADMIN_PASSWORD) env.ADMIN_PASSWORD = 'ChangeThisAdminPassword123!';

module.exports = { env };
