const test = require('node:test');
const assert = require('node:assert/strict');
const { overlaps, sortExams, buildSlots, teacherAvailable } = require('../src/services/scheduler');

test('overlap detection treats touching exam boundaries as non-overlapping', () => {
  assert.equal(overlaps('09:00:00', '12:00:00', '11:00:00', '13:00:00'), true);
  assert.equal(overlaps('09:00:00', '11:00:00', '11:00:00', '13:00:00'), false);
  assert.equal(overlaps('13:00:00', '15:00:00', '09:00:00', '13:00:00'), false);
});

test('FCFS keeps registration order', () => {
  const exams = [
    { id: 2, created_at: '2026-11-01 10:00:00', priority: 1 },
    { id: 1, created_at: '2026-11-01 09:00:00', priority: 5 }
  ];
  assert.deepEqual(sortExams(exams, 'FCFS').map((exam) => exam.id), [1, 2]);
});

test('Priority Scheduling orders higher priority first and uses FCFS for ties', () => {
  const exams = [
    { id: 1, created_at: '2026-11-01 09:00:00', priority: 2 },
    { id: 2, created_at: '2026-11-01 08:00:00', priority: 5 },
    { id: 3, created_at: '2026-11-01 07:00:00', priority: 5 }
  ];
  assert.deepEqual(sortExams(exams, 'PRIORITY').map((exam) => exam.id), [3, 2, 1]);
});

test('slot generation stays inside the session window and uses half-hour increments', () => {
  const slots = buildSlots({ start_date: '2026-11-16', end_date: '2026-11-16', day_start_time: '09:00:00', day_end_time: '12:00:00' }, 90);
  assert.deepEqual(slots, [
    { date: '2026-11-16', start: '09:00:00', end: '10:30:00' },
    { date: '2026-11-16', start: '09:30:00', end: '11:00:00' },
    { date: '2026-11-16', start: '10:00:00', end: '11:30:00' },
    { date: '2026-11-16', start: '10:30:00', end: '12:00:00' }
  ]);
});

test('teacher availability supports recurring weekdays and date-specific entries', () => {
  const availability = [
    { teacher_id: 7, weekday: 1, available_date: null, start_time: '09:00:00', end_time: '13:00:00' },
    { teacher_id: 8, weekday: null, available_date: '2026-11-17', start_time: '10:00:00', end_time: '14:00:00' }
  ];
  assert.equal(teacherAvailable(7, '2026-11-16', '10:00:00', '12:00:00', availability), true);
  assert.equal(teacherAvailable(8, '2026-11-17', '11:00:00', '13:00:00', availability), true);
  assert.equal(teacherAvailable(8, '2026-11-18', '11:00:00', '13:00:00', availability), false);
});
